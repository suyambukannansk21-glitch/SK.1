import os
import shutil
import platform
from pathlib import Path
from datetime import datetime

try:
    import send2trash
    _SEND2TRASH = True
except ImportError:
    _SEND2TRASH = False

from core.undo import push_undo

_OS = platform.system()  # "Windows" | "Darwin" | "Linux"

# Undo keeps a file's previous contents in memory so `write` can be reversed.
# Above this size it does not — a 200 MB log would sit in RAM for the rest of
# the session to protect an edit nobody is going to take back.
_UNDO_CONTENT_LIMIT = 1_000_000


def _undo_move(src: Path, dst: Path):
    """Reverse of a move: put it back where it came from."""
    def _fn():
        if not dst.exists():
            return f"'{dst.name}' is no longer there — nothing moved back."
        src.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dst), str(src))
        return f"'{src.name}' is back in {src.parent.name}/."
    return _fn


def _undo_create(target: Path):
    """Reverse of a create: remove what we made — and only if we still made it.

    Deliberately refuses to touch a directory that has since been filled: the
    undo for 'create a folder' is not 'delete whatever ended up in it'."""
    def _fn():
        if not target.exists():
            return f"'{target.name}' is already gone."
        if target.is_dir():
            if any(target.iterdir()):
                return (f"'{target.name}' is not empty any more — "
                        f"leaving it alone rather than deleting your files.")
            target.rmdir()
        else:
            target.unlink()
        return f"Removed '{target.name}'."
    return _fn


def _undo_write(target: Path, previous: str | None):
    """Reverse of a write: restore the old contents, or remove a file that did
    not exist before the write created it."""
    def _fn():
        if previous is None:
            if target.exists():
                target.unlink()
                return f"Removed '{target.name}' — it did not exist before."
            return f"'{target.name}' is already gone."
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(previous, encoding="utf-8")
        return f"Restored the previous contents of '{target.name}'."
    return _fn


def _restore_from_trash(original: Path) -> str:
    """Best-effort undelete.

    delete_file uses send2trash, which is the right call: the file lands in the
    Recycle Bin / Trash where the person can also find it themselves. Getting it
    back out again is shell work and only reliable on Windows, where pywin32 is
    already a dependency. Everywhere else this says where the file is instead of
    pretending it failed — the file is not lost either way."""
    if _OS == "Windows":
        try:
            import win32com.client
            shell = win32com.client.Dispatch("Shell.Application")
            bin_folder = shell.NameSpace(10)      # ssfBITBUCKET
            for item in bin_folder.Items():
                if str(bin_folder.GetDetailsOf(item, 1)).strip().lower() == \
                        str(original.parent).strip().lower():
                    if str(item.Name).strip().lower() == original.name.strip().lower():
                        item.InvokeVerb("UNDELETE")
                        return f"'{original.name}' restored from the Recycle Bin."
        except Exception as e:
            print(f"[file] Recycle Bin restore failed: {e}")
    return (f"'{original.name}' is in the Recycle Bin — I could not pull it back "
            f"automatically, but it is there and can be restored by hand.")


_SAFE_ROOTS: list[Path] = [
    Path.home(),
]

def _is_safe_path(target: Path) -> bool:
    """Full system access: all files, folders, and drives are permitted."""
    return True

def _get_desktop() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_DESKTOP_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Desktop"

def _get_downloads() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_DOWNLOAD_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Downloads"

def _get_documents() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_DOCUMENTS_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Documents"

def _get_pictures() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_PICTURES_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Pictures"

def _get_music() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_MUSIC_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Music"

def _get_videos() -> Path:
    if _OS == "Linux":
        xdg = os.environ.get("XDG_VIDEOS_DIR", "")
        if xdg and Path(xdg).exists():
            return Path(xdg)
    return Path.home() / "Videos"


def _resolve_path(raw: str) -> Path:
    shortcuts: dict[str, Path] = {
        "desktop":   _get_desktop(),
        "downloads": _get_downloads(),
        "documents": _get_documents(),
        "pictures":  _get_pictures(),
        "music":     _get_music(),
        "videos":    _get_videos(),
        "home":      Path.home(),
    }
    if not raw:
        return Path.cwd()
    clean = str(raw).strip().strip("'\"`")
    lower = clean.lower()
    for prefix, folder in shortcuts.items():
        if lower == prefix:
            return folder
        if lower.startswith(prefix + "/") or lower.startswith(prefix + "\\"):
            sub = clean[len(prefix)+1:]
            return folder / sub
    return Path(clean).expanduser()


def _get_target_path(path: str = "", name: str = "") -> Path:
    """Resolves target path cleanly whether user/model provides full path in path or name, or split."""
    clean_p = str(path or "").strip().strip("'\"`")
    clean_n = str(name or "").strip().strip("'\"`")

    # If clean_n is an absolute path or drive path (e.g. D:\foo or /foo), use it directly
    if clean_n:
        try:
            pn = Path(clean_n).expanduser()
            if pn.is_absolute() or (len(clean_n) > 1 and clean_n[1] == ":") or clean_n.startswith(("/", "\\")):
                return pn.resolve()
        except Exception:
            pass

    if not clean_p:
        if clean_n:
            return (_get_desktop() / clean_n).resolve()
        return Path.cwd().resolve()

    base = _resolve_path(clean_p)

    if clean_n:
        if base.is_file() or (base.name.lower() == clean_n.lower()):
            return base.resolve()
        return (base / clean_n).resolve()

    return base.resolve()

def _format_size(b: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if b < 1024:
            return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} TB"

def _safe_trash(target: Path) -> str:
    if _SEND2TRASH:
        try:
            send2trash.send2trash(str(target))
            return f"Moved to Trash: {target.name}"
        except Exception as e:
            print(f"[file_controller] send2trash failed, falling back to permanent delete: {e}")
    try:
        if target.is_dir():
            shutil.rmtree(str(target))
        else:
            target.unlink()
        return f"Deleted: {target.name}"
    except Exception as e:
        return f"Could not delete {target.name}: {e}"


def list_files(path: str = "desktop", show_hidden: bool = False) -> str:
    try:
        target = _get_target_path(path)
        if not target.exists():
            return f"Path not found: {target}"
        if not target.is_dir():
            return f"Not a directory: {target}"

        items = []
        for item in sorted(target.iterdir()):
            if not show_hidden and item.name.startswith("."):
                continue
            if item.is_dir():
                items.append(f"📁 {item.name}/")
            else:
                size = _format_size(item.stat().st_size)
                items.append(f"📄 {item.name} ({size})")

        if not items:
            return f"Directory is empty: {target}/"

        return f"Contents of {target} ({len(items)} items):\n" + "\n".join(items)

    except PermissionError:
        return f"Permission denied: {path}"
    except Exception as e:
        return f"Error listing files: {e}"


def create_file(path: str, name: str = "", content: str = "") -> str:
    try:
        target = _get_target_path(path, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        existed = target.exists()
        previous = None
        if existed:
            try:
                previous = target.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                previous = None
        target.write_text(content, encoding="utf-8")
        push_undo(f"created {target.name}",
                  _undo_write(target, previous) if existed else _undo_create(target))
        return f"File created: {target}"
    except Exception as e:
        return f"Could not create file: {e}"


def create_folder(path: str, name: str = "") -> str:
    try:
        target = _get_target_path(path, name)
        already = target.exists()
        target.mkdir(parents=True, exist_ok=True)
        if not already:
            push_undo(f"created folder {target.name}", _undo_create(target))
        return f"Folder created: {target}"
    except Exception as e:
        return f"Could not create folder: {e}"


def delete_file(path: str, name: str = "") -> str:
    try:
        target = _get_target_path(path, name)
        if not target.exists():
            return f"Not found: {target}"

        # Protect root directories and user root folder
        protected = {
            _get_desktop(), _get_downloads(), _get_documents(),
            _get_pictures(), _get_music(), _get_videos(), Path.home()
        }
        if target.resolve() in {p.resolve() for p in protected} or target.resolve().parent == target.resolve():
            return f"Protected directory, cannot delete: {target}"

        original = target.resolve()
        result   = _safe_trash(target)
        if result.startswith("Moved to Trash") or result.startswith("Deleted"):
            push_undo(f"deleted {original.name}",
                      lambda p=original: _restore_from_trash(p))
        return result

    except PermissionError:
        return f"Permission denied: {target}"
    except Exception as e:
        return f"Could not delete: {e}"


def move_file(path: str, name: str = "", destination: str = "") -> str:
    try:
        src = _get_target_path(path, name)
        if not src.exists():
            return f"Source not found: {src}"
        if not destination:
            return "No destination specified."
        dst = _get_target_path(destination)

        if dst.is_dir():
            dst = dst / src.name

        dst.parent.mkdir(parents=True, exist_ok=True)
        origin = src.resolve()
        shutil.move(str(src), str(dst))
        push_undo(f"moved {origin.name} to {dst.parent}/",
                  _undo_move(origin, dst.resolve()))
        return f"Moved: {src.name} → {dst}"

    except Exception as e:
        return f"Could not move: {e}"


def copy_file(path: str, name: str = "", destination: str = "") -> str:
    try:
        src = _get_target_path(path, name)
        if not src.exists():
            return f"Source not found: {src}"
        if not destination:
            return "No destination specified."
        dst = _get_target_path(destination)

        if dst.is_dir():
            dst = dst / src.name

        dst.parent.mkdir(parents=True, exist_ok=True)

        if src.is_dir():
            shutil.copytree(str(src), str(dst))
        else:
            shutil.copy2(str(src), str(dst))

        _copy = dst.resolve()
        def _undo_copy():
            if not _copy.exists():
                return f"The copy '{_copy.name}' is already gone."
            if _copy.is_dir():
                shutil.rmtree(_copy)
            else:
                _copy.unlink()
            return f"Removed the copy in {_copy.parent}/."
        push_undo(f"copied {src.name} to {dst.parent}/", _undo_copy)

        return f"Copied: {src.name} → {dst}"

    except Exception as e:
        return f"Could not copy: {e}"


def rename_file(path: str, name: str = "", new_name: str = "") -> str:
    try:
        target = _get_target_path(path, name)
        if not target.exists():
            return f"Not found: {target}"
        clean_new = str(new_name or "").strip().strip("'\"`")
        if not clean_new:
            return "No new name provided."

        new_path = target.parent / clean_new
        if new_path.exists():
            return f"A file named '{clean_new}' already exists here."

        old_path = target.resolve()
        target.rename(new_path)
        push_undo(f"renamed {old_path.name} to {clean_new}",
                  _undo_move(old_path, new_path.resolve()))
        return f"Renamed: {target.name} → {clean_new}"

    except Exception as e:
        return f"Could not rename: {e}"


def read_file(path: str, name: str = "", max_chars: int = 16000) -> str:
    try:
        target = _get_target_path(path, name)
        if not target.exists():
            return f"File not found: {target}"
        if not target.is_file():
            return f"Not a file: {target}"

        content = target.read_text(encoding="utf-8", errors="ignore")
        if max_chars and len(content) > max_chars:
            content = content[:max_chars] + f"\n\n[Truncated — {len(content)} total chars. Increase max_chars to view more.]"
        return content

    except Exception as e:
        return f"Could not read file: {e}"


def write_file(path: str, name: str = "", content: str = "",
               append: bool = False) -> str:
    try:
        target = _get_target_path(path, name)
        target.parent.mkdir(parents=True, exist_ok=True)

        previous: str | None = None
        undoable = True
        if target.exists():
            try:
                if target.stat().st_size > _UNDO_CONTENT_LIMIT:
                    undoable = False
                else:
                    previous = target.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                undoable = False

        mode = "a" if append else "w"
        with open(target, mode, encoding="utf-8") as f:
            f.write(content)

        action = "Appended to" if append else "Written to"
        if undoable:
            push_undo(f"wrote to {target.name}", _undo_write(target, previous))
            return f"{action}: {target}"
        return f"{action}: {target}."
    except Exception as e:
        return f"Could not write file: {e}"


def edit_file(
    path: str,
    name: str = "",
    old_text: str = "",
    new_text: str = "",
    content: str = "",
    instruction: str = "",
    line: int = 0,
    append: bool = False,
) -> str:
    """Edits an existing file: exact text replacement, line replacement, append, full rewrite, or LLM instruction."""
    try:
        target = _get_target_path(path, name)
        if not target.exists():
            if content or new_text:
                return create_file(path=str(target.parent), name=target.name, content=content or new_text)
            return f"File not found: {target}"
        if not target.is_file():
            return f"Not a file: {target}"

        previous = target.read_text(encoding="utf-8", errors="ignore")
        updated = previous

        # 1. Append
        if append:
            to_append = content or new_text
            updated = previous + ("\n" if previous and not previous.endswith("\n") else "") + to_append
            target.write_text(updated, encoding="utf-8")
            push_undo(f"appended to {target.name}", _undo_write(target, previous))
            return f"Appended to '{target.name}'. Length: {len(updated)} chars."

        # 2. Exact match replacement
        if old_text:
            if old_text in previous:
                updated = previous.replace(old_text, new_text, 1)
            elif old_text.strip() in previous:
                updated = previous.replace(old_text.strip(), new_text, 1)
            else:
                return f"Could not find target text in '{target.name}'. Did not find:\n{old_text[:120]}"

            target.write_text(updated, encoding="utf-8")
            push_undo(f"edited {target.name}", _undo_write(target, previous))
            return f"Edited '{target.name}': Replaced '{old_text[:40]}...' with '{new_text[:40]}...'."

        # 3. Line replacement
        if line and line > 0:
            lines = previous.splitlines(keepends=True)
            if line <= len(lines):
                lines[line - 1] = new_text + ("\n" if not new_text.endswith("\n") else "")
            else:
                lines.append(new_text + "\n")
            updated = "".join(lines)
            target.write_text(updated, encoding="utf-8")
            push_undo(f"edited line {line} in {target.name}", _undo_write(target, previous))
            return f"Updated line {line} in '{target.name}'."

        # 4. Direct full content replacement
        if content:
            target.write_text(content, encoding="utf-8")
            push_undo(f"overwrote {target.name}", _undo_write(target, previous))
            return f"Updated '{target.name}' with new content ({len(content)} chars)."

        # 5. Semantic / instruction-based edit
        if instruction:
            try:
                from actions.code_helper import _get_gemini, _clean_code
                model = _get_gemini()
                prompt = f"""You are an expert file editor.
Apply the following change or instruction to the file below.
Return ONLY the complete updated file content — no explanation, no markdown, no code fences.

Instruction: {instruction}

Original content:
{previous}

Updated content:"""
                resp = model.generate_content(prompt)
                updated = _clean_code(resp.text)
                target.write_text(updated, encoding="utf-8")
                push_undo(f"edited {target.name} ({instruction[:30]})", _undo_write(target, previous))
                return f"Edited '{target.name}' according to instruction: {instruction}."
            except Exception as ge:
                return f"Could not apply edit instruction via Gemini: {ge}"

        return "Please specify what to edit: provide old_text & new_text, content, line & new_text, or an instruction."

    except Exception as e:
        return f"Could not edit file: {e}"


def find_files(name: str = "", extension: str = "",
               path: str = "", max_results: int = 20) -> str:
    try:
        search_path = _get_target_path(path)
        if not search_path.exists():
            return f"Search path not found: {path}"

        results    = []
        dir_count  = 0
        max_dirs   = 1000

        for item in search_path.rglob("*"):
            if item.is_dir():
                dir_count += 1
                if dir_count > max_dirs:
                    break
                continue
            if not item.is_file():
                continue
            if extension and item.suffix.lower() != extension.lower():
                continue
            if name and name.lower() not in item.name.lower():
                continue
            size = _format_size(item.stat().st_size)
            results.append(f"📄 {item.name} ({size}) — {item.parent}")
            if len(results) >= max_results:
                break

        if not results:
            query = name or extension or "files"
            return f"No {query} found in {search_path}/"

        return f"Found {len(results)} file(s):\n" + "\n".join(results)

    except Exception as e:
        return f"Search error: {e}"


def get_largest_files(path: str = "downloads", count: int = 10) -> str:
    count = min(count, 50)
    try:
        search_path = _get_target_path(path)
        if not search_path.exists():
            return f"Path not found: {path}"

        files = []
        for item in search_path.rglob("*"):
            if item.is_file():
                try:
                    files.append((item.stat().st_size, item))
                except Exception:
                    continue

        files.sort(reverse=True)
        top = files[:count]

        if not top:
            return "No files found."

        lines = [f"Top {len(top)} largest files in {search_path}/:"]
        for size, f in top:
            lines.append(f"  {_format_size(size):>10}  {f.name}  ({f.parent})")

        return "\n".join(lines)

    except Exception as e:
        return f"Error: {e}"


def get_disk_usage(path: str = "home") -> str:
    try:
        target = _get_target_path(path)
        usage  = shutil.disk_usage(target)
        pct    = usage.used / usage.total * 100
        return (
            f"Disk usage ({target}):\n"
            f"  Total : {_format_size(usage.total)}\n"
            f"  Used  : {_format_size(usage.used)} ({pct:.1f}%)\n"
            f"  Free  : {_format_size(usage.free)}"
        )
    except Exception as e:
        return f"Could not get disk usage: {e}"


def organize_desktop() -> str:
    type_map = {
        "Images":    {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".ico", ".heic"},
        "Documents": {".pdf", ".doc", ".docx", ".txt", ".xls", ".xlsx",
                      ".ppt", ".pptx", ".csv", ".odt", ".ods", ".odp"},
        "Videos":    {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v"},
        "Music":     {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"},
        "Archives":  {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"},
        "Code":      {".py", ".js", ".ts", ".html", ".css", ".json", ".xml",
                      ".cpp", ".java", ".cs", ".go", ".rs", ".sh"},
    }

    desktop = _get_desktop()
    moved, skipped = [], []
    journal: list[tuple[Path, Path]] = []

    try:
        for item in desktop.iterdir():
            if item.is_dir() or item.name.startswith("."):
                continue
            if item.name in {k for k in type_map}:
                continue

            ext        = item.suffix.lower()
            target_dir = desktop / "Others"
            for folder, exts in type_map.items():
                if ext in exts:
                    target_dir = desktop / folder
                    break

            target_dir.mkdir(exist_ok=True)
            new_path = target_dir / item.name

            if new_path.exists():
                skipped.append(item.name)
                continue

            origin = item.resolve()
            shutil.move(str(item), str(new_path))
            journal.append((origin, new_path.resolve()))
            moved.append(f"{item.name} → {target_dir.name}/")

        if journal:
            def _undo_organize(entries=tuple(journal)):
                restored = 0
                for origin, moved_to in entries:
                    try:
                        if moved_to.exists():
                            origin.parent.mkdir(parents=True, exist_ok=True)
                            shutil.move(str(moved_to), str(origin))
                            restored += 1
                    except Exception as e:
                        print(f"[file] undo organize: {moved_to.name}: {e}")
                for folder in {m.parent for _o, m in entries}:
                    try:
                        if folder.exists() and folder.is_dir() and not any(folder.iterdir()):
                            folder.rmdir()
                    except Exception:
                        pass
                return f"{restored} file(s) put back on the desktop."
            push_undo(f"organized the desktop ({len(journal)} files)", _undo_organize)

        result = f"Desktop organized: {len(moved)} files moved."
        if moved:
            preview = moved[:8]
            result += "\n" + "\n".join(preview)
            if len(moved) > 8:
                result += f"\n... and {len(moved) - 8} more."
        if skipped:
            result += f"\n{len(skipped)} file(s) skipped (name conflict)."
        return result

    except Exception as e:
        return f"Could not organize desktop: {e}"


def get_file_info(path: str, name: str = "") -> str:
    try:
        target = _get_target_path(path, name)
        if not target.exists():
            return f"Not found: {target}"

        stat = target.stat()
        info = {
            "Name":      target.name,
            "Type":      "Folder" if target.is_dir() else "File",
            "Size":      _format_size(stat.st_size),
            "Location":  str(target.parent),
            "Path":      str(target.resolve()),
            "Created":   datetime.fromtimestamp(stat.st_ctime).strftime("%Y-%m-%d %H:%M"),
            "Modified":  datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            "Extension": target.suffix or "—",
        }
        return "\n".join(f"  {k}: {v}" for k, v in info.items())

    except Exception as e:
        return f"Could not get file info: {e}"

def file_controller(
    parameters: dict = None,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    params = parameters or {}
    raw_action = params.get("action", "").lower().strip()
    path   = params.get("path", "")
    name   = params.get("name", "")

    action_map = {
        "list":             "list",
        "ls":               "list",
        "dir":              "list",
        "create_file":      "create_file",
        "create":           "create_file",
        "touch":            "create_file",
        "new_file":         "create_file",
        "create_folder":    "create_folder",
        "mkdir":            "create_folder",
        "new_folder":       "create_folder",
        "delete":           "delete",
        "delete_file":      "delete",
        "remove":           "delete",
        "rm":               "delete",
        "move":             "move",
        "mv":               "move",
        "copy":             "copy",
        "cp":               "copy",
        "rename":           "rename",
        "read":             "read",
        "read_file":        "read",
        "view":             "read",
        "cat":              "read",
        "write":            "write",
        "write_file":       "write",
        "save":             "write",
        "append":           "append",
        "edit":             "edit",
        "edit_file":        "edit",
        "modify":           "edit",
        "replace":          "edit",
        "update":           "edit",
        "find":             "find",
        "search":           "find",
        "largest":          "largest",
        "disk_usage":       "disk_usage",
        "organize_desktop": "organize_desktop",
        "info":             "info",
    }
    action = action_map.get(raw_action, raw_action)

    if player:
        player.write_log(f"[file] {action} {name or path}")

    try:
        if action == "list":
            return list_files(path or "desktop", show_hidden=params.get("show_hidden", False))

        elif action == "create_file":
            return create_file(path, name=name, content=params.get("content", ""))

        elif action == "create_folder":
            return create_folder(path, name=name)

        elif action == "delete":
            return delete_file(path, name=name)

        elif action == "move":
            return move_file(path, name=name, destination=params.get("destination", ""))

        elif action == "copy":
            return copy_file(path, name=name, destination=params.get("destination", ""))

        elif action == "rename":
            return rename_file(path, name=name, new_name=params.get("new_name", ""))

        elif action == "read":
            max_c = params.get("max_chars")
            max_c = int(max_c) if max_c else 16000
            return read_file(path, name=name, max_chars=max_c)

        elif action == "write":
            return write_file(
                path, name=name,
                content=params.get("content", ""),
                append=params.get("append", False)
            )

        elif action == "append":
            return write_file(
                path, name=name,
                content=params.get("content", "") or params.get("new_text", ""),
                append=True
            )

        elif action == "edit":
            return edit_file(
                path, name=name,
                old_text=params.get("old_text") or params.get("find") or params.get("target_text") or "",
                new_text=params.get("new_text") or params.get("replacement") or "",
                content=params.get("content", ""),
                instruction=params.get("instruction") or params.get("description") or "",
                line=int(params.get("line") or 0),
                append=bool(params.get("append", False)),
            )

        elif action == "find":
            return find_files(
                name=name or params.get("name", ""),
                extension=params.get("extension", ""),
                path=path or "home",
                max_results=min(int(params.get("max_results", 20)), 50),
            )

        elif action == "largest":
            return get_largest_files(
                path=path or "downloads",
                count=int(params.get("count", 10)),
            )

        elif action == "disk_usage":
            return get_disk_usage(path or "home")

        elif action == "organize_desktop":
            return organize_desktop()

        elif action == "info":
            return get_file_info(path, name=name)

        else:
            return f"Unknown action: '{action}'. Available: read, write, edit, append, create_file, create_folder, delete, move, copy, rename, list, find, info, disk_usage."

    except Exception as e:
        return f"File controller error ({action}): {e}"


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "file_controller",
    "description": (
        "Full access and permission to view, read, write, create, edit, modify, append, delete, "
        "move, copy, rename, and find ANY file or folder across the ENTIRE system and all drives "
        "(C:, D:, E:, Desktop, Documents, Downloads, project files, etc.). "
        "Supports direct path access, full file reads, text replacement, and intelligent editing."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "read | write | edit | append | create_file | create_folder | delete | move | copy | rename | list | find | largest | disk_usage | organize_desktop | info"
            },
            "path": {
                "type": "STRING",
                "description": "File or folder path on any drive (e.g. 'D:/project/app.py', 'C:/Users/...', 'D:/', 'desktop', 'documents')"
            },
            "name": {
                "type": "STRING",
                "description": "File or folder name (optional if full path is in path parameter)"
            },
            "content": {
                "type": "STRING",
                "description": "Content for create_file, write, append, or full replacement in edit"
            },
            "old_text": {
                "type": "STRING",
                "description": "Exact text to find and replace when action is edit"
            },
            "new_text": {
                "type": "STRING",
                "description": "Replacement text when action is edit or append"
            },
            "instruction": {
                "type": "STRING",
                "description": "Instruction for modifying the file when action is edit"
            },
            "line": {
                "type": "INTEGER",
                "description": "Line number to modify when action is edit"
            },
            "append": {
                "type": "BOOLEAN",
                "description": "If true, appends content to the end of the file"
            },
            "destination": {
                "type": "STRING",
                "description": "Destination path for move/copy"
            },
            "new_name": {
                "type": "STRING",
                "description": "New name for rename"
            },
            "max_chars": {
                "type": "INTEGER",
                "description": "Max characters to read for read action (default: 16000)"
            },
            "name": {
                "type": "STRING",
                "description": "File name to search for"
            },
            "extension": {
                "type": "STRING",
                "description": "File extension to search (e.g. .pdf)"
            },
            "count": {
                "type": "INTEGER",
                "description": "Number of results for largest"
            }
        },
        "required": [
            "action"
        ]
    },
    "handler": file_controller,
}

