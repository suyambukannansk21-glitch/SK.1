"""
actions/app_manager.py — Windows Application Downloader, Installer & Uninstaller

Allows JARVIS to:
- Search packages via Windows Package Manager (winget)
- Install applications silently via winget or direct URL download
- Uninstall applications with confirmation safeguard
- List all installed software from Windows Registry
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import winreg
from pathlib import Path

from core import confirm as confirm_gate

_WINGET_PATH = shutil.which("winget.exe") or "winget"


def _has_winget() -> bool:
    try:
        r = subprocess.run([_WINGET_PATH, "--version"], capture_output=True, timeout=5)
        return r.returncode == 0
    except Exception:
        return False


def search_apps(query: str, max_results: int = 15) -> str:
    """Search for installable applications in the Windows Package Manager repository."""
    query = query.strip().strip('"').strip("'")
    if not query:
        return "Please specify an application name to search for."

    if not _has_winget():
        return "Windows Package Manager (winget) is not available on this system."

    try:
        cmd = [
            _WINGET_PATH, "search", query,
            "--accept-source-agreements",
            "--exact" if len(query) <= 3 else ""
        ]
        cmd = [c for c in cmd if c]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30, errors="replace")
        lines = [line for line in proc.stdout.splitlines() if line.strip()]

        if not lines or "No package found" in proc.stdout:
            return f"No applications found matching '{query}' in winget repository."

        # Return header and first max_results lines
        header = lines[:2] if len(lines) >= 2 else []
        results = lines[2:2 + max_results]
        return "\n".join(header + results)
    except Exception as e:
        return f"Error searching applications: {e}"


def install_app(app_name: str, silent: bool = True) -> str:
    """
    Install an application via winget or direct download URL.
    Example: install_app("VLC.VLC") or install_app("Google.Chrome")
    """
    app_name = app_name.strip().strip('"').strip("'")
    if not app_name:
        return "Please specify an application name or installer URL."

    # Direct URL download
    if app_name.startswith("http://") or app_name.startswith("https://"):
        try:
            url = app_name
            filename = Path(url.split("?")[0]).name or "installer.exe"
            dest = Path(tempfile.gettempdir()) / filename

            print(f"[AppManager] Downloading installer from {url} to {dest}...")
            urllib.request.urlretrieve(url, str(dest))

            print(f"[AppManager] Running installer: {dest}")
            if dest.suffix.lower() == ".msi":
                subprocess.Popen(["msiexec.exe", "/i", str(dest), "/passive" if silent else ""])
            else:
                subprocess.Popen([str(dest)])
            return f"Downloaded and launched installer: {filename}"
        except Exception as e:
            return f"Failed to download and install from URL: {e}"

    if not _has_winget():
        return "winget is not installed. Please download installers manually or enable Windows Package Manager."

    try:
        cmd = [
            _WINGET_PATH, "install", app_name,
            "--accept-source-agreements",
            "--accept-package-agreements",
        ]
        if silent:
            cmd.append("--silent")

        print(f"[AppManager] Running: {' '.join(cmd)}")
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300, errors="replace")
        output = proc.stdout + proc.stderr

        if proc.returncode == 0:
            return f"Successfully installed '{app_name}'."
        elif "No package found" in output:
            return f"Package '{app_name}' not found. Try searching first with action='search'."
        else:
            return f"Install command finished with code {proc.returncode}:\n{output[-400:].strip()}"
    except Exception as e:
        return f"Error during installation of '{app_name}': {e}"


def uninstall_app(app_name: str, confirmed: bool = False) -> str:
    """
    Uninstall an application from the system.
    Gated behind confirmation so the user is in full control.
    """
    app_name = app_name.strip().strip('"').strip("'")
    if not app_name:
        return "Please specify an application name to uninstall."

    def _execute_uninstall() -> str:
        try:
            cmd = [_WINGET_PATH, "uninstall", app_name, "--accept-source-agreements"]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180, errors="replace")
            output = proc.stdout + proc.stderr
            if proc.returncode == 0:
                return f"Successfully uninstalled '{app_name}'."
            return f"Uninstall finished with code {proc.returncode}:\n{output[-300:].strip()}"
        except Exception as ex:
            return f"Uninstall failed: {ex}"

    if confirmed:
        return _execute_uninstall()

    return confirm_gate.request(
        key=f"uninstall_{app_name}",
        title=f"Uninstall {app_name}",
        detail=f"Are you sure you want to uninstall '{app_name}' from your computer?",
        run=_execute_uninstall,
    )


def list_installed_apps(query: str = "", max_results: int = 30) -> str:
    """List installed desktop applications by querying Windows Registry uninstall keys."""
    installed = {}
    query_lower = query.lower().strip()

    registry_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]

    for root_hive, subkey_path in registry_paths:
        try:
            with winreg.OpenKey(root_hive, subkey_path) as parent_key:
                num_subkeys = winreg.QueryInfoKey(parent_key)[0]
                for i in range(num_subkeys):
                    try:
                        subkey_name = winreg.EnumKey(parent_key, i)
                        with winreg.OpenKey(parent_key, subkey_name) as subkey:
                            try:
                                name, _ = winreg.QueryValueEx(subkey, "DisplayName")
                                name = str(name).strip()
                                if not name or name in installed:
                                    continue

                                # Skip system components / hotfixes if not requested
                                try:
                                    is_system, _ = winreg.QueryValueEx(subkey, "SystemComponent")
                                    if is_system == 1 and not query_lower:
                                        continue
                                except Exception:
                                    pass

                                try:
                                    version, _ = winreg.QueryValueEx(subkey, "DisplayVersion")
                                    version = str(version).strip()
                                except Exception:
                                    version = ""

                                if query_lower and query_lower not in name.lower():
                                    continue

                                installed[name] = version
                            except Exception:
                                pass
                    except Exception:
                        continue
        except Exception:
            continue

    if not installed:
        return f"No installed applications found{' matching ' + query if query else ''}."

    lines = [f"Found {len(installed)} installed application(s):"]
    for name, ver in sorted(installed.items())[:max_results]:
        ver_str = f" (v{ver})" if ver else ""
        lines.append(f"  • {name}{ver_str}")

    if len(installed) > max_results:
        lines.append(f"... and {len(installed) - max_results} more.")

    return "\n".join(lines)


def app_manager(
    parameters: dict = None,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    """Tool entrypoint called by JARVIS."""
    params = parameters or {}
    action = params.get("action", "").lower().strip()
    name   = params.get("name", "") or params.get("app_name", "") or params.get("query", "")
    silent = params.get("silent", True)
    confirmed = params.get("confirmed", False)

    if player:
        player.write_log(f"[app_manager] {action}: {name}")

    try:
        if action == "search":
            return search_apps(name)
        elif action in ("install", "download"):
            return install_app(name, silent=silent)
        elif action in ("uninstall", "delete", "remove"):
            return uninstall_app(name, confirmed=confirmed)
        elif action in ("list", "list_installed"):
            return list_installed_apps(query=name)
        else:
            return f"Unknown action: '{action}'. Available: search, install, uninstall, list."
    except Exception as e:
        return f"App manager error: {e}"
