"""
actions/registry_manager.py — Windows Registry Inspector and Editor

Allows JARVIS to safely:
- Read registry keys and values
- List subkeys and values
- Set / create registry values (with auto-backup)
- Delete values or subkeys (with confirmation and rollback backup)
"""

import os
import subprocess
import tempfile
import winreg
from datetime import datetime
from pathlib import Path

from core import confirm as confirm_gate

_HIVES = {
    "hkcu": winreg.HKEY_CURRENT_USER,
    "hkey_current_user": winreg.HKEY_CURRENT_USER,
    "hklm": winreg.HKEY_LOCAL_MACHINE,
    "hkey_local_machine": winreg.HKEY_LOCAL_MACHINE,
    "hkcr": winreg.HKEY_CLASSES_ROOT,
    "hkey_classes_root": winreg.HKEY_CLASSES_ROOT,
    "hku": winreg.HKEY_USERS,
    "hkey_users": winreg.HKEY_USERS,
    "hkcc": winreg.HKEY_CURRENT_CONFIG,
    "hkey_current_config": winreg.HKEY_CURRENT_CONFIG,
}

_TYPES = {
    "sz": winreg.REG_SZ,
    "string": winreg.REG_SZ,
    "reg_sz": winreg.REG_SZ,
    "dword": winreg.REG_DWORD,
    "reg_dword": winreg.REG_DWORD,
    "multi_sz": winreg.REG_MULTI_SZ,
    "reg_multi_sz": winreg.REG_MULTI_SZ,
    "expand_sz": winreg.REG_EXPAND_SZ,
    "reg_expand_sz": winreg.REG_EXPAND_SZ,
    "binary": winreg.REG_BINARY,
    "reg_binary": winreg.REG_BINARY,
}


def _get_hive(raw: str):
    return _HIVES.get(raw.lower().strip(), winreg.HKEY_CURRENT_USER)


def _get_type(raw: str):
    return _TYPES.get(raw.lower().strip(), winreg.REG_SZ)


def _clean_path(path: str) -> str:
    p = path.strip().strip("\\/").replace("/", "\\")
    for prefix in ["HKEY_CURRENT_USER\\", "HKCU\\", "HKEY_LOCAL_MACHINE\\", "HKLM\\"]:
        if p.upper().startswith(prefix):
            p = p[len(prefix):]
            break
    return p


def backup_registry_key(hive_str: str, key_path: str) -> str:
    """Export a registry key to a .reg file in Temp for safe rollback."""
    clean = _clean_path(key_path)
    h_name = hive_str.upper()
    full_target = f"{h_name}\\{clean}"
    backup_dir = Path(tempfile.gettempdir()) / "jarvis_reg_backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = re_sub = "".join(c if c.isalnum() else "_" for c in clean)[-40:]
    out_file = backup_dir / f"reg_{safe_name}_{timestamp}.reg"

    try:
        subprocess.run(["reg.exe", "export", full_target, str(out_file), "/y"],
                       capture_output=True, timeout=10)
        return str(out_file)
    except Exception:
        return ""


def read_registry_value(hive_str: str, key_path: str, value_name: str = "") -> str:
    """Read a specific value from the Windows Registry."""
    hive = _get_hive(hive_str)
    clean = _clean_path(key_path)
    try:
        with winreg.OpenKey(hive, clean, 0, winreg.KEY_READ) as key:
            val, v_type = winreg.QueryValueEx(key, value_name)
            type_name = [k for k, v in _TYPES.items() if v == v_type and "reg_" in k]
            t_str = type_name[0].upper() if type_name else str(v_type)
            name_display = value_name if value_name else "(Default)"
            return f"{hive_str}\\{clean}\n  {name_display} = {val}  [{t_str}]"
    except FileNotFoundError:
        return f"Key or value not found: {hive_str}\\{clean} -> {value_name}"
    except PermissionError:
        return f"Permission denied accessing: {hive_str}\\{clean}. Administrator privileges may be required."
    except Exception as e:
        return f"Registry read error: {e}"


def list_registry_key(hive_str: str, key_path: str, max_items: int = 30) -> str:
    """List subkeys and values within a registry key."""
    hive = _get_hive(hive_str)
    clean = _clean_path(key_path)
    try:
        with winreg.OpenKey(hive, clean, 0, winreg.KEY_READ) as key:
            num_subkeys, num_values, _ = winreg.QueryInfoKey(key)

            lines = [f"Registry key: {hive_str}\\{clean}"]
            lines.append(f"Subkeys ({num_subkeys}):")
            for i in range(min(num_subkeys, max_items)):
                try:
                    lines.append(f"  📁 {winreg.EnumKey(key, i)}")
                except Exception:
                    break
            if num_subkeys > max_items:
                lines.append(f"  ... and {num_subkeys - max_items} more subkeys.")

            lines.append(f"Values ({num_values}):")
            for i in range(min(num_values, max_items)):
                try:
                    v_name, v_val, v_type = winreg.EnumValue(key, i)
                    v_disp = v_name if v_name else "(Default)"
                    lines.append(f"  • {v_disp} = {str(v_val)[:60]}")
                except Exception:
                    break
            if num_values > max_items:
                lines.append(f"  ... and {num_values - max_items} more values.")

            return "\n".join(lines)
    except FileNotFoundError:
        return f"Registry key not found: {hive_str}\\{clean}"
    except PermissionError:
        return f"Permission denied reading: {hive_str}\\{clean}."
    except Exception as e:
        return f"Registry list error: {e}"


def set_registry_value(
    hive_str: str,
    key_path: str,
    value_name: str,
    value: str | int,
    value_type: str = "string",
) -> str:
    """Set or create a registry value. Creates the key if it does not exist."""
    hive = _get_hive(hive_str)
    clean = _clean_path(key_path)
    v_type = _get_type(value_type)

    # Convert numeric values for DWORD
    if v_type == winreg.REG_DWORD:
        try:
            value = int(value)
        except ValueError:
            return f"Invalid integer value for DWORD: {value}"

    # Auto backup first
    backup_file = backup_registry_key(hive_str, clean)

    try:
        with winreg.CreateKeyEx(hive, clean, 0, winreg.KEY_SET_VALUE | winreg.KEY_WRITE) as key:
            winreg.SetValueEx(key, value_name, 0, v_type, value)
            backup_info = f" (Backup saved: {Path(backup_file).name})" if backup_file else ""
            return f"Successfully set {hive_str}\\{clean} -> {value_name or '(Default)'} = {value}{backup_info}"
    except PermissionError:
        return f"Permission denied writing to: {hive_str}\\{clean}. Please run JARVIS as Administrator."
    except Exception as e:
        return f"Failed to set registry value: {e}"


def delete_registry_value(
    hive_str: str,
    key_path: str,
    value_name: str,
    confirmed: bool = False,
) -> str:
    """Delete a specific registry value."""
    clean = _clean_path(key_path)

    def _execute_delete() -> str:
        hive = _get_hive(hive_str)
        backup_file = backup_registry_key(hive_str, clean)
        try:
            with winreg.OpenKey(hive, clean, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, value_name)
                b_str = f" (Backup: {Path(backup_file).name})" if backup_file else ""
                return f"Deleted value '{value_name}' from {hive_str}\\{clean}{b_str}."
        except Exception as ex:
            return f"Delete value error: {ex}"

    if confirmed:
        return _execute_delete()

    return confirm_gate.request(
        key=f"reg_del_val_{clean}_{value_name}",
        title=f"Delete Registry Value",
        detail=f"Delete registry value '{value_name}' at {hive_str}\\{clean}?",
        run=_execute_delete,
    )


def delete_registry_key(
    hive_str: str,
    key_path: str,
    confirmed: bool = False,
) -> str:
    """Delete a registry key (must have no subkeys in standard Win32)."""
    clean = _clean_path(key_path)

    def _execute_delete() -> str:
        hive = _get_hive(hive_str)
        backup_file = backup_registry_key(hive_str, clean)
        try:
            winreg.DeleteKey(hive, clean)
            b_str = f" (Backup: {Path(backup_file).name})" if backup_file else ""
            return f"Deleted registry key {hive_str}\\{clean}{b_str}."
        except Exception as ex:
            return f"Delete key error: {ex}"

    if confirmed:
        return _execute_delete()

    return confirm_gate.request(
        key=f"reg_del_key_{clean}",
        title=f"Delete Registry Key",
        detail=f"Delete registry key {hive_str}\\{clean} and all its settings?",
        run=_execute_delete,
    )


def registry_manager(
    parameters: dict = None,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    """Tool entrypoint for Windows Registry management."""
    params = parameters or {}
    action = params.get("action", "").lower().strip()
    hive   = params.get("hive", "HKCU").strip()
    path   = params.get("path", "") or params.get("key", "")
    name   = params.get("name", "") or params.get("value_name", "")
    value  = params.get("value", "")
    v_type = params.get("type", "string")
    confirmed = params.get("confirmed", False)

    if player:
        player.write_log(f"[registry] {action}: {hive}\\{path}")

    try:
        if action in ("read", "get"):
            return read_registry_value(hive, path, name)
        elif action in ("list", "query", "enum"):
            return list_registry_key(hive, path)
        elif action in ("set", "write", "create"):
            return set_registry_value(hive, path, name, value, value_type=v_type)
        elif action == "delete_value":
            return delete_registry_value(hive, path, name, confirmed=confirmed)
        elif action == "delete_key":
            return delete_registry_key(hive, path, confirmed=confirmed)
        elif action == "backup":
            f = backup_registry_key(hive, path)
            return f"Registry key exported to: {f}" if f else "Backup failed."
        else:
            return f"Unknown registry action: '{action}'. Available: read, list, set, delete_value, delete_key, backup."
    except Exception as e:
        return f"Registry manager error: {e}"
