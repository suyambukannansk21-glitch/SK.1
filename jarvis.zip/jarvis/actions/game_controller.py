"""
actions/game_controller.py — Pro-Gamer Gaming & Hardware Automation Controller.

Features:
- Windows DirectInput Hardware Scan-Code Injection (SendInput with KEYEVENTF_SCANCODE):
  Works inside DirectX, Unreal, Unity, and modern 3D games where standard virtual keys fail.
- 3D Relative Mouse Aiming & Camera Control:
  Relative mouse deltas (MOUSEEVENTF_MOVE) and smooth aiming curves for FPS / 3D titles.
- Pro Gaming Combos & Presets:
  WASD navigation, sprint-jumping, crouch-sliding, dodge-rolling, ability rotations, rapid fire.
- Autonomous Game Bot Loop:
  Background thread for continuous tasks (anti-AFK, auto-clicker, combat strafing, macro loops)
  with instant voice/hotkey cancellation.
- Game Vision:
  High-speed screen capture and AI situation analysis for tactical gameplay decisions.
"""
from __future__ import annotations

import sys as _sys
for _stream in ("stdout", "stderr"):
    try:
        _s = getattr(_sys, _stream, None)
        if _s is not None and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import io
import json
import math
import platform
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable

_OS = platform.system()

# ── Windows SendInput / Hardware Scan Code Structures ─────────────────────────
if _OS == "Windows":
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    PUL = ctypes.POINTER(ctypes.c_ulong)

    class KeyBdInput(ctypes.Structure):
        _fields_ = [
            ("wVk", ctypes.c_ushort),
            ("wScan", ctypes.c_ushort),
            ("dwFlags", ctypes.c_ulong),
            ("time", ctypes.c_ulong),
            ("dwExtraInfo", PUL),
        ]

    class HardwareInput(ctypes.Structure):
        _fields_ = [
            ("uMsg", ctypes.c_ulong),
            ("wParamL", ctypes.c_short),
            ("wParamH", ctypes.c_ushort),
        ]

    class MouseInput(ctypes.Structure):
        _fields_ = [
            ("dx", ctypes.c_long),
            ("dy", ctypes.c_long),
            ("mouseData", ctypes.c_ulong),
            ("dwFlags", ctypes.c_ulong),
            ("time", ctypes.c_ulong),
            ("dwExtraInfo", PUL),
        ]

    class Input_I(ctypes.Union):
        _fields_ = [
            ("ki", KeyBdInput),
            ("mi", MouseInput),
            ("hi", HardwareInput),
        ]

    class Input(ctypes.Structure):
        _fields_ = [
            ("type", ctypes.c_ulong),
            ("ii", Input_I),
        ]

    # Flags
    INPUT_MOUSE    = 0
    INPUT_KEYBOARD = 1

    KEYEVENTF_EXTENDEDKEY = 0x0001
    KEYEVENTF_KEYUP       = 0x0002
    KEYEVENTF_UNICODE     = 0x0004
    KEYEVENTF_SCANCODE    = 0x0008

    MOUSEEVENTF_MOVE       = 0x0001
    MOUSEEVENTF_LEFTDOWN   = 0x0002
    MOUSEEVENTF_LEFTUP     = 0x0004
    MOUSEEVENTF_RIGHTDOWN  = 0x0008
    MOUSEEVENTF_RIGHTUP    = 0x0010
    MOUSEEVENTF_MIDDLEDOWN = 0x0020
    MOUSEEVENTF_MIDDLEUP   = 0x0040
    MOUSEEVENTF_WHEEL      = 0x0800

# ── DirectInput Hardware Scancode Table ──────────────────────────────────────
# Standard Set 1 scancodes used by DirectX / PC games
SCANCODES: dict[str, int] = {
    # Letters
    "a": 0x1E, "b": 0x30, "c": 0x2E, "d": 0x20, "e": 0x12, "f": 0x21,
    "g": 0x22, "h": 0x23, "i": 0x17, "j": 0x24, "k": 0x25, "l": 0x26,
    "m": 0x32, "n": 0x31, "o": 0x18, "p": 0x19, "q": 0x10, "r": 0x13,
    "s": 0x1F, "t": 0x14, "u": 0x16, "v": 0x2F, "w": 0x11, "x": 0x2D,
    "y": 0x15, "z": 0x2C,
    # Numbers
    "1": 0x02, "2": 0x03, "3": 0x04, "4": 0x05, "5": 0x06,
    "6": 0x07, "7": 0x08, "8": 0x09, "9": 0x0A, "0": 0x0B,
    # Function Keys
    "f1": 0x3B, "f2": 0x3C, "f3": 0x3D, "f4": 0x3E, "f5": 0x3F, "f6": 0x40,
    "f7": 0x41, "f8": 0x42, "f9": 0x43, "f10": 0x44, "f11": 0x57, "f12": 0x58,
    # Control & Navigation
    "escape": 0x01, "esc": 0x01,
    "tab": 0x0F,
    "caps": 0x3A, "capslock": 0x3A,
    "shift": 0x2A, "lshift": 0x2A, "rshift": 0x36,
    "ctrl": 0x1D, "lctrl": 0x1D, "rctrl": 0x1D,
    "alt": 0x38, "lalt": 0x38, "ralt": 0x38,
    "space": 0x39,
    "enter": 0x1C, "return": 0x1C,
    "backspace": 0x0E,
    # Arrows (Extended)
    "up": 0x48, "down": 0x50, "left": 0x4B, "right": 0x4D,
    # Common symbols
    "`": 0x29, "-": 0x0C, "=": 0x0D, "[": 0x1A, "]": 0x1B,
    "\\": 0x2B, ";": 0x27, "'": 0x28, ",": 0x33, ".": 0x34, "/": 0x35,
}

_EXTENDED_KEYS = {"up", "down", "left", "right", "insert", "delete", "home", "end", "pageup", "pagedown"}

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.01
    _PYAUTOGUI = True
except ImportError:
    _PYAUTOGUI = False


def _get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


def _get_api_key() -> str:
    path = _get_base_dir() / "config" / "api_keys.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("gemini_api_key", "")
    except Exception:
        return ""


# ── DirectInput Low-Level Keyboard Implementation ────────────────────────────

def _resolve_scancode(key: str) -> tuple[int, bool]:
    """Resolve key name to (scancode, is_extended)."""
    k = key.lower().strip()
    is_ext = k in _EXTENDED_KEYS
    if k in SCANCODES:
        return SCANCODES[k], is_ext

    # Fallback to Windows MapVirtualKey if available
    if _OS == "Windows":
        try:
            vk = user32.VkKeyScanW(ord(k[0])) & 0xFF
            scan = user32.MapVirtualKeyW(vk, 0)
            if scan:
                return scan, is_ext
        except Exception:
            pass

    return 0, False


def direct_key_down(key: str) -> bool:
    """Press and hold a keyboard key using DirectInput scan codes."""
    if _OS == "Windows":
        scan, is_ext = _resolve_scancode(key)
        if scan:
            flags = KEYEVENTF_SCANCODE
            if is_ext:
                flags |= KEYEVENTF_EXTENDEDKEY
            extra = ctypes.c_ulong(0)
            ii = Input_I()
            ii.ki = KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))
            x = Input(ctypes.c_ulong(INPUT_KEYBOARD), ii)
            user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
            return True

    if _PYAUTOGUI:
        pyautogui.keyDown(key)
        return True
    return False


def direct_key_up(key: str) -> bool:
    """Release a held keyboard key using DirectInput scan codes."""
    if _OS == "Windows":
        scan, is_ext = _resolve_scancode(key)
        if scan:
            flags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP
            if is_ext:
                flags |= KEYEVENTF_EXTENDEDKEY
            extra = ctypes.c_ulong(0)
            ii = Input_I()
            ii.ki = KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))
            x = Input(ctypes.c_ulong(INPUT_KEYBOARD), ii)
            user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
            return True

    if _PYAUTOGUI:
        pyautogui.keyUp(key)
        return True
    return False


def direct_press_key(key: str, hold_seconds: float = 0.05) -> bool:
    """Press and release a key with game-ready tick duration."""
    direct_key_down(key)
    time.sleep(max(0.02, hold_seconds))
    direct_key_up(key)
    return True


def direct_hold_key(key: str, seconds: float = 1.0) -> bool:
    """Hold key down for a specified duration (e.g. running forward)."""
    direct_key_down(key)
    time.sleep(max(0.05, seconds))
    direct_key_up(key)
    return True


# ── 3D Relative Mouse Aiming & Camera Control ────────────────────────────────

def direct_aim_relative(dx: int, dy: int) -> str:
    """
    Move mouse by relative delta (dx, dy).
    Crucial for 3D camera rotation in FPS/action games where cursor is locked.
    """
    if _OS == "Windows":
        user32.mouse_event(MOUSEEVENTF_MOVE, int(dx), int(dy), 0, 0)
        return f"Aimed relative ({dx:+d}, {dy:+d})"
    if _PYAUTOGUI:
        pyautogui.moveRel(dx, dy)
        return f"Moved relative ({dx:+d}, {dy:+d})"
    return "Mouse relative move unsupported"


def direct_smooth_aim(dx: int, dy: int, duration: float = 0.15, steps: int = 10) -> str:
    """
    Smoothly interpolate camera movement across multiple steps for natural, human-like flicking.
    """
    steps = max(1, steps)
    step_dx = dx / steps
    step_dy = dy / steps
    step_delay = duration / steps

    for _ in range(steps):
        if _OS == "Windows":
            user32.mouse_event(MOUSEEVENTF_MOVE, int(step_dx), int(step_dy), 0, 0)
        elif _PYAUTOGUI:
            pyautogui.moveRel(int(step_dx), int(step_dy))
        time.sleep(step_delay)

    return f"Smooth aimed ({dx:+d}, {dy:+d}) over {duration:.2f}s"


def direct_mouse_down(button: str = "left") -> bool:
    btn = button.lower()
    if _OS == "Windows":
        flags = MOUSEEVENTF_LEFTDOWN if btn == "left" else (
            MOUSEEVENTF_RIGHTDOWN if btn == "right" else MOUSEEVENTF_MIDDLEDOWN
        )
        user32.mouse_event(flags, 0, 0, 0, 0)
        return True
    if _PYAUTOGUI:
        pyautogui.mouseDown(button=btn)
        return True
    return False


def direct_mouse_up(button: str = "left") -> bool:
    btn = button.lower()
    if _OS == "Windows":
        flags = MOUSEEVENTF_LEFTUP if btn == "left" else (
            MOUSEEVENTF_RIGHTUP if btn == "right" else MOUSEEVENTF_MIDDLEUP
        )
        user32.mouse_event(flags, 0, 0, 0, 0)
        return True
    if _PYAUTOGUI:
        pyautogui.mouseUp(button=btn)
        return True
    return False


def direct_hold_mouse(button: str = "left", seconds: float = 0.5) -> str:
    direct_mouse_down(button)
    time.sleep(max(0.05, seconds))
    direct_mouse_up(button)
    return f"Held {button} mouse button for {seconds}s"


def direct_rapid_click(button: str = "left", count: int = 10, cps: int = 12) -> str:
    """Rapidly click at a target clicks-per-second (CPS) rate."""
    interval = max(0.02, 1.0 / max(1, cps))
    for _ in range(count):
        direct_mouse_down(button)
        time.sleep(interval / 2)
        direct_mouse_up(button)
        time.sleep(interval / 2)
    return f"Rapid-clicked {button} {count} times at {cps} CPS"


# ── Pro-Gamer Movement Combos & Presets ───────────────────────────────────────

def combo_sprint(seconds: float = 2.0) -> str:
    """Hold Shift + W to sprint forward."""
    direct_key_down("shift")
    direct_key_down("w")
    time.sleep(seconds)
    direct_key_up("w")
    direct_key_up("shift")
    return f"Sprinted forward for {seconds}s"


def combo_sprint_jump() -> str:
    """Sprint forward, jump, and maintain forward momentum."""
    direct_key_down("shift")
    direct_key_down("w")
    time.sleep(0.3)
    direct_press_key("space", 0.08)
    time.sleep(0.5)
    direct_key_up("w")
    direct_key_up("shift")
    return "Executed sprint-jump combo"


def combo_crouch_slide() -> str:
    """Sprint into a crouch-slide, then jump back up."""
    direct_key_down("shift")
    direct_key_down("w")
    time.sleep(0.4)
    direct_press_key("c", 0.1)  # Slide
    time.sleep(0.3)
    direct_press_key("space", 0.08)  # Jump cancel
    direct_key_up("w")
    direct_key_up("shift")
    return "Executed slide-jump cancel"


def combo_dodge(direction: str = "left") -> str:
    """Execute quick evasive dodge in a direction."""
    d = direction.lower()
    key = "a" if d == "left" else ("d" if d == "right" else ("s" if d == "back" else "w"))
    direct_key_down(key)
    direct_press_key("space", 0.08)
    time.sleep(0.2)
    direct_key_up(key)
    return f"Dodged {direction}"


def combo_wasd_move(direction: str = "w", seconds: float = 1.0) -> str:
    """Walk in a direction for N seconds."""
    key = direction.lower().strip()
    if key not in ("w", "a", "s", "d"):
        key = "w"
    direct_hold_key(key, seconds)
    return f"Moved {key.upper()} for {seconds}s"


def combo_shoot(shots: int = 1, ads: bool = False) -> str:
    """Shoot N times, optionally aiming down sights (ADS) first."""
    if ads:
        direct_mouse_down("right")
        time.sleep(0.15)
    for _ in range(shots):
        direct_mouse_down("left")
        time.sleep(0.08)
        direct_mouse_up("left")
        time.sleep(0.1)
    if ads:
        time.sleep(0.05)
        direct_mouse_up("right")
    return f"Fired {shots} shot(s){' with ADS' if ads else ''}"


def combo_ability(key: str = "q", wait_after: float = 0.2) -> str:
    """Cast an in-game ability with tick-guaranteed execution."""
    direct_press_key(key, 0.08)
    time.sleep(wait_after)
    return f"Used ability [{key.upper()}]"


def execute_macro(steps: list[dict[str, Any]]) -> str:
    """
    Execute a structured sequence of game inputs with millisecond precision.
    Each step: {"action": ..., ...}
    Supported step actions:
      - key_down: {"action": "key_down", "key": "w"}
      - key_up: {"action": "key_up", "key": "w"}
      - press: {"action": "press", "key": "space", "hold": 0.05}
      - aim: {"action": "aim", "dx": 100, "dy": 0}
      - click: {"action": "click", "button": "left"}
      - mouse_down / mouse_up
      - wait: {"action": "wait", "seconds": 0.2}
    """
    count = 0
    for step in steps:
        act = step.get("action", "").lower()
        if act == "key_down":
            direct_key_down(step.get("key", "w"))
        elif act == "key_up":
            direct_key_up(step.get("key", "w"))
        elif act == "press":
            direct_press_key(step.get("key", "w"), float(step.get("hold", 0.05)))
        elif act == "aim":
            direct_aim_relative(int(step.get("dx", 0)), int(step.get("dy", 0)))
        elif act == "click":
            btn = step.get("button", "left")
            direct_mouse_down(btn)
            time.sleep(0.05)
            direct_mouse_up(btn)
        elif act == "mouse_down":
            direct_mouse_down(step.get("button", "left"))
        elif act == "mouse_up":
            direct_mouse_up(step.get("button", "left"))
        elif act == "wait":
            time.sleep(float(step.get("seconds", 0.1)))
        count += 1
    return f"Macro executed ({count} steps)"


# ── Autonomous Game Bot Engine ───────────────────────────────────────────────

class _GameBot:
    """Background autonomous bot with instant cancellation."""

    def __init__(self):
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._mode = "idle"
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self, mode: str, kwargs: dict[str, Any]) -> str:
        with self._lock:
            if self.is_running:
                return f"Bot is already active in mode: '{self._mode}'. Stop it first."

            self._stop_event.clear()
            self._mode = mode.lower().strip()

            target_fn = self._get_bot_worker(self._mode, kwargs)
            if not target_fn:
                return f"Unknown bot mode: '{self._mode}'. Available: afk_anti_kick | auto_clicker | combat_strafe | custom_loop"

            self._thread = threading.Thread(target=target_fn, daemon=True)
            self._thread.start()
            return f"Started game bot in mode: '{self._mode}' (say 'stop gaming' or call stop_bot anytime to cancel)."

    def stop(self) -> str:
        with self._lock:
            if not self.is_running:
                return "No game bot is currently running."
            self._stop_event.set()
            # Release any pressed keys
            for k in ("w", "a", "s", "d", "shift", "ctrl", "space"):
                try:
                    direct_key_up(k)
                except Exception:
                    pass
            try:
                direct_mouse_up("left")
                direct_mouse_up("right")
            except Exception:
                pass
            self._mode = "idle"
            return "Game bot stopped immediately."

    def status(self) -> str:
        if self.is_running:
            return f"Game bot active: mode='{self._mode}'"
        return "Game bot is idle."

    def _get_bot_worker(self, mode: str, kwargs: dict[str, Any]) -> Callable[[], None] | None:
        if mode == "afk_anti_kick":
            interval = float(kwargs.get("interval", 25.0))
            return lambda: self._worker_afk(interval)
        if mode == "auto_clicker":
            cps = int(kwargs.get("cps", 10))
            btn = kwargs.get("button", "left")
            return lambda: self._worker_clicker(cps, btn)
        if mode == "combat_strafe":
            return lambda: self._worker_combat_strafe()
        if mode == "custom_loop":
            macro_steps = kwargs.get("steps", [])
            repeat = int(kwargs.get("repeat", 100))
            return lambda: self._worker_custom_loop(macro_steps, repeat)
        return None

    def _worker_afk(self, interval: float):
        """Periodically moves, looks, and jumps to prevent being AFK kicked."""
        while not self._stop_event.is_set():
            # Small strafe
            direct_hold_key("w", 0.4)
            time.sleep(0.1)
            direct_press_key("space", 0.08)
            direct_aim_relative(30, 0)
            time.sleep(0.5)
            direct_aim_relative(-30, 0)
            # Wait for interval or stop
            if self._stop_event.wait(timeout=interval):
                break

    def _worker_clicker(self, cps: int, button: str):
        """Continuous auto-clicker."""
        delay = max(0.01, 1.0 / max(1, cps))
        while not self._stop_event.is_set():
            direct_mouse_down(button)
            time.sleep(delay / 2)
            direct_mouse_up(button)
            time.sleep(delay / 2)

    def _worker_combat_strafe(self):
        """Strafes back and forth while periodically firing and adjusting aim."""
        while not self._stop_event.is_set():
            # Strafe left
            direct_key_down("a")
            time.sleep(0.4)
            direct_key_up("a")
            # Fire burst
            combo_shoot(shots=2, ads=False)
            if self._stop_event.is_set():
                break
            # Strafe right
            direct_key_down("d")
            time.sleep(0.4)
            direct_key_up("d")
            combo_shoot(shots=2, ads=False)
            time.sleep(0.2)

    def _worker_custom_loop(self, steps: list[dict], repeat: int):
        for _ in range(repeat):
            if self._stop_event.is_set():
                break
            execute_macro(steps)
            time.sleep(0.1)


_GLOBAL_BOT = _GameBot()


# ── Game Vision & Window Management ──────────────────────────────────────────

def focus_game_window(title: str) -> str:
    """Bring the game window to the foreground."""
    if _OS == "Windows":
        try:
            ps_script = f"""
            $proc = Get-Process | Where-Object {{ $_.MainWindowTitle -like '*{title}*' }} | Select-Object -First 1
            if ($proc) {{
                (New-Object -ComObject WScript.Shell).AppActivate($proc.Id)
                'OK'
            }} else {{
                'NOT_FOUND'
            }}
            """
            res = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
                capture_output=True, text=True, timeout=5,
            )
            if "OK" in res.stdout:
                time.sleep(0.3)
                return f"Focused game window matching '{title}'"
            return f"Game window '{title}' not found in active processes."
        except Exception as e:
            return f"Failed to focus game: {e}"
    return f"Window focusing not supported on {_OS}"


def analyze_game_screen(prompt: str = "Analyze the gameplay screen. Identify enemies, crosshair position, health status, and optimal next action.") -> str:
    """Capture current game frame and analyze with Gemini."""
    api_key = _get_api_key()
    if not api_key:
        return "No API key configured for game analysis."

    try:
        from google import genai
        from google.genai import types as gtypes

        if not _PYAUTOGUI:
            return "Screen capture requires pyautogui."

        img = pyautogui.screenshot()
        # Resize to 720p for low latency
        img = img.resize((1280, 720))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=85)
        img_bytes = buf.getvalue()

        client = genai.Client(api_key=api_key)
        resp = client.models.generate_content(
            model="gemini-flash-latest",
            contents=[
                gtypes.Part.from_bytes(data=img_bytes, mime_type="image/jpeg"),
                f"You are a professional gamer AI companion. {prompt}\nBe tactical, precise, and concise.",
            ],
        )
        return resp.text or "No response from game vision analysis."
    except Exception as e:
        return f"Game screen analysis error: {e}"


# ── Public Action Dispatcher ─────────────────────────────────────────────────

def game_controller(parameters: dict, player=None) -> str:
    """
    Main dispatch table for all pro-gamer and game automation commands.
    """
    params = parameters or {}
    action = params.get("action", "").lower().strip()

    if not action:
        return "No action specified for game_controller."

    if player and hasattr(player, "write_log"):
        player.write_log(f"[Gamer] {action}")

    print(f"[GameController] [>] {action} {params}")

    try:
        # Keyboard low-level DirectInput
        if action == "key_down":
            key = params.get("key", "w")
            ok = direct_key_down(key)
            return f"Key '{key}' DOWN" if ok else f"Failed to press {key}"

        if action == "key_up":
            key = params.get("key", "w")
            ok = direct_key_up(key)
            return f"Key '{key}' UP" if ok else f"Failed to release {key}"

        if action in ("hold_key", "hold"):
            key = params.get("key", "w")
            sec = float(params.get("seconds", params.get("duration", 1.0)))
            direct_hold_key(key, sec)
            return f"Held key '{key}' for {sec}s"

        if action in ("press", "tap"):
            key = params.get("key", "space")
            sec = float(params.get("hold", 0.05))
            direct_press_key(key, sec)
            return f"Pressed key '{key}'"

        # Mouse aiming & shooting
        if action in ("aim", "aim_relative"):
            dx = int(params.get("dx", 0))
            dy = int(params.get("dy", 0))
            return direct_aim_relative(dx, dy)

        if action == "smooth_aim":
            dx = int(params.get("dx", 0))
            dy = int(params.get("dy", 0))
            dur = float(params.get("duration", 0.15))
            steps = int(params.get("steps", 10))
            return direct_smooth_aim(dx, dy, dur, steps)

        if action == "mouse_down":
            btn = params.get("button", "left")
            direct_mouse_down(btn)
            return f"Mouse {btn} DOWN"

        if action == "mouse_up":
            btn = params.get("button", "left")
            direct_mouse_up(btn)
            return f"Mouse {btn} UP"

        if action == "hold_mouse":
            btn = params.get("button", "left")
            sec = float(params.get("seconds", params.get("duration", 0.5)))
            return direct_hold_mouse(btn, sec)

        if action in ("rapid_click", "auto_click"):
            btn = params.get("button", "left")
            count = int(params.get("count", 10))
            cps = int(params.get("cps", 12))
            return direct_rapid_click(btn, count, cps)

        # Pro-gamer movement & actions
        if action == "sprint":
            sec = float(params.get("seconds", params.get("duration", 2.0)))
            return combo_sprint(sec)

        if action == "sprint_jump":
            return combo_sprint_jump()

        if action in ("crouch_slide", "slide_jump"):
            return combo_crouch_slide()

        if action == "dodge":
            direction = params.get("direction", "left")
            return combo_dodge(direction)

        if action in ("wasd", "walk", "move"):
            d = params.get("direction", params.get("key", "w"))
            sec = float(params.get("seconds", params.get("duration", 1.0)))
            return combo_wasd_move(d, sec)

        if action in ("shoot", "fire"):
            shots = int(params.get("shots", 1))
            ads = bool(params.get("ads", False))
            return combo_shoot(shots, ads)

        if action == "reload":
            direct_press_key("r", 0.08)
            return "Reloaded weapon [R]"

        if action == "ability":
            key = params.get("key", "q")
            return combo_ability(key)

        if action == "macro":
            steps = params.get("steps", [])
            if isinstance(steps, str):
                steps = json.loads(steps)
            return execute_macro(steps)

        # Autonomous bot management
        if action in ("start_bot", "play_game", "auto_play"):
            mode = params.get("mode", "afk_anti_kick")
            return _GLOBAL_BOT.start(mode, params)

        if action in ("stop_bot", "stop_game", "stop"):
            return _GLOBAL_BOT.stop()

        if action == "bot_status":
            return _GLOBAL_BOT.status()

        # Window & Vision
        if action == "focus_game":
            title = params.get("title", params.get("game_name", ""))
            return focus_game_window(title)

        if action in ("analyze_screen", "game_analyze", "vision"):
            prompt = params.get("prompt", "Analyze the current game screen, targets, and objectives.")
            return analyze_game_screen(prompt)

        return f"Unknown game_controller action: '{action}'"

    except Exception as e:
        print(f"[GameController] [!] {action}: {e}")
        return f"game_controller '{action}' failed: {e}"
