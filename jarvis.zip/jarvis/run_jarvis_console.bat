@echo off
cd /d "%~dp0"
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo JARVIS exited with an error code: %ERRORLEVEL%
    pause
)
