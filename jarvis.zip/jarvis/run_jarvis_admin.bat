@echo off
:: run_jarvis_admin.bat — Launch JARVIS with full Administrator privileges

cd /d "%~dp0"

:: Test for Administrator rights
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [JARVIS] Running with full Administrator privileges 🛡️
    python main.py
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo JARVIS exited with error code: %ERRORLEVEL%
        pause
    )
) else (
    echo [JARVIS] Requesting Administrator elevation...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)
