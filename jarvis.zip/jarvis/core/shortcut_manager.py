from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path

_OS = platform.system()


def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_base_dir()
ICON_PATH = BASE_DIR / "config" / "jarvis.ico"
SCRIPT_PATH = BASE_DIR / "main.py"


def get_desktop_dir() -> Path:
    """
    Resolve the user's real active Desktop directory.
    Handles OneDrive folder redirection on Windows (e.g. C:/Users/.../OneDrive/Desktop)
    and localized XDG user dirs on Linux.
    """
    home = Path.home()

    if _OS == "Windows":
        # 1) Try win32com WScript.Shell SpecialFolders
        try:
            import win32com.client  # type: ignore

            shell = win32com.client.Dispatch("WScript.Shell")
            desk = shell.SpecialFolders("Desktop")
            if desk and Path(desk).is_dir():
                return Path(desk)
        except Exception:
            pass

        # 2) SHGetKnownFolderPath (FOLDERID_Desktop {B4BFCC3A-DB2C-424C-B029-7FE99A87C641})
        try:
            import ctypes
            from ctypes import wintypes

            class _GUID(ctypes.Structure):
                _fields_ = [
                    ("Data1", wintypes.DWORD),
                    ("Data2", wintypes.WORD),
                    ("Data3", wintypes.WORD),
                    ("Data4", ctypes.c_ubyte * 8),
                ]

            fid = _GUID(
                0xB4BFCC3A,
                0xDB2C,
                0x424C,
                (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41),
            )
            buf = ctypes.c_wchar_p()
            if (
                ctypes.windll.shell32.SHGetKnownFolderPath(
                    ctypes.byref(fid), 0, None, ctypes.byref(buf)
                )
                == 0
            ):
                p = Path(buf.value)
                ctypes.windll.ole32.CoTaskMemFree(buf)
                if p.is_dir():
                    return p
        except Exception:
            pass

        # 3) Registry: User Shell Folders
        try:
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
            ) as key:
                val, _ = winreg.QueryValueEx(key, "Desktop")
            p = Path(os.path.expandvars(val))
            if p.is_dir():
                return p
        except Exception:
            pass

    elif _OS == "Linux":
        try:
            out = subprocess.run(
                ["xdg-user-dir", "DESKTOP"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            p = Path(out.stdout.strip())
            if out.stdout.strip() and p != home and p.is_dir():
                return p
        except Exception:
            pass
        try:
            cfg = home / ".config" / "user-dirs.dirs"
            if cfg.exists():
                for line in cfg.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("XDG_DESKTOP_DIR"):
                        val = line.split("=", 1)[1].strip().strip('"')
                        p = Path(val.replace("$HOME", str(home)))
                        if p != home and p.is_dir():
                            return p
        except Exception:
            pass

    # Standard fallback
    return home / "Desktop"


def _create_lnk_windows(
    lnk_path: Path, target: str, args: str, work_dir: str, icon_loc: str
) -> None:
    """Create a Windows .lnk shortcut without opening a console window."""
    # Method 1: pywin32 COM
    try:
        import win32com.client  # type: ignore

        shell = win32com.client.Dispatch("WScript.Shell")
        sc = shell.CreateShortCut(str(lnk_path))
        sc.TargetPath = target
        sc.Arguments = f'"{args}"'
        sc.WorkingDirectory = work_dir
        sc.Description = "J.A.R.V.I.S — Voice AI Assistant"
        sc.IconLocation = icon_loc
        sc.Save()
        return
    except Exception:
        pass

    # Method 2: wscript.exe + temporary VBScript
    import tempfile

    vbs_content = "\n".join(
        [
            'Set ws = CreateObject("WScript.Shell")',
            f'Set sc = ws.CreateShortcut("{lnk_path}")',
            f'sc.TargetPath = "{target}"',
            f'sc.Arguments = Chr(34) & "{args}" & Chr(34)',
            f'sc.WorkingDirectory = "{work_dir}"',
            'sc.Description = "J.A.R.V.I.S — Voice AI Assistant"',
            f'sc.IconLocation = "{icon_loc}"',
            "sc.Save",
        ]
    )
    fd, tmp_file = tempfile.mkstemp(suffix=".vbs")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(vbs_content)
        proc = subprocess.Popen(
            ["wscript.exe", "/nologo", tmp_file],
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        proc.wait(timeout=10)
    finally:
        try:
            os.unlink(tmp_file)
        except Exception:
            pass

    if lnk_path.exists():
        return

    # Method 3: PowerShell fallback
    ps_cmd = (
        f"$ws = New-Object -ComObject WScript.Shell; "
        f"$s = $ws.CreateShortcut('{lnk_path}'); "
        f"$s.TargetPath = '{target}'; "
        f"$s.Arguments = '\"{args}\"'; "
        f"$s.WorkingDirectory = '{work_dir}'; "
        f"$s.IconLocation = '{icon_loc}'; "
        f"$s.Save()"
    )
    subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
        creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        check=True,
        timeout=10,
    )


def create_desktop_shortcut() -> tuple[bool, str]:
    """
    Create a desktop shortcut on Windows / macOS / Linux.
    Returns (success: bool, message: str).
    """
    desktop = get_desktop_dir()
    if not desktop.exists():
        try:
            desktop.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return False, f"Desktop directory not found: {e}"

    python_exe = Path(sys.executable)
    icon_loc = str(ICON_PATH) if ICON_PATH.exists() else f"{python_exe},0"

    try:
        if _OS == "Windows":
            pythonw = python_exe.parent / "pythonw.exe"
            target = str(pythonw if pythonw.exists() else python_exe)
            lnk = desktop / "J.A.R.V.I.S.lnk"

            _create_lnk_windows(
                lnk,
                target=target,
                args=str(SCRIPT_PATH),
                work_dir=str(BASE_DIR),
                icon_loc=icon_loc,
            )

            # If user has a secondary desktop directory (e.g. OneDrive Desktop vs Local Desktop), copy there too
            local_desktop = Path.home() / "Desktop"
            if local_desktop.exists() and local_desktop.resolve() != desktop.resolve():
                try:
                    import shutil
                    shutil.copy2(lnk, local_desktop / "J.A.R.V.I.S.lnk")
                except Exception:
                    pass

            return True, f"Desktop shortcut created at {lnk.name}"

        elif _OS == "Darwin":
            import stat

            app_bundle = desktop / "J.A.R.V.I.S.app"
            mac_bin_dir = app_bundle / "Contents" / "MacOS"
            mac_res_dir = app_bundle / "Contents" / "Resources"
            mac_bin_dir.mkdir(parents=True, exist_ok=True)
            mac_res_dir.mkdir(exist_ok=True)

            launcher = mac_bin_dir / "JARVIS"
            launcher.write_text(
                f"#!/usr/bin/env bash\ncd \"{BASE_DIR}\"\nexec \"{python_exe}\" \"{SCRIPT_PATH}\"\n",
                encoding="utf-8",
            )
            launcher.chmod(launcher.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

            (app_bundle / "Contents" / "Info.plist").write_text(
                '<?xml version="1.0" encoding="UTF-8"?>\n'
                '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                '<plist version="1.0"><dict>\n'
                '  <key>CFBundleExecutable</key><string>JARVIS</string>\n'
                '  <key>CFBundleIdentifier</key><string>com.jarvis.assistant</string>\n'
                '  <key>CFBundleName</key><string>J.A.R.V.I.S</string>\n'
                '  <key>CFBundlePackageType</key><string>APPL</string>\n'
                '  <key>CFBundleVersion</key><string>1.0</string>\n'
                '</dict></plist>\n',
                encoding="utf-8",
            )
            return True, "macOS desktop app bundle created."

        else:
            # Linux
            desk_file = desktop / "J.A.R.V.I.S.desktop"
            icon_line = f"Icon={ICON_PATH}\n" if ICON_PATH.exists() else ""
            desk_file.write_text(
                "[Desktop Entry]\n"
                "Name=J.A.R.V.I.S\n"
                f"Exec={python_exe} {SCRIPT_PATH}\n"
                f"Path={BASE_DIR}\n"
                "Type=Application\n"
                "Terminal=false\n"
                "Categories=Utility;\n"
                + icon_line,
                encoding="utf-8",
            )
            desk_file.chmod(desk_file.stat().st_mode | 0o755)
            return True, "Linux desktop launcher created."

    except Exception as e:
        return False, str(e)


def is_autostart_enabled() -> bool:
    """Check if autostart on system boot is enabled."""
    try:
        if _OS == "Windows":
            import winreg

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_READ,
            )
            try:
                winreg.QueryValueEx(key, "JARVIS_AI")
                return True
            except FileNotFoundError:
                return False
            finally:
                winreg.CloseKey(key)

        elif _OS == "Darwin":
            plist = Path.home() / "Library" / "LaunchAgents" / "com.jarvis.assistant.plist"
            return plist.exists()

        else:
            desk = Path.home() / ".config" / "autostart" / "jarvis.desktop"
            return desk.exists()

    except Exception:
        return False


def toggle_autostart() -> tuple[bool, str]:
    """Toggle autostart on system boot ON/OFF. Returns (ok, message)."""
    currently_on = is_autostart_enabled()
    try:
        if _OS == "Windows":
            import winreg

            reg = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_ALL_ACCESS,
            )
            try:
                if currently_on:
                    winreg.DeleteValue(reg, "JARVIS_AI")
                    return True, "Auto-start disabled."
                else:
                    pythonw = Path(sys.executable).parent / "pythonw.exe"
                    exe = str(pythonw if pythonw.exists() else sys.executable)
                    winreg.SetValueEx(
                        reg,
                        "JARVIS_AI",
                        0,
                        winreg.REG_SZ,
                        f'"{exe}" "{SCRIPT_PATH}"',
                    )
                    return True, "Auto-start enabled."
            finally:
                winreg.CloseKey(reg)

        elif _OS == "Darwin":
            plist_dir = Path.home() / "Library" / "LaunchAgents"
            plist_dir.mkdir(parents=True, exist_ok=True)
            plist = plist_dir / "com.jarvis.assistant.plist"
            if currently_on:
                plist.unlink(missing_ok=True)
                return True, "Auto-start disabled."
            else:
                plist.write_text(
                    '<?xml version="1.0" encoding="UTF-8"?>\n'
                    '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                    '<plist version="1.0"><dict>\n'
                    '  <key>Label</key><string>com.jarvis.assistant</string>\n'
                    '  <key>ProgramArguments</key><array>\n'
                    f'    <string>{sys.executable}</string>\n'
                    f'    <string>{SCRIPT_PATH}</string>\n'
                    '  </array>\n'
                    '  <key>RunAtLoad</key><true/>\n'
                    '</dict></plist>\n',
                    encoding="utf-8",
                )
                return True, "Auto-start enabled."

        else:
            desk_dir = Path.home() / ".config" / "autostart"
            desk_dir.mkdir(parents=True, exist_ok=True)
            desk = desk_dir / "jarvis.desktop"
            if currently_on:
                desk.unlink(missing_ok=True)
                return True, "Auto-start disabled."
            else:
                desk.write_text(
                    "[Desktop Entry]\n"
                    "Name=J.A.R.V.I.S\n"
                    f"Exec={sys.executable} {SCRIPT_PATH}\n"
                    "Type=Application\n"
                    "Terminal=false\n"
                    "X-GNOME-Autostart-enabled=true\n",
                    encoding="utf-8",
                )
                return True, "Auto-start enabled."

    except Exception as e:
        return False, f"Failed to toggle auto-start: {e}"
