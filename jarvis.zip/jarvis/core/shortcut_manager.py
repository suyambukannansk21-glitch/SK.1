"""
core/shortcut_manager.py — Desktop shortcut and auto-start management.

Handles Windows (with OneDrive Desktop redirection support), Linux, and macOS.
"""
from __future__ import annotations

import os
import sys
import platform
import subprocess
from pathlib import Path

_OS = platform.system()


def get_base_dir() -> Path:
    """Return the root directory of the JARVIS project."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


def get_desktop_paths() -> list[Path]:
    """
    Return all valid Desktop folder paths on the system.
    Handles OneDrive folder redirection on Windows.
    """
    paths: list[Path] = []

    if _OS == "Windows":
        # 1. SHGetFolderPathW (CSIDL_DESKTOPDIRECTORY = 0x0010)
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf)
            p = Path(buf.value)
            if p.exists() and p not in paths:
                paths.append(p)
        except Exception:
            pass

        # 2. Windows Registry: User Shell Folders -> Desktop
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
            )
            val, _ = winreg.QueryValueEx(key, "Desktop")
            expanded = Path(os.path.expandvars(val))
            if expanded.exists() and expanded not in paths:
                paths.append(expanded)
        except Exception:
            pass

        # 3. WScript.Shell SpecialFolders
        try:
            import win32com.client
            shell = win32com.client.Dispatch("WScript.Shell")
            desk = shell.SpecialFolders("Desktop")
            if desk:
                p = Path(desk)
                if p.exists() and p not in paths:
                    paths.append(p)
        except Exception:
            pass

        # 4. Standard user profile desktop fallback
        home_desk = Path.home() / "Desktop"
        if home_desk.exists() and home_desk not in paths:
            paths.append(home_desk)

    elif _OS == "Linux":
        xdg = os.environ.get("XDG_DESKTOP_DIR", "")
        if xdg and Path(xdg).exists():
            paths.append(Path(xdg))
        home_desk = Path.home() / "Desktop"
        if home_desk.exists() and home_desk not in paths:
            paths.append(home_desk)

    elif _OS == "Darwin":
        home_desk = Path.home() / "Desktop"
        if home_desk.exists():
            paths.append(home_desk)

    # Fallback to home/Desktop even if it doesn't exist yet
    if not paths:
        paths.append(Path.home() / "Desktop")

    return paths


def _get_target_executable() -> Path:
    """Return pythonw.exe if available (to prevent console pop-up), else python.exe."""
    exe = Path(sys.executable)
    if _OS == "Windows":
        pythonw = exe.parent / "pythonw.exe"
        if pythonw.exists():
            return pythonw
    return exe


def create_desktop_shortcut() -> tuple[bool, str]:
    """
    Create a desktop shortcut for JARVIS on the current user's desktop.
    Returns (success, message).
    """
    base_dir = get_base_dir()
    main_py = base_dir / "main.py"
    icon_path = base_dir / "config" / "jarvis.ico"
    target_exe = _get_target_executable()

    if not main_py.exists():
        return False, f"main.py not found at {main_py}"

    desktop_dirs = get_desktop_paths()
    if not desktop_dirs:
        return False, "Could not determine Desktop directory"

    created_at: list[str] = []

    if _OS == "Windows":
        for desk in desktop_dirs:
            lnk_path = desk / "JARVIS.lnk"
            ok = _create_windows_lnk(
                shortcut_path=lnk_path,
                target_exe=target_exe,
                arguments=f'"{main_py}"',
                work_dir=base_dir,
                icon_path=icon_path if icon_path.exists() else None,
            )
            if ok:
                created_at.append(str(lnk_path))

        if created_at:
            return True, f"Shortcut created at {', '.join(created_at)}"
        return False, "Failed to create Windows shortcut (.lnk)"

    elif _OS == "Linux":
        entry = (
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=JARVIS\n"
            "Comment=JARVIS AI Assistant\n"
            f"Exec=\"{target_exe}\" \"{main_py}\"\n"
            f"Path={base_dir}\n"
            "Terminal=false\n"
            "Categories=Utility;Application;\n"
        )
        if icon_path.exists():
            entry += f"Icon={icon_path}\n"

        for desk in desktop_dirs:
            desk_file = desk / "jarvis.desktop"
            try:
                desk_file.write_text(entry, encoding="utf-8")
                desk_file.chmod(0o755)
                created_at.append(str(desk_file))
            except Exception:
                pass

        apps_dir = Path.home() / ".local" / "share" / "applications"
        try:
            apps_dir.mkdir(parents=True, exist_ok=True)
            (apps_dir / "jarvis.desktop").write_text(entry, encoding="utf-8")
        except Exception:
            pass

        if created_at:
            return True, f"Shortcut created at {', '.join(created_at)}"
        return False, "Failed to create Linux desktop entry"

    elif _OS == "Darwin":
        for desk in desktop_dirs:
            cmd_file = desk / "JARVIS.command"
            try:
                content = (
                    "#!/bin/bash\n"
                    f"cd \"{base_dir}\"\n"
                    f"\"{target_exe}\" \"{main_py}\"\n"
                )
                cmd_file.write_text(content, encoding="utf-8")
                cmd_file.chmod(0o755)
                created_at.append(str(cmd_file))
            except Exception:
                pass

        if created_at:
            return True, f"Shortcut created at {', '.join(created_at)}"
        return False, "Failed to create macOS launcher"

    return False, f"Unsupported OS: {_OS}"


def _create_windows_lnk(
    shortcut_path: Path,
    target_exe: Path,
    arguments: str,
    work_dir: Path,
    icon_path: Path | None,
) -> bool:
    """Create a Windows shortcut (.lnk) file via COM, with PowerShell fallback."""
    # Method 1: pywin32 WScript.Shell
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(str(shortcut_path))
        shortcut.TargetPath = str(target_exe)
        shortcut.Arguments = arguments
        shortcut.WorkingDirectory = str(work_dir)
        if icon_path and icon_path.exists():
            shortcut.IconLocation = f"{icon_path},0"
        shortcut.Description = "JARVIS AI Assistant"
        shortcut.Save()
        if shortcut_path.exists():
            return True
    except Exception:
        pass

    # Method 2: PowerShell COM fallback
    try:
        icon_line = (
            f"$s.IconLocation = '{icon_path},0';"
            if icon_path and icon_path.exists()
            else ""
        )
        ps_cmd = (
            f"$w = New-Object -ComObject WScript.Shell; "
            f"$s = $w.CreateShortcut('{shortcut_path}'); "
            f"$s.TargetPath = '{target_exe}'; "
            f"$s.Arguments = '{arguments}'; "
            f"$s.WorkingDirectory = '{work_dir}'; "
            f"{icon_line} "
            f"$s.Description = 'JARVIS AI Assistant'; "
            f"$s.Save()"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
            capture_output=True,
            check=True,
        )
        if shortcut_path.exists():
            return True
    except Exception:
        pass

    return False


# ── Auto-Start Management ───────────────────────────────────────────────────

def is_autostart_enabled() -> bool:
    """Check if JARVIS is configured to start with OS boot."""
    if _OS == "Windows":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_READ,
            )
            val, _ = winreg.QueryValueEx(key, "JARVIS")
            winreg.CloseKey(key)
            return bool(val)
        except OSError:
            return False
    elif _OS == "Linux":
        autostart_file = Path.home() / ".config" / "autostart" / "jarvis.desktop"
        return autostart_file.exists()
    return False


def set_autostart(enable: bool) -> tuple[bool, str]:
    """Enable or disable auto-start on boot."""
    base_dir = get_base_dir()
    main_py = base_dir / "main.py"
    target_exe = _get_target_executable()

    if _OS == "Windows":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_SET_VALUE | winreg.KEY_READ,
            )
            if enable:
                cmd = f'"{target_exe}" "{main_py}"'
                winreg.SetValueEx(key, "JARVIS", 0, winreg.REG_SZ, cmd)
                winreg.CloseKey(key)
                return True, "Auto-start enabled (Windows Startup Registry)."
            else:
                try:
                    winreg.DeleteValue(key, "JARVIS")
                except FileNotFoundError:
                    pass
                winreg.CloseKey(key)
                return True, "Auto-start disabled."
        except Exception as e:
            return False, f"Failed to modify Windows startup registry: {e}"

    elif _OS == "Linux":
        autostart_dir = Path.home() / ".config" / "autostart"
        autostart_file = autostart_dir / "jarvis.desktop"
        try:
            if enable:
                autostart_dir.mkdir(parents=True, exist_ok=True)
                entry = (
                    "[Desktop Entry]\n"
                    "Type=Application\n"
                    "Name=JARVIS\n"
                    "Comment=JARVIS AI Assistant\n"
                    f"Exec=\"{target_exe}\" \"{main_py}\"\n"
                    f"Path={base_dir}\n"
                    "Terminal=false\n"
                )
                autostart_file.write_text(entry, encoding="utf-8")
                return True, "Auto-start enabled (~/.config/autostart)."
            else:
                if autostart_file.exists():
                    autostart_file.unlink()
                return True, "Auto-start disabled."
        except Exception as e:
            return False, f"Failed to modify Linux autostart: {e}"

    return False, f"Auto-start not supported on {_OS}."


def toggle_autostart() -> tuple[bool, str]:
    """Toggle auto-start on or off."""
    currently_enabled = is_autostart_enabled()
    return set_autostart(not currently_enabled)


if __name__ == "__main__":
    ok, msg = create_desktop_shortcut()
    print("Status:", "OK" if ok else "FAILED")
    print(msg)
