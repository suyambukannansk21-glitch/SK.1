# core/offline_engine.py
"""
Offline Command Processing Engine for JARVIS MARK LII.

Provides local command matching and execution when internet connectivity
or Gemini Live is unavailable, strictly bounded by a Limited Access
security policy:
  - Allowed: Local system settings (volume, brightness, display, lock),
    launching installed apps, opening files/docs across drives, searching
    files across drives, system telemetry, time/date, local memory recall.
  - Restricted: Registry modifications, app installations/uninstalls/downloads,
    cloud searches, external messaging, and file deletions are blocked.
  - Offline TTS: Windows SAPI voice synthesizer via win32com.
"""

from __future__ import annotations

import asyncio
import os
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

for _stream in ("stdout", "stderr"):
    try:
        _s = getattr(sys, _stream, None)
        if _s is not None and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Local tool imports
try:
    from actions.computer_settings import computer_settings
except ImportError:
    computer_settings = None

try:
    from actions.open_app import open_app
except ImportError:
    open_app = None

try:
    from actions.file_controller import file_controller
except ImportError:
    file_controller = None

try:
    from actions.system_monitor import get_system_status
except ImportError:
    get_system_status = None

try:
    from memory.memory_manager import search_memory
except ImportError:
    search_memory = None


class OfflineSpeaker:
    """Windows SAPI TTS engine for speaking offline without cloud or model downloads."""

    def __init__(self):
        self._lock = threading.Lock()
        self._available = False
        try:
            import win32com.client
            import pythoncom
            self._available = True
        except ImportError:
            self._available = False

    def speak(self, text: str, on_done: Optional[Callable[[], None]] = None) -> None:
        """Speak text asynchronously in a background thread."""
        if not text:
            if on_done:
                on_done()
            return

        def _worker():
            with self._lock:
                try:
                    import pythoncom
                    import win32com.client
                    pythoncom.CoInitialize()
                    try:
                        voice = win32com.client.Dispatch("SAPI.SpVoice")
                        # 0 = SVSFDefault (synchronous within worker thread)
                        voice.Speak(text, 0)
                    finally:
                        pythoncom.CoUninitialize()
                except Exception as e:
                    print(f"[OfflineSpeaker] Speech error: {e}")
                finally:
                    if on_done:
                        try:
                            on_done()
                        except Exception:
                            pass

        threading.Thread(target=_worker, daemon=True).start()


class OfflineEngine:
    """Manages offline intent matching, safety enforcement, and local action dispatch."""

    def __init__(self, player: Any = None):
        self.player = player
        self.speaker = OfflineSpeaker()
        self.is_offline_active = False

    def set_offline_active(self, active: bool) -> None:
        self.is_offline_active = active

    def log(self, msg: str) -> None:
        print(f"[OfflineEngine] {msg}")
        if self.player and hasattr(self.player, "write_log"):
            self.player.write_log(msg)

    def speak_and_log(self, response_text: str, log_prefix: str = "JARVIS: ") -> None:
        """Deliver response to UI log and synthesize local voice."""
        self.log(f"{log_prefix}{response_text}")
        if self.player and hasattr(self.player, "set_state"):
            self.player.set_state("SPEAKING")

        def _on_done():
            if self.player and hasattr(self.player, "set_state"):
                self.player.set_state("LISTENING")

        self.speaker.speak(response_text, on_done=_on_done)

    # ─────────────────────────────────────────────────────────────────────────
    # Limited Access Security Guard
    # ─────────────────────────────────────────────────────────────────────────

    def _check_security_policy(self, text: str) -> Optional[str]:
        """Verify whether a command attempts restricted high-risk offline actions.
        Returns a friendly rejection explanation if blocked, or None if safe."""
        low = text.lower().strip()

        # 1. Registry manipulation
        reg_keywords = (
            "registry", "regedit", "kayıt defteri", "hkey_", "reg key",
            "registry_manager", "edit registry", "delete key", "set registry"
        )
        if any(k in low for k in reg_keywords):
            return (
                "⚠️ Registry management is restricted in Offline Mode for system integrity and safety. "
                "Please reconnect to the internet for administrative modifications."
            )

        # 2. App installation / uninstallation / download
        install_keywords = (
            "install app", "uninstall app", "download app", "install program",
            "uninstall program", "uygulama kur", "uygulama sil", "uygulama kaldır",
            "winget", "download and install"
        )
        if any(k in low for k in install_keywords):
            return (
                "⚠️ Application installation, uninstallation, and downloads are restricted in Offline Mode. "
                "Please reconnect to the internet to manage software packages."
            )

        # 3. Permanent file deletion
        delete_keywords = (
            "delete file", "remove file", "delete folder", "remove folder",
            "dosyayı sil", "klasörü sil", "dosya sil"
        )
        if any(k in low for k in delete_keywords):
            return (
                "⚠️ File and folder deletion is restricted in Offline Mode for safety."
            )

        # 4. Cloud searches & external services
        cloud_keywords = (
            "google ", "search web", "web search", "internette ara", "internetten ara",
            "weather", "hava durumu", "flight", "uçuş", "send message", "mesaj gönder",
            "youtube", "video ara"
        )
        if any(k in low for k in cloud_keywords):
            return (
                "🌐 This action requires an active internet connection. "
                "Offline Mode only supports local laptop controls, documents, and system telemetry."
            )

        # 5. Creating or editing photos and videos
        media_keywords = (
            "edit photo", "create photo", "make photo", "generate photo", "draw photo",
            "edit image", "create image", "make image", "generate image", "draw image",
            "edit video", "create video", "make video", "generate video", "render video",
            "trim video", "crop photo", "crop image", "resize photo", "resize image",
            "compress video", "compress image", "convert photo", "convert video",
            "fotoğraf düzenle", "fotoğraf oluştur", "resim oluştur", "resim çiz",
            "resim yap", "video düzenle", "video oluştur", "video kes", "resim düzenle",
        )
        if any(k in low for k in media_keywords):
            return (
                "⚠️ Permission Denied: I do not have permission to create or edit photos and videos."
            )

        return None

    # ─────────────────────────────────────────────────────────────────────────
    # Local Intent Parsing
    # ─────────────────────────────────────────────────────────────────────────

    def process_command(self, text: str) -> str:
        """Parse and execute a local command under offline mode constraints."""
        raw = (text or "").strip()
        if not raw:
            return ""

        print(f"[OfflineEngine] Processing offline command: '{raw}'")
        low = raw.lower()

        # Check security policy first
        security_rejection = self._check_security_policy(raw)
        if security_rejection:
            self.speak_and_log(security_rejection)
            return security_rejection

        # 1. Volume Controls
        # "set volume to 40", "volume 50", "sesi 70 yap"
        vol_match = re.search(r"(?:set\s+volume\s+(?:to\s+)?|volume\s+|sesi\s+)(\d{1,3})(?:\s*%|\s+yap)?", low)
        if vol_match and any(w in low for w in ("volume", "ses", "sound")):
            target = max(0, min(100, int(vol_match.group(1))))
            res = computer_settings({"action": "volume_set", "value": target}, player=self.player) if computer_settings else f"Volume set to {target}%."
            reply = f"Volume adjusted to {target}%."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("volume up", "louder", "turn it up", "ses aç", "sesi artır", "sesi yükselt")):
            if computer_settings:
                computer_settings({"action": "volume_up"}, player=self.player)
            reply = "Volume increased."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("volume down", "quieter", "turn it down", "ses kıs", "sesi azalt")):
            if computer_settings:
                computer_settings({"action": "volume_down"}, player=self.player)
            reply = "Volume decreased."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("mute", "silence", "sessize al", "sesi kapat")):
            if computer_settings:
                computer_settings({"action": "mute"}, player=self.player)
            reply = "Audio muted."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("unmute", "sesi geri aç", "sesi aç")):
            if computer_settings:
                computer_settings({"action": "unmute"}, player=self.player)
            reply = "Audio unmuted."
            self.speak_and_log(reply)
            return reply

        # 2. Brightness Controls
        # "brightness 80", "set brightness to 70", "parlaklığı 60 yap"
        bri_match = re.search(r"(?:set\s+brightness\s+(?:to\s+)?|brightness\s+|parlaklığı\s+)(\d{1,3})(?:\s*%|\s+yap)?", low)
        if bri_match and any(w in low for w in ("brightness", "parlaklık")):
            target = max(0, min(100, int(bri_match.group(1))))
            res = computer_settings({"action": "brightness_set", "value": target}, player=self.player) if computer_settings else f"Brightness set to {target}%."
            reply = f"Brightness set to {target}%."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("brightness up", "brighter", "parlaklığı artır", "parlaklığı yükselt")):
            if computer_settings:
                computer_settings({"action": "brightness_up"}, player=self.player)
            reply = "Brightness increased."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("brightness down", "dimmer", "parlaklığı azalt", "parlaklığı kıs")):
            if computer_settings:
                computer_settings({"action": "brightness_down"}, player=self.player)
            reply = "Brightness decreased."
            self.speak_and_log(reply)
            return reply

        # 3. System & Display Settings
        if any(k in low for k in ("lock screen", "lock pc", "lock computer", "bilgisayarı kilitle", "ekranı kilitle")):
            if computer_settings:
                computer_settings({"action": "lock_screen"}, player=self.player)
            reply = "Computer locked."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("sleep display", "screen off", "display off", "ekranı kapat", "ekranı uyut")):
            if computer_settings:
                computer_settings({"action": "sleep_display"}, player=self.player)
            reply = "Display set to sleep."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("show desktop", "minimize everything", "masaüstünü göster", "masaüstü")):
            if computer_settings:
                computer_settings({"action": "show_desktop"}, player=self.player)
            reply = "Showing desktop."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("task manager", "görev yöneticisi", "taskmgr")):
            if computer_settings:
                computer_settings({"action": "task_manager"}, player=self.player)
            reply = "Task Manager opened."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("screenshot", "take a screenshot", "ekran görüntüsü al", "ekran görüntüsü")):
            if computer_settings:
                computer_settings({"action": "screenshot"}, player=self.player)
            reply = "Screenshot captured."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("dark mode", "night mode", "karanlık mod", "karanlık tema")):
            if computer_settings:
                computer_settings({"action": "dark_mode"}, player=self.player)
            reply = "Dark mode toggled."
            self.speak_and_log(reply)
            return reply

        # 4. Time and Date
        if any(k in low for k in ("what time is it", "current time", "what time", "saat kaç", "saat")):
            now = datetime.now()
            reply = f"It is currently {now.strftime('%I:%M %p')} on {now.strftime('%A, %B %d, %Y')}."
            self.speak_and_log(reply)
            return reply

        if any(k in low for k in ("what date is it", "what's the date", "what is today's date", "today's date", "tarih ne", "tarih", "bugün günlerden ne")):
            now = datetime.now()
            reply = f"Today is {now.strftime('%A, %B %d, %Y')}."
            self.speak_and_log(reply)
            return reply

        # 5. System Status & Hardware Telemetry
        if any(k in low for k in ("system status", "system health", "hardware status", "sistem durumu", "pil durumu", "battery", "cpu", "ram", "donanım")):
            if get_system_status:
                stats = get_system_status()
                cpu = stats.get("cpu_percent", 0)
                ram_pct = stats.get("ram_percent", 0)
                ram_gb = stats.get("ram_used_gb", 0)
                ram_tot = stats.get("ram_total_gb", 0)
                uptime = stats.get("uptime", "unknown")
                reply = (
                    f"System Status: CPU usage is at {cpu}%, RAM is at {ram_pct}% "
                    f"({ram_gb} GB of {ram_tot} GB). System uptime: {uptime}."
                )
            else:
                reply = "System status monitor is unavailable."
            self.speak_and_log(reply)
            return reply

        # 6. File Search across all drives
        find_match = re.search(r"(?:find\s+file|search\s+(?:for\s+)?file|search\s+for|dosya\s+bul|dosya\s+ara)\s+(.+)", raw, re.IGNORECASE)
        if find_match:
            filename = find_match.group(1).strip().strip('"').strip("'")
            if file_controller:
                res = file_controller({"action": "find", "name": filename}, player=self.player)
                self.speak_and_log(f"File search for '{filename}' completed.")
                self.log(res)
                return res
            else:
                reply = "File search module unavailable."
                self.speak_and_log(reply)
                return reply

        # 7. Open Document / File on any drive
        open_file_match = re.search(r"(?:open\s+file|open\s+document|dosya\s+aç)\s+(.+)", raw, re.IGNORECASE)
        if open_file_match:
            filepath = open_file_match.group(1).strip().strip('"').strip("'")
            if file_controller:
                res = file_controller({"action": "open", "path": filepath}, player=self.player)
                self.speak_and_log(res)
                return res
            else:
                reply = "File opener module unavailable."
                self.speak_and_log(reply)
                return reply

        # 8. List files in directory
        list_match = re.search(r"(?:list\s+files\s+in|show\s+files\s+in|dosyaları\s+listele\s*(?:klasöründe)?)\s*(.*)", raw, re.IGNORECASE)
        if list_match and any(w in low for w in ("list files", "show files", "dosyaları listele")):
            folder = list_match.group(1).strip().strip('"').strip("'") or "desktop"
            if file_controller:
                res = file_controller({"action": "list", "path": folder}, player=self.player)
                self.speak_and_log(f"Listed files in {folder}.")
                self.log(res)
                return res

        # 9. Disk usage
        if any(k in low for k in ("disk usage", "disk space", "storage space", "depolama durumu", "disk durumu")):
            if file_controller:
                res = file_controller({"action": "disk_usage"}, player=self.player)
                self.speak_and_log("Disk usage retrieved.")
                self.log(res)
                return res

        # 10. Local Memory Recall
        recall_match = re.search(r"(?:recall|what\s+do\s+you\s+remember\s+about|remember\s+about|hatırla)\s+(.+)", raw, re.IGNORECASE)
        if recall_match:
            topic = recall_match.group(1).strip().strip('"').strip("'")
            if search_memory:
                mem_res = search_memory(topic)
                reply = f"Memory recall for '{topic}': {mem_res}"
                self.speak_and_log(reply)
                return reply

        # 11. Launch / Open Application
        app_match = re.search(r"^(?:open|launch|start)\s+(?:app|application|program)?\s*(.+)$", raw, re.IGNORECASE)
        if not app_match:
            app_match = re.search(r"^(.+?)\s+(?:aç|başlat)$", raw, re.IGNORECASE)

        if app_match:
            target_app = app_match.group(1).strip().strip('"').strip("'")
            if target_app.lower() not in ("file", "document", "folder", "desktop", "sound", "volume", "registry"):
                if open_app:
                    res = open_app({"app_name": target_app}, player=self.player)
                    self.speak_and_log(res)
                    return res
                else:
                    reply = f"Cannot open {target_app} (app launcher unavailable)."
                    self.speak_and_log(reply)
                    return reply

        # 12. Fallback / Unrecognized Offline Command
        help_msg = (
            "⚡ [Offline Mode — Limited Access]\\n"
            "Cloud AI is offline. Available local commands:\\n"
            " • Audio & Display: 'volume up', 'volume down', 'set volume to 50', 'brightness up', 'screen off'\\n"
            " • System Control: 'lock pc', 'show desktop', 'task manager', 'screenshot', 'system status', 'what time is it'\\n"
            " • Apps & Files: 'open <app>', 'open file <path>', 'find file <name>', 'list files in <folder>', 'disk usage'\\n"
            " • Memory: 'recall <topic>'\\n"
            "(High-risk actions like registry edits and app installations are restricted while offline.)"
        )
        self.speak_and_log(
            "I am in offline mode with limited access. You can control volume, display, launch apps, open files, or check system status."
        )
        self.log(help_msg)
        return help_msg
