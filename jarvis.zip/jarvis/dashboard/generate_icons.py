"""
Generate high-resolution JARVIS Arc-Reactor icons for PWA & Android app.
"""
import math
from pathlib import Path
from PIL import Image, ImageDraw

ICONS_DIR = Path(__file__).parent / "static" / "icons"
ICONS_DIR.mkdir(parents=True, exist_ok=True)

def draw_reactor_icon(size: int, maskable: bool = False) -> Image.Image:
    # High-resolution supersampling (2x)
    render_size = size * 2
    img = Image.new("RGBA", (render_size, render_size), (7, 9, 15, 255 if maskable else 0))
    draw = ImageDraw.Draw(img)

    cx = cy = render_size / 2
    # Radius scale
    r_scale = 0.38 if maskable else 0.44
    max_r = render_size * r_scale

    # Background subtle radial glow
    steps = 40
    for i in range(steps, 0, -1):
        alpha = int(35 * (1 - i / steps))
        r = max_r * 1.15 * (i / steps)
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(99, 102, 241, alpha))

    # Outer metallic ring
    outer_r = max_r
    outer_w = int(render_size * 0.028)
    draw.ellipse([cx - outer_r, cy - outer_r, cx + outer_r, cy + outer_r],
                 outline=(99, 102, 241, 180), width=outer_w)

    # 10 Segment reactor teeth
    num_teeth = 10
    tooth_r_in = max_r * 0.76
    tooth_r_out = max_r * 0.94
    for i in range(num_teeth):
        angle_deg = i * (360 / num_teeth)
        angle_rad = math.radians(angle_deg)
        x1 = cx + tooth_r_in * math.cos(angle_rad)
        y1 = cy + tooth_r_in * math.sin(angle_rad)
        x2 = cx + tooth_r_out * math.cos(angle_rad)
        y2 = cy + tooth_r_out * math.sin(angle_rad)
        draw.line([x1, y1, x2, y2], fill=(0, 240, 255, 230), width=int(render_size * 0.035))

    # Middle cyan ring
    mid_r = max_r * 0.72
    mid_w = int(render_size * 0.02)
    draw.ellipse([cx - mid_r, cy - mid_r, cx + mid_r, cy + mid_r],
                 outline=(0, 240, 255, 255), width=mid_w)

    # Inner ring
    inner_r = max_r * 0.50
    draw.ellipse([cx - inner_r, cy - inner_r, cx + inner_r, cy + inner_r],
                 outline=(99, 102, 241, 220), width=int(render_size * 0.018))

    # Glowing core
    core_r = max_r * 0.36
    for i in range(25, 0, -1):
        alpha = int(220 * (1 - (i / 25) ** 2))
        r = core_r * (i / 25)
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(0, 240, 255, alpha))

    # Center white-hot spark
    spark_r = max_r * 0.14
    draw.ellipse([cx - spark_r, cy - spark_r, cx + spark_r, cy + spark_r],
                 fill=(255, 255, 255, 250))

    # Downsample with Lanczos for anti-aliasing
    return img.resize((size, size), Image.Resampling.LANCZOS)

if __name__ == "__main__":
    icon_192 = draw_reactor_icon(192, maskable=False)
    icon_192.save(ICONS_DIR / "icon-192.png", "PNG")

    icon_512 = draw_reactor_icon(512, maskable=False)
    icon_512.save(ICONS_DIR / "icon-512.png", "PNG")

    icon_maskable = draw_reactor_icon(512, maskable=True)
    icon_maskable.save(ICONS_DIR / "icon-maskable.png", "PNG")

    print(f"Generated icons in: {ICONS_DIR}")
