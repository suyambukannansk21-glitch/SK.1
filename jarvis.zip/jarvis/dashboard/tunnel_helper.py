"""
dashboard/tunnel_helper.py — Remote Access Helper for Mobile JARVIS

Provides instant cloud tunneling (Cloudflare Tunnel / ngrok) so you can connect
your Android phone to JARVIS over 4G/5G mobile data anywhere in the world.
"""

import shutil
import subprocess
import sys
import time

PORT = 8000

def check_tools():
    has_cf = shutil.which("cloudflared") is not None
    has_ngrok = shutil.which("ngrok") is not None
    return has_cf, has_ngrok

def start_cloudflare_tunnel():
    print("[Tunnel] Starting Cloudflare Tunnel on port 8000...")
    cmd = ["cloudflared", "tunnel", "--url", f"http://localhost:{PORT}"]
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        print("[Tunnel] Tunnel is initializing. Look for your https://*.trycloudflare.com URL below:")
        print("----------------------------------------------------------------------")
        for line in iter(proc.stdout.readline, ''):
            if "trycloudflare.com" in line:
                for word in line.split():
                    if "trycloudflare.com" in word:
                        clean_url = word.strip().rstrip('.')
                        if clean_url.startswith("https://"):
                            print(f"\n[Tunnel] 🌟 YOUR MOBILE ACCESS URL: {clean_url}\n")
                            print("Enter this URL into your JARVIS Android App settings (⚙).\n")
            print(line, end='')
    except Exception as e:
        print(f"[Tunnel] Error starting cloudflared: {e}")

def start_ngrok():
    print(f"[Tunnel] Starting ngrok on port {PORT}...")
    try:
        subprocess.run(["ngrok", "http", str(PORT)])
    except Exception as e:
        print(f"[Tunnel] Error starting ngrok: {e}")

def main():
    print("=" * 60)
    print("  JARVIS Remote Mobile Access Helper")
    print("=" * 60)
    has_cf, has_ngrok = check_tools()

    if has_cf:
        print("\n[✓] Cloudflare Tunnel (cloudflared) detected.")
        start_cloudflare_tunnel()
    elif has_ngrok:
        print("\n[✓] ngrok detected.")
        start_ngrok()
    else:
        print("\n[!] No cloud tunneling tools detected on PATH.")
        print("\nTo connect your Android phone outside your home Wi-Fi:")
        print("1. Cloudflare Tunnel (Recommended - 100% Free & Unlimited):")
        print("   - Download 'cloudflared' from: https://github.com/cloudflare/cloudflared/releases")
        print("   - Run: cloudflared tunnel --url http://localhost:8000")
        print("2. Or install ngrok: https://ngrok.com/download")
        print("   - Run: ngrok http 8000")
        print("3. Or install Tailscale: https://tailscale.com/")
        print("   - Connect both your PC and phone to Tailscale and use the 100.x.y.z IP.")

if __name__ == "__main__":
    main()
