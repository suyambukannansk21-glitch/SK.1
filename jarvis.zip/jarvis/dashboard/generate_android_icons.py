from pathlib import Path
from PIL import Image

BASE_DIR = Path(__file__).parent.parent
SOURCE_ICON = BASE_DIR / "dashboard" / "static" / "icons" / "icon-512.png"
RES_DIR = BASE_DIR / "android" / "app" / "src" / "main" / "res"

DENSITIES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

if SOURCE_ICON.exists():
    img = Image.open(SOURCE_ICON)
    for folder, size in DENSITIES.items():
        out_dir = RES_DIR / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        resized = img.resize((size, size), Image.Resampling.LANCZOS)
        resized.save(out_dir / "ic_launcher.png", "PNG")
        resized.save(out_dir / "ic_launcher_round.png", "PNG")
    print("Android mipmap icons generated successfully!")
else:
    print(f"Source icon not found at {SOURCE_ICON}")
