import subprocess
import sys
import platform
from pathlib import Path

print("Installing requirements...")
subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)

print("Installing Playwright browsers...")
subprocess.run([sys.executable, "-m", "playwright", "install"], check=True)

if platform.system() == "Windows":
    try:
        import win32com.client  # noqa: F401
    except ImportError:
        postinstall = Path(sys.executable).parent / "Scripts" / "pywin32_postinstall.py"
        print(
            "\n⚠️  pywin32 did not install correctly — desktop shortcut creation "
            "will fall back to a slower method that may not work on this machine.\n"
            "    Try fixing it manually with:\n"
            f'    "{sys.executable}" -m pip install --force-reinstall pywin32\n'
            f'    "{sys.executable}" "{postinstall}" -install\n'
        )

print("\nCreating desktop shortcut...")
try:
    from core.shortcut_manager import create_desktop_shortcut
    ok, msg = create_desktop_shortcut()
    if ok:
        print(f"✅ {msg}")
    else:
        print(f"⚠️  {msg}")
except Exception as e:
    print(f"⚠️  Could not create desktop shortcut: {e}")

print("\n✅ Setup complete! Run 'python main.py' to start MARK LII.")

