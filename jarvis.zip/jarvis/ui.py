from __future__ import annotations

import colorsys
import json
import math
import os
import platform
import random
import subprocess
import sys
import threading
import time
from pathlib import Path

import psutil

if platform.system() == "Windows":
    _WIN_HIDE: dict = {"creationflags": subprocess.CREATE_NO_WINDOW}
else:
    _WIN_HIDE: dict = {}

from PyQt6.QtCore import (
    QEasingCurve, QMimeData, QObject, QPoint, QPointF, QRectF, QSize, Qt,
    QTimer, QUrl, pyqtSignal,
)
from PyQt6.QtGui import (
    QBrush, QColor, QConicalGradient, QDesktopServices, QDragEnterEvent, QDropEvent, QFont,
    QFontDatabase, QKeySequence, QLinearGradient, QPainter, QPainterPath,
    QPen, QPixmap, QRadialGradient, QShortcut,
)
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMenu, QPushButton, QScrollArea, QSizePolicy, QSplitter,
    QStackedWidget, QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR   = _base_dir()
CONFIG_DIR = BASE_DIR / "config"
API_FILE   = CONFIG_DIR / "api_keys.json"


def _read_full_config() -> dict:
    try:
        return json.loads(API_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


_DEFAULT_W, _DEFAULT_H = 860, 680
_MIN_W,     _MIN_H     = 700, 540
_OS = platform.system()


# ── Apple Siri Dark Palette ──────────────────────────────────────────────────
class C:
    BG        = "#08090f"       # Deep Obsidian Space Black
    PANEL     = "#121420"       # Frosted Glass Surface
    PANEL2    = "#181b2a"       # Secondary Elevated Surface
    BORDER    = "#222738"       # Translucent Border
    BORDER_B  = "#31384e"       # Highlight Border
    BORDER_A  = "#414a67"       # Active Border
    PRI       = "#00c6ff"       # Siri Vibrant Cyan
    PRI_DIM   = "#0072ff"       # Siri Deep Royal Blue
    PRI_GHO   = "#0c1830"       # Ambient Accent Glow
    ACC       = "#af52de"       # Siri Neon Purple / Violet
    ACC2      = "#ff2d55"       # Siri Hot Pink / Magenta
    GREEN     = "#30d158"       # Apple Emerald Green
    GREEN_D   = "#248a3d"       # Dark Emerald
    RED       = "#ff453a"       # Apple Soft Red
    MUTED_C   = "#ff453a"       # Muted Accent Red
    TEXT      = "#f5f5f7"       # Apple Crisp Primary Text
    TEXT_DIM  = "#86868b"       # Apple Secondary Muted Label
    TEXT_MED  = "#a1a1a6"       # Apple Mid-Gray Label
    WHITE     = "#ffffff"       # Pure White
    DARK      = "#050608"       # Deep Void
    BAR_BG    = "#161824"       # Capsule Bar Background


_HUE_LINKED = (
    "BG", "PANEL", "PANEL2", "BORDER", "BORDER_B", "BORDER_A",
    "PRI", "PRI_DIM", "PRI_GHO", "TEXT", "TEXT_DIM", "TEXT_MED",
    "WHITE", "DARK", "BAR_BG",
)
_PALETTE_DEFAULTS: dict[str, str] = {k: getattr(C, k) for k in _HUE_LINKED}
DEFAULT_UI_COLOR = _PALETTE_DEFAULTS["PRI"]


def apply_ui_accent(accent_hex: str) -> bool:
    accent_hex = (accent_hex or "").strip().lower()
    if not (accent_hex.startswith("#") and len(accent_hex) == 7):
        return False
    try:
        int(accent_hex[1:], 16)
    except ValueError:
        return False

    def _hsv(h: str) -> tuple[float, float, float]:
        r = int(h[1:3], 16) / 255
        g = int(h[3:5], 16) / 255
        b = int(h[5:7], 16) / 255
        return colorsys.rgb_to_hsv(r, g, b)

    base_h = _hsv(_PALETTE_DEFAULTS["PRI"])[0]
    acc_h, acc_s, _ = _hsv(accent_hex)
    dh = acc_h - base_h
    grey = acc_s < 0.08

    for key, hex0 in _PALETTE_DEFAULTS.items():
        h, s, v = _hsv(hex0)
        if grey:
            s *= 0.15
        r, g, b = colorsys.hsv_to_rgb((h + dh) % 1.0, s, v)
        setattr(C, key, "#{:02x}{:02x}{:02x}".format(
            int(r * 255 + 0.5), int(g * 255 + 0.5), int(b * 255 + 0.5)))
    return True


def current_palette() -> dict[str, str]:
    return {k: getattr(C, k) for k in _HUE_LINKED}


def retheme_all_widgets(old: dict[str, str], new: dict[str, str]) -> None:
    mapping = {old[k].lower(): new[k].lower()
               for k in old if old[k].lower() != new.get(k, old[k]).lower()}
    if not mapping:
        return
    app = QApplication.instance()
    if app is None:
        return
    for w in app.allWidgets():
        try:
            ss = w.styleSheet()
            if ss:
                s2 = ss
                for o, n in mapping.items():
                    if o in s2:
                        s2 = s2.replace(o, n)
                if s2 != ss:
                    w.setStyleSheet(s2)
            w.update()
        except Exception:
            pass


def qcol(h: str, a: int = 255) -> QColor:
    c = QColor(h)
    c.setAlpha(a)
    return c


# ── Hardware Metrics System ──────────────────────────────────────────────────
_nvml_lib: object = None
_nvml_ok:  object = None


def _nvml_gpu_windows() -> float:
    global _nvml_lib, _nvml_ok
    if _nvml_ok is False:
        return -1.0
    try:
        import ctypes
        class _Util(ctypes.Structure):
            _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]

        if _nvml_lib is None:
            for dll in ("nvml", r"C:\Windows\System32\nvml.dll"):
                try:
                    lib = ctypes.WinDLL(dll)
                    lib.nvmlInit_v2()
                    _nvml_lib = lib
                    break
                except Exception:
                    continue

        if _nvml_lib is None:
            import pynvml
            pynvml.nvmlInit()
            h = pynvml.nvmlDeviceGetHandleByIndex(0)
            _nvml_ok = True
            return float(pynvml.nvmlDeviceGetUtilizationRates(h).gpu)

        dev = ctypes.c_void_p()
        _nvml_lib.nvmlDeviceGetHandleByIndex_v2(0, ctypes.byref(dev))
        util = _Util()
        _nvml_lib.nvmlDeviceGetUtilizationRates(dev, ctypes.byref(util))
        _nvml_ok = True
        return float(util.gpu)
    except Exception:
        _nvml_ok = False
        return -1.0


class _SysMetrics:
    def __init__(self):
        self.cpu, self.mem, self.net, self.gpu, self.tmp = 0.0, 0.0, 0.0, -1.0, -1.0
        self._lock = threading.Lock()
        self._last_net = psutil.net_io_counters()
        self._last_net_t = time.time()
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while self._running:
            try:
                self._update()
            except Exception:
                pass
            time.sleep(1.5)

    def _update(self):
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent
        nc = psutil.net_io_counters()
        now = time.time()
        dt = now - self._last_net_t
        net = ((nc.bytes_sent - self._last_net.bytes_sent) + (nc.bytes_recv - self._last_net.bytes_recv)) / dt / (1024 * 1024) if dt > 0 else 0.0
        self._last_net, self._last_net_t = nc, now
        gpu = self._get_gpu()
        tmp = self._get_temp()

        with self._lock:
            self.cpu, self.mem, self.net, self.gpu, self.tmp = cpu, mem, net, gpu, tmp

    def _get_gpu(self) -> float:
        try:
            import pynvml
            pynvml.nvmlInit()
            return float(pynvml.nvmlDeviceGetUtilizationRates(pynvml.nvmlDeviceGetHandleByIndex(0)).gpu)
        except Exception:
            pass
        if _OS == "Windows":
            return _nvml_gpu_windows()
        return -1.0

    def _get_temp(self) -> float:
        try:
            temps = psutil.sensors_temperatures()
            for name in ["coretemp", "k10temp", "cpu_thermal", "acpitz", "cpu-thermal"]:
                if name in temps and temps[name]:
                    return temps[name][0].current
        except Exception:
            pass
        if _OS == "Windows":
            try:
                import wmi
                tz = wmi.WMI(namespace="root/wmi").MSAcpi_ThermalZoneTemperature()
                if tz:
                    return (tz[0].CurrentTemperature / 10.0) - 273.15
            except Exception:
                pass
        return -1.0

    def snapshot(self) -> dict:
        with self._lock:
            return {"cpu": self.cpu, "mem": self.mem, "net": self.net, "gpu": self.gpu, "tmp": self.tmp}

_metrics = _SysMetrics()


# ── Siri Floating Orb Widget (When Minimized) ────────────────────────────────
class OrbFloatingWidget(QWidget):
    expand_requested = pyqtSignal()
    mute_toggled = pyqtSignal()
    settings_requested = pyqtSignal()
    quit_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(140, 140)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("JARVIS (Siri Orb)\n• Click to open full window\n• Drag to reposition\n• Right-click for options")

        self._tick = 0
        self._drag_pos = QPoint()
        self._press_pos = QPoint()
        self._has_dragged = False
        self._live_amp = 0.0
        self._amp_disp = 0.0
        self.speaking = False
        self.muted = False

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self._timer.start(16)

        # Local keyboard shortcuts while Orb is active
        QShortcut(QKeySequence("F12"), self).activated.connect(self.expand_requested)
        QShortcut(QKeySequence("Escape"), self).activated.connect(self.expand_requested)
        QShortcut(QKeySequence("F4"), self).activated.connect(self.mute_toggled)

    def set_audio_level(self, level: float) -> None:
        try:
            lv = max(0.0, min(1.0, float(level)))
            if lv > self._live_amp:
                self._live_amp = lv
        except (TypeError, ValueError):
            pass

    def _step(self):
        self._tick += 1
        self._live_amp *= 0.88
        self._amp_disp += (self._live_amp - self._amp_disp) * 0.4
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._press_pos = event.globalPosition().toPoint()
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._has_dragged = False
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton:
            curr = event.globalPosition().toPoint()
            if (curr - self._press_pos).manhattanLength() > 6:
                self._has_dragged = True
                self.move(curr - self._drag_pos)
                event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if not self._has_dragged:
                self.expand_requested.emit()
            self._has_dragged = False
            event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.expand_requested.emit()
            event.accept()

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        menu.setStyleSheet(f"""
            QMenu {{
                background: #181b2a;
                color: {C.WHITE};
                border: 1px solid #2e3449;
                border-radius: 8px;
                padding: 4px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 9pt;
            }}
            QMenu::item {{
                padding: 6px 16px;
                border-radius: 4px;
            }}
            QMenu::item:selected {{
                background: {C.PRI_DIM};
                color: #ffffff;
            }}
        """)
        act_restore = menu.addAction("🗖  Open JARVIS [F12]")
        act_mute = menu.addAction("🔇  Unmute Microphone [F4]" if self.muted else "🎙  Mute Microphone [F4]")
        act_settings = menu.addAction("⚙  Settings")
        menu.addSeparator()
        act_quit = menu.addAction("✕  Quit")

        res = menu.exec(event.globalPos())
        if res == act_restore:
            self.expand_requested.emit()
        elif res == act_mute:
            self.mute_toggled.emit()
        elif res == act_settings:
            self.settings_requested.emit()
        elif res == act_quit:
            self.quit_requested.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        cx, cy = self.width() / 2.0, self.height() / 2.0
        amp = self._amp_disp
        base_r = 34.0 + amp * 18.0

        colors = [
            (QColor(C.PRI), 0.7, 1.2),
            (QColor(C.ACC), 0.5, -1.0),
            (QColor(C.ACC2), 0.4, 1.8),
            (QColor(C.GREEN), 0.3, -1.4),
        ]

        if self.muted:
            colors = [(QColor(C.MUTED_C), 0.4, 0.5)]

        glow = QRadialGradient(cx, cy, base_r * 1.6)
        glow_color = QColor(C.MUTED_C if self.muted else C.PRI)
        glow_color.setAlpha(int(60 + amp * 90))
        glow.setColorAt(0.0, glow_color)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setBrush(QBrush(glow))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(cx, cy), base_r * 1.6, base_r * 1.6)

        for col, opac, speed_mult in colors:
            c = QColor(col)
            c.setAlpha(int((opac * 255) * (0.6 + amp * 0.4)))
            p.setPen(QPen(c, 2.0))
            p.setBrush(Qt.BrushStyle.NoBrush)

            path = QPainterPath()
            points = 48
            for i in range(points + 1):
                angle = (i / points) * 2 * math.pi
                shimmer = math.sin(angle * 3 + self._tick * 0.08 * speed_mult) * (3.0 + amp * 14.0)
                r = base_r + shimmer
                x = cx + r * math.cos(angle)
                y = cy + r * math.sin(angle)
                if i == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            path.closeSubpath()
            p.drawPath(path)

        orb_grad = QConicalGradient(cx, cy, self._tick * 2.0)
        orb_grad.setColorAt(0.0, qcol(C.PRI, 220))
        orb_grad.setColorAt(0.33, qcol(C.ACC, 220))
        orb_grad.setColorAt(0.66, qcol(C.ACC2, 220))
        orb_grad.setColorAt(1.0, qcol(C.PRI, 220))

        p.setBrush(QBrush(qcol(C.MUTED_C, 180) if self.muted else orb_grad))
        p.setPen(QPen(QColor(255, 255, 255, 180), 1.0))
        p.drawEllipse(QPointF(cx, cy), base_r * 0.65, base_r * 0.65)

        hi = QRadialGradient(cx - base_r * 0.18, cy - base_r * 0.18, base_r * 0.4)
        hi.setColorAt(0.0, QColor(255, 255, 255, 220))
        hi.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setBrush(QBrush(hi))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(cx - base_r * 0.18, cy - base_r * 0.18), base_r * 0.25, base_r * 0.25)
        p.end()


# ── Animated Siri Fluid Hero Orb & Wave Canvas ───────────────────────────────
class HudCanvas(QWidget):
    wake_requested = pyqtSignal()

    def __init__(self, face_path: str = "", assistant_name: str = "JARVIS", parent=None):
        super().__init__(parent)
        self.setMinimumHeight(240)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self.muted, self.speaking, self.state = False, False, "ONLINE"
        self._assistant_name = assistant_name
        self.style_mode = "siri"  # "siri" or "reactor"
        self._tick = 0
        self._live_amp, self._amp_disp = 0.0, 0.0
        self._particles = []
        self._face_px = None
        self._load_face(face_path)

        # Arc Reactor parameters
        self._halo = 160.0
        self._rings = [0.0, 45.0, 90.0]
        self._scan, self._scan2 = 0.0, 180.0
        self._pulses = []

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._step)
        self._tmr.start(16)

    def set_audio_level(self, level: float) -> None:
        try:
            lv = max(0.0, min(1.0, float(level)))
            if lv > self._live_amp:
                self._live_amp = lv
        except (TypeError, ValueError):
            pass

    def _load_face(self, path: str):
        if not path or not Path(path).exists():
            self._face_px = None
            return
        try:
            from PIL import Image, ImageDraw
            import io
            img = Image.open(path).convert("RGBA")
            sz = min(img.size)
            img = img.resize((sz, sz), Image.LANCZOS)
            mk = Image.new("L", (sz, sz), 0)
            ImageDraw.Draw(mk).ellipse((2, 2, sz - 2, sz - 2), fill=255)
            img.putalpha(mk)
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            px = QPixmap()
            px.loadFromData(buf.getvalue())
            self._face_px = px
        except Exception:
            self._face_px = None

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.wake_requested.emit()
            e.accept()

    def _step(self):
        self._tick += 1
        self._live_amp *= 0.88
        self._amp_disp += (self._live_amp - self._amp_disp) * 0.35
        amp = self._amp_disp

        # Ambient floating micro-particles for Siri mode
        if (self.speaking or amp > 0.08) and random.random() < 0.25:
            cx, cy = self.width() / 2, self.height() / 2 - 15
            angle = random.uniform(0, 2 * math.pi)
            dist = random.uniform(40, 70 + amp * 40)
            self._particles.append([
                cx + math.cos(angle) * dist,
                cy + math.sin(angle) * dist,
                math.cos(angle) * random.uniform(0.6, 2.0),
                math.sin(angle) * random.uniform(0.6, 2.0),
                1.0,
                random.choice([C.PRI, C.ACC, C.ACC2, C.GREEN]),
            ])

        self._particles = [
            [p[0] + p[2], p[1] + p[3], p[2] * 0.96, p[3] * 0.96, p[4] - 0.025, p[5]]
            for p in self._particles if p[4] > 0
        ]

        # Reactor HUD animation updates
        spd = 1.0 + amp * 3.0
        self._rings[0] = (self._rings[0] + 0.8 * spd) % 360
        self._rings[1] = (self._rings[1] - 1.2 * spd) % 360
        self._rings[2] = (self._rings[2] + 1.6 * spd) % 360
        self._scan = (self._scan + 2.5 * spd) % 360
        self._scan2 = (self._scan2 - 1.8 * spd) % 360
        target_halo = 80.0 if self.state == "SLEEPING" else (220.0 if self.speaking else (180.0 if self.state == "LISTENING" else 140.0))
        target_halo += amp * 70.0
        self._halo += (target_halo - self._halo) * 0.15

        if (self.speaking or amp > 0.1) and self._tick % 12 == 0:
            self._pulses.append(10.0)
        self._pulses = [r + 2.0 + amp * 4.0 for r in self._pulses if r < 180.0]

        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        if not p.isActive():
            return
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        W, H = self.width(), self.height()
        cx, cy = W / 2.0, max(H * 0.42, H / 2.0 - 15.0)
        amp = self._amp_disp

        # Solid opaque background fill prevents dirty buffer artifacts
        p.fillRect(self.rect(), qcol(C.BG, 255))

        if self.style_mode == "reactor":
            self._paint_reactor(p, W, H, cx, cy, amp)
        else:
            self._paint_siri(p, W, H, cx, cy, amp)
        p.end()

    def _paint_siri(self, p: QPainter, W: float, H: float, cx: float, cy: float, amp: float):
        is_sleeping = (self.state == "SLEEPING")
        breath = math.sin(self._tick * 0.04) * 0.5 + 0.5 if is_sleeping else 0.0

        # Background radial glow
        bg_grad = QRadialGradient(cx, cy, max(W, H) * 0.6)
        bg_grad.setColorAt(0.0, qcol(C.PANEL, 120))
        bg_grad.setColorAt(0.5, qcol(C.BG, 200))
        bg_grad.setColorAt(1.0, qcol(C.BG, 255))
        p.fillRect(self.rect(), QBrush(bg_grad))

        # Ambient Siri Glow Aura
        if is_sleeping:
            base_r = 44.0 + breath * 4.0
            glow_r = base_r * 2.0
            glow = QRadialGradient(cx, cy, glow_r)
            glow.setColorAt(0.0, qcol(C.PRI, int(30 + breath * 25)))
            glow.setColorAt(0.5, qcol(C.ACC, int(15 + breath * 15)))
            glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        elif self.muted:
            base_r = 52.0 + math.sin(self._tick * 0.05) * 2.0
            glow_r = base_r * 2.2
            glow = QRadialGradient(cx, cy, glow_r)
            glow.setColorAt(0.0, qcol(C.MUTED_C, int(60 + amp * 60)))
            glow.setColorAt(0.5, qcol(C.MUTED_C, int(20 + amp * 20)))
            glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        else:
            base_r = 54.0 + amp * 32.0 + (math.sin(self._tick * 0.05) * 3.0)
            glow_r = base_r * 2.4
            glow = QRadialGradient(cx, cy, glow_r)
            glow.setColorAt(0.0, qcol(C.PRI, int(70 + amp * 90)))
            glow.setColorAt(0.35, qcol(C.ACC, int(45 + amp * 60)))
            glow.setColorAt(0.7, qcol(C.ACC2, int(25 + amp * 30)))
            glow.setColorAt(1.0, QColor(0, 0, 0, 0))

        p.setBrush(QBrush(glow))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(cx, cy), glow_r, glow_r)

        # Micro-particles shimmer
        if not is_sleeping:
            for pt in self._particles:
                col = qcol(pt[5], int(pt[4] * 200))
                p.setBrush(QBrush(col))
                p.drawEllipse(QPointF(pt[0], pt[1]), 2.2 * pt[4], 2.2 * pt[4])

        # Fluid Siri Undulating Harmonic Waves
        siri_layers = [
            (C.PRI,   1.2,  3,  0.06,  1.0),
            (C.ACC,  -0.9,  4, -0.05,  0.8),
            (C.ACC2,  1.5,  3,  0.08,  0.6),
            (C.GREEN, -1.3, 5, -0.07,  0.5),
        ]
        if self.muted:
            siri_layers = [(C.MUTED_C, 0.6, 3, 0.04, 0.7)]
        elif is_sleeping:
            siri_layers = [(C.PRI, 0.4, 3, 0.02, 0.35), (C.ACC, -0.3, 4, -0.02, 0.25)]

        p.setBrush(Qt.BrushStyle.NoBrush)
        points = 64
        for hex_col, speed, freq, spd, opac in siri_layers:
            c = qcol(hex_col, int(opac * 230 * (0.6 + amp * 0.4)))
            p.setPen(QPen(c, 2.4 if not is_sleeping else 1.5))

            path = QPainterPath()
            for i in range(points + 1):
                theta = (i / points) * 2 * math.pi
                shimmer = math.sin(theta * freq + self._tick * spd) * (2.0 if is_sleeping else (4.0 + amp * 22.0))
                shimmer += math.cos(theta * 2 - self._tick * 0.04) * (1.0 if is_sleeping else (2.0 + amp * 10.0))
                r = base_r + shimmer
                x = cx + r * math.cos(theta)
                y = cy + r * math.sin(theta)
                if i == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            path.closeSubpath()
            p.drawPath(path)

        # Core Siri Chromatic Rotating Sphere
        core_r = base_r * 0.68
        if self._face_px:
            fsz = int(core_r * 1.8)
            scaled = self._face_px.scaled(
                fsz, fsz,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            p.drawPixmap(int(cx - fsz / 2), int(cy - fsz / 2), scaled)
            p.setPen(QPen(qcol(C.PRI, 180), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QPointF(cx, cy), core_r, core_r)
        else:
            core_grad = QConicalGradient(cx, cy, self._tick * (0.8 if is_sleeping else 2.2))
            if self.muted:
                core_grad.setColorAt(0.0, qcol(C.MUTED_C, 240))
                core_grad.setColorAt(1.0, qcol("#590a18", 240))
            elif is_sleeping:
                core_grad.setColorAt(0.0, qcol(C.PRI, int(100 + breath * 60)))
                core_grad.setColorAt(0.5, qcol(C.ACC, int(80 + breath * 50)))
                core_grad.setColorAt(1.0, qcol(C.PRI, int(100 + breath * 60)))
            else:
                core_grad.setColorAt(0.0, qcol(C.PRI, 240))
                core_grad.setColorAt(0.28, qcol(C.ACC, 240))
                core_grad.setColorAt(0.56, qcol(C.ACC2, 240))
                core_grad.setColorAt(0.82, qcol(C.GREEN, 240))
                core_grad.setColorAt(1.0, qcol(C.PRI, 240))

            p.setBrush(QBrush(core_grad))
            p.setPen(QPen(QColor(255, 255, 255, 120 if is_sleeping else 200), 1.2))
            p.drawEllipse(QPointF(cx, cy), core_r, core_r)

            # Apple Siri Specular Crescent Highlight
            hl = QRadialGradient(cx - core_r * 0.28, cy - core_r * 0.28, core_r * 0.55)
            hl.setColorAt(0.0, QColor(255, 255, 255, 130 if is_sleeping else 230))
            hl.setColorAt(0.6, QColor(255, 255, 255, 30 if is_sleeping else 60))
            hl.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.setBrush(QBrush(hl))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QPointF(cx - core_r * 0.28, cy - core_r * 0.28), core_r * 0.38, core_r * 0.38)

        # Dynamic Status Label
        sy = min(H - 46.0, cy + base_r + 20.0)
        if self.muted:
            status_text = "Muted [F4]"
            status_col = qcol(C.MUTED_C)
            dot_sym = "⊘"
        elif self.speaking:
            status_text = "Speaking..."
            status_col = qcol(C.PRI)
            dot_sym = "●"
        elif self.state in ("THINKING", "PROCESSING"):
            status_text = "Thinking..."
            status_col = qcol(C.ACC)
            dot_sym = "◈"
        elif self.state == "LISTENING":
            status_text = "Listening..."
            status_col = qcol(C.GREEN)
            dot_sym = "●"
        elif is_sleeping:
            status_text = "Asleep — say 'Hey Jarvis' or tap to wake"
            status_col = qcol(C.TEXT_DIM)
            dot_sym = "💤"
        else:
            status_text = "How can I help you?"
            status_col = qcol(C.TEXT)
            dot_sym = "●"

        p.setFont(QFont("Segoe UI", 11, QFont.Weight.DemiBold))
        p.setPen(QPen(status_col, 1))
        p.drawText(QRectF(0, sy, W, 22), Qt.AlignmentFlag.AlignCenter, f"{dot_sym}  {status_text}")

        # Minimalist Siri Audio Waveform Beneath
        wy = min(H - 14.0, sy + 26.0)
        N = 32
        bw = 6
        spacing = 4
        total_wave_w = N * (bw + spacing)
        wx0 = (W - total_wave_w) / 2.0
        mid = (N - 1) / 2.0

        for i in range(N):
            env = math.exp(-0.5 * ((i - mid) / (N * 0.26)) ** 2)
            if self.muted:
                hgt = 2.0
                bar_c = qcol(C.MUTED_C, 120)
            elif is_sleeping:
                idle = 1.8 + 0.8 * math.sin(self._tick * 0.05 + i * 0.3)
                hgt = idle * env
                bar_c = qcol(C.PRI, 60)
            else:
                shimmer = 0.6 + 0.4 * math.sin(self._tick * 0.16 + i * 0.6)
                idle = 2.5 + 1.8 * math.sin(self._tick * 0.08 + i * 0.4)
                hgt = max(2.0, min(22.0, idle + amp * 24.0 * env * shimmer))
                bar_c = qcol(C.PRI if i % 2 == 0 else C.ACC, int(150 + amp * 105))

            p.setBrush(QBrush(bar_c))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(QRectF(wx0 + i * (bw + spacing), wy - hgt / 2, bw, hgt), 3, 3)

    def _paint_reactor(self, p: QPainter, W: float, H: float, cx: float, cy: float, amp: float):
        is_sleeping = (self.state == "SLEEPING")
        fw = min(W, H) * 0.76
        r_face = fw * 0.31

        # Background radial grid & glow
        bg_grad = QRadialGradient(cx, cy, fw * 0.9)
        bg_grad.setColorAt(0.0, qcol(C.PANEL, 140))
        bg_grad.setColorAt(0.6, qcol(C.BG, 220))
        bg_grad.setColorAt(1.0, qcol(C.BG, 255))
        p.fillRect(self.rect(), QBrush(bg_grad))

        # Pulse rings
        for pr in self._pulses:
            a = max(0, int(220 * (1.0 - pr / (fw * 0.74))))
            col = qcol(C.MUTED_C if self.muted else C.PRI, a)
            p.setPen(QPen(col, 1.5))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(cx - pr, cy - pr, pr * 2, pr * 2))

        # Spinning segmented arc rings
        for idx, (r_frac, w_r, arc_l, gap) in enumerate(
            [(0.48, 3, 115, 78), (0.40, 2, 78, 55), (0.32, 1.5, 56, 40)]
        ):
            ring_r = fw * r_frac
            base = self._rings[idx]
            a_val = max(0, min(255, int(self._halo * (1.0 - idx * 0.18))))
            col = qcol(C.MUTED_C if self.muted else (C.ACC if idx == 1 else C.PRI), a_val)
            p.setPen(QPen(col, w_r))
            p.setBrush(Qt.BrushStyle.NoBrush)
            rect = QRectF(cx - ring_r, cy - ring_r, ring_r * 2, ring_r * 2)
            angle = base
            while angle < base + 360:
                p.drawArc(rect, int(angle * 16), int(arc_l * 16))
                angle += arc_l + gap

        # Scanners
        sr = fw * 0.50
        sa = min(255, int(self._halo * 1.4))
        ex = 75 if self.speaking else 44
        p.setPen(QPen(qcol(C.MUTED_C if self.muted else C.PRI, sa), 2.5))
        srect = QRectF(cx - sr, cy - sr, sr * 2, sr * 2)
        p.drawArc(srect, int(self._scan * 16), int(ex * 16))
        p.setPen(QPen(qcol(C.ACC2 if not self.muted else C.MUTED_C, sa // 2), 1.5))
        p.drawArc(srect, int(self._scan2 * 16), int(ex * 16))

        # Tick marks
        t_out, t_in = fw * 0.497, fw * 0.474
        p.setPen(QPen(qcol(C.PRI, 120), 1))
        for deg in range(0, 360, 15):
            rad = math.radians(deg)
            inn = t_in if deg % 30 == 0 else t_in + 4
            p.drawLine(
                QPointF(cx + t_out * math.cos(rad), cy - t_out * math.sin(rad)),
                QPointF(cx + inn * math.cos(rad), cy - inn * math.sin(rad)),
            )

        # Center core
        core_r = r_face * 0.55
        p.setBrush(QBrush(qcol(C.MUTED_C, 160) if self.muted else qcol(C.PRI, int(80 + amp * 120))))
        p.setPen(QPen(qcol(C.WHITE, 200), 1.5))
        p.drawEllipse(QPointF(cx, cy), core_r, core_r)

        # Status text
        sy = min(H - 32.0, cy + fw * 0.44)
        if self.muted:
            status_text = "MUTED [F4]"
            status_col = qcol(C.MUTED_C)
        elif self.speaking:
            status_text = "TRANSMITTING..."
            status_col = qcol(C.PRI)
        elif self.state in ("THINKING", "PROCESSING"):
            status_text = "PROCESSING..."
            status_col = qcol(C.ACC)
        elif self.state == "LISTENING":
            status_text = "ONLINE // LISTENING"
            status_col = qcol(C.GREEN)
        elif is_sleeping:
            status_text = "STANDBY // SLEEPING (SAY 'HEY JARVIS')"
            status_col = qcol(C.TEXT_DIM)
        else:
            status_text = "STANDBY // READY"
            status_col = qcol(C.PRI)

        p.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        p.setPen(QPen(status_col, 1))
        p.drawText(QRectF(0, sy, W, 22), Qt.AlignmentFlag.AlignCenter, status_text)


# ── Compact Apple-Style Hardware Metric Pill ─────────────────────────────────
class MetricBar(QWidget):
    def __init__(self, label: str, color: str = C.PRI, parent=None):
        super().__init__(parent)
        self._label, self._color, self._value, self._text = label, color, 0.0, "--"
        self.setFixedHeight(26)
        self.setMinimumWidth(72)

    def set_value(self, pct: float, text: str):
        self._value = max(0.0, min(100.0, pct))
        self._text = text
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        if not p.isActive():
            return
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        W, H = self.width(), self.height()
        # Frosted glass capsule background
        p.setBrush(QBrush(QColor(255, 255, 255, 12)))
        p.setPen(QPen(QColor(255, 255, 255, 18), 1))
        p.drawRoundedRect(QRectF(1, 1, W - 2, H - 2), H / 2, H / 2)

        # Dynamic Status Dot
        dot_col = qcol(C.RED if self._value > 85 else (C.ACC2 if self._value > 65 else self._color))
        p.setBrush(QBrush(dot_col))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(9, H / 2), 3, 3)

        # Metric Label
        p.setFont(QFont("Segoe UI", 8, QFont.Weight.DemiBold))
        p.setPen(QPen(qcol(C.TEXT_DIM), 1))
        p.drawText(QRectF(16, 0, 32, H), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self._label)

        # Metric Value
        p.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        p.setPen(QPen(dot_col if self._text != "--" else qcol(C.TEXT_DIM), 1))
        p.drawText(QRectF(38, 0, W - 46, H), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, self._text)
        p.end()


# ── Apple Siri Activity / Conversation Stream ────────────────────────────────
class LogWidget(QTextEdit):
    _sig = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont("Segoe UI", 10))
        self.setStyleSheet(f"""
            QTextEdit {{
                background: transparent;
                color: {C.TEXT};
                border: none;
                padding: 10px 18px;
                selection-background-color: {C.PRI_DIM};
            }}
            QScrollBar:vertical {{
                background: transparent; width: 6px; margin: 4px;
            }}
            QScrollBar::handle:vertical {{
                background: rgba(255, 255, 255, 0.15); border-radius: 3px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: rgba(255, 255, 255, 0.3);
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)
        self._queue = []
        self._sig.connect(self._enqueue)

    def append_log(self, text: str):
        self._sig.emit(text)

    def _enqueue(self, text: str):
        text = text.strip()
        if not text:
            return

        tl = text.lower()
        if tl.startswith("you:"):
            msg = text[4:].strip()
            html = f"""
                <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-top: 6px; margin-bottom: 6px;">
                    <tr>
                        <td align="right">
                            <table border="0" cellpadding="8" cellspacing="0" style="background-color: #00364d; border: 1px solid {C.PRI}; border-radius: 12px;">
                                <tr>
                                    <td style="color: #ffffff; font-family: 'Segoe UI', sans-serif; font-size: 13px;">
                                        {msg}
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            """
        elif tl.startswith("jarvis:") or any(tl.startswith(f"{name}:") for name in ["ai", "assistant", "siri"]):
            parts = text.split(":", 1)
            msg = parts[1].strip() if len(parts) > 1 else text
            html = f"""
                <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-top: 6px; margin-bottom: 6px;">
                    <tr>
                        <td align="left">
                            <table border="0" cellpadding="8" cellspacing="0" style="background-color: #171a26; border: 1px solid #2e3449; border-radius: 12px;">
                                <tr>
                                    <td style="color: #f5f5f7; font-family: 'Segoe UI', sans-serif; font-size: 13px;">
                                        {msg}
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            """
        elif tl.startswith("file:"):
            msg = text[5:].strip()
            html = f"""
                <div align="center" style="margin: 4px 0px;">
                    <span style="color: {C.GREEN}; font-size: 11px; font-weight: bold;">📎 {msg}</span>
                </div>
            """
        elif "err" in tl:
            html = f"""
                <div align="center" style="margin: 4px 0px;">
                    <span style="color: {C.RED}; font-size: 11px;">⚠ {text}</span>
                </div>
            """
        else:
            html = f"""
                <div align="center" style="margin: 4px 0px;">
                    <span style="color: {C.TEXT_DIM}; font-size: 11px;">{text}</span>
                </div>
            """

        cur = self.textCursor()
        cur.movePosition(cur.MoveOperation.End)
        cur.insertHtml(html)
        self.setTextCursor(cur)
        self.ensureCursorVisible()


# ── Sleek File Attachment / Drop Zone ────────────────────────────────────────
class FileDropZone(QWidget):
    file_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._current_file = None
        self.setFixedHeight(32)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        self._chip = QWidget()
        self._chip.setStyleSheet(f"""
            QWidget {{
                background: rgba(48, 209, 88, 0.15);
                border: 1px solid rgba(48, 209, 88, 0.35);
                border-radius: 12px;
            }}
        """)
        chip_lay = QHBoxLayout(self._chip)
        chip_lay.setContentsMargins(10, 2, 8, 2)
        chip_lay.setSpacing(6)

        self._file_lbl = QLabel("")
        self._file_lbl.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self._file_lbl.setStyleSheet(f"color: {C.GREEN}; border: none;")
        chip_lay.addWidget(self._file_lbl)

        clear_btn = QPushButton("✕")
        clear_btn.setFixedSize(16, 16)
        clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        clear_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #86868b; border: none; font-size: 10px;
            }
            QPushButton:hover { color: #ffffff; }
        """)
        clear_btn.clicked.connect(self._clear_file)
        chip_lay.addWidget(clear_btn)

        lay.addWidget(self._chip)
        lay.addStretch()
        self.hide()

    def _set_file(self, path: str):
        self._current_file = path
        self._file_lbl.setText(f"📎  {Path(path).name}")
        self.show()
        self.file_selected.emit(path)

    def _clear_file(self):
        self._current_file = None
        self.hide()

    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e: QDropEvent):
        urls = e.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if Path(path).is_file():
                self._set_file(path)


# ── Circular Hue Color Picker ────────────────────────────────────────────────
class HueWheel(QWidget):
    hue_picked = pyqtSignal(str)
    hue_committed = pyqtSignal(str)
    _RING = 14

    def __init__(self, initial_hex: str = DEFAULT_UI_COLOR, parent=None):
        super().__init__(parent)
        self.setFixedSize(140, 140)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hue, self._drag = 0.53, False
        self.set_color(initial_hex)

    def color(self) -> str:
        return QColor.fromHsvF(self._hue, 1.0, 1.0).name()

    def set_color(self, hex_str: str):
        c = QColor((hex_str or "").strip())
        if c.isValid() and c.hsvHueF() >= 0:
            self._hue = c.hsvHueF()
            self.update()

    def _ring_rect(self) -> QRectF:
        m = self._RING / 2 + 3
        return QRectF(self.rect()).adjusted(m, m, -m, -m)

    def _hue_from_pos(self, pos: QPointF) -> float:
        c = QRectF(self.rect()).center()
        return (math.atan2(c.y() - pos.y(), pos.x() - c.x()) / (2 * math.pi)) % 1.0

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self._ring_rect()
        center = rect.center()
        grad = QConicalGradient(center, 0)
        for i in range(0, 361, 20):
            grad.setColorAt(i / 360.0, QColor.fromHsvF((i % 360) / 360.0, 1.0, 1.0))
        p.setPen(QPen(QBrush(grad), self._RING))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(rect)

        p.setPen(QPen(qcol(C.BORDER_B), 1))
        p.setBrush(QBrush(QColor.fromHsvF(self._hue, 1.0, 1.0)))
        p.drawEllipse(rect.adjusted(24, 24, -24, -24))

        r = rect.width() / 2
        ang = self._hue * 2 * math.pi
        hx, hy = center.x() + r * math.cos(ang), center.y() - r * math.sin(ang)
        p.setPen(QPen(QColor("#00060a"), 2))
        p.setBrush(QBrush(QColor("#ffffff")))
        p.drawEllipse(QPointF(hx, hy), 6.0, 6.0)
        p.end()

    def mousePressEvent(self, e):
        self._drag = True
        self._hue = self._hue_from_pos(e.position())
        self.update()
        self.hue_picked.emit(self.color())

    def mouseMoveEvent(self, e):
        if self._drag:
            self._hue = self._hue_from_pos(e.position())
            self.update()
            self.hue_picked.emit(self.color())

    def mouseReleaseEvent(self, e):
        if self._drag:
            self._drag = False
            self.hue_committed.emit(self.color())


# ── Apple-Style Unified Settings Dialog ──────────────────────────────────────
class SettingsDialog(QDialog):
    saved = pyqtSignal(dict)

    def __init__(self, parent=None, get_plugins_fn=None):
        super().__init__(parent)
        self.setWindowTitle("System Settings & Preferences")
        self.setFixedSize(580, 540)
        self.setStyleSheet(f"""
            QDialog {{
                background: #141620;
                border: 1px solid #282d3f;
                border-radius: 14px;
            }}
            QTabWidget::pane {{
                border: 1px solid #252a3b;
                background: #191c2b;
                border-radius: 10px;
                top: -1px;
            }}
            QTabBar::tab {{
                background: transparent;
                color: {C.TEXT_DIM};
                padding: 8px 18px;
                margin-right: 4px;
                border-radius: 6px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 9pt;
                font-weight: 500;
            }}
            QTabBar::tab:selected {{
                background: #23273a;
                color: {C.WHITE};
            }}
            QTabBar::tab:hover:!selected {{
                color: {C.TEXT};
            }}
            QLabel {{
                color: {C.TEXT};
                font-family: 'Segoe UI', sans-serif;
                font-size: 9pt;
            }}
            QLineEdit, QComboBox {{
                background: #12141f;
                color: {C.WHITE};
                border: 1px solid #2b3145;
                padding: 6px 10px;
                border-radius: 6px;
                font-family: 'Segoe UI', sans-serif;
            }}
            QLineEdit:focus, QComboBox:focus {{
                border: 1px solid {C.PRI};
            }}
            QPushButton {{
                background: #23273a;
                color: {C.WHITE};
                border: 1px solid #2f354d;
                border-radius: 6px;
                padding: 6px 14px;
                font-family: 'Segoe UI', sans-serif;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background: #2b3046;
                border-color: {C.PRI};
            }}
            QScrollArea {{
                border: none;
                background: transparent;
            }}
        """)
        self._get_plugins = get_plugins_fn
        self._cfg = _read_full_config()
        self._initial_color = self._cfg.get("ui_color") or DEFAULT_UI_COLOR
        self._cur_color = self._initial_color

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 18, 18, 18)
        lay.setSpacing(14)

        self.tabs = QTabWidget()
        lay.addWidget(self.tabs)

        self.tabs.addTab(self._tab_general(), "Identity && UI")
        self.tabs.addTab(self._tab_audio(), "Audio")
        self.tabs.addTab(self._tab_system(), "System")
        self.tabs.addTab(self._tab_memory(), "Memory")
        self.tabs.addTab(self._tab_plugins(), "Plugins")

        btn_row = QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        apply_btn = QPushButton("Save && Apply")
        apply_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C.PRI};
                color: #00060a;
                border: none;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: #38d6ff;
            }}
        """)
        apply_btn.clicked.connect(self._save)
        btn_row.addWidget(apply_btn)

        lay.addLayout(btn_row)

    def _tab_general(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)

        lay.addWidget(QLabel("Assistant Identifier:"))
        self._name_in = QLineEdit(self._cfg.get("assistant_name", "JARVIS"))
        lay.addWidget(self._name_in)

        lay.addWidget(QLabel("User Name (optional):"))
        self._user_in = QLineEdit(self._cfg.get("user_name", ""))
        lay.addWidget(self._user_in)

        lay.addWidget(QLabel("Gemini API Key (starts with AIzaSy...):"))
        self._key_in = QLineEdit(self._cfg.get("gemini_api_key", ""))
        self._key_in.setEchoMode(QLineEdit.EchoMode.Password)
        self._key_in.setPlaceholderText("AIzaSy... (free key at aistudio.google.com/apikey)")
        lay.addWidget(self._key_in)

        lay.addSpacing(6)
        lay.addWidget(QLabel("Accent Color Theme:"))
        chdr = QHBoxLayout()
        self._wheel = HueWheel(self._cur_color)
        self._wheel.hue_committed.connect(self._on_color_pick)
        chdr.addWidget(self._wheel)

        vbox = QVBoxLayout()
        self._hex_in = QLineEdit(self._cur_color)
        self._hex_in.textEdited.connect(self._on_color_pick)
        def_btn = QPushButton("Reset to Default")
        def_btn.clicked.connect(lambda: self._on_color_pick(DEFAULT_UI_COLOR))
        vbox.addWidget(self._hex_in)
        vbox.addWidget(def_btn)
        vbox.addStretch()
        chdr.addLayout(vbox)
        lay.addLayout(chdr)

        lay.addSpacing(10)
        lay.addWidget(QLabel("Visualizer Style:"))
        self._style_combo = QComboBox()
        self._style_combo.addItem("Apple Siri (Fluid Hero Orb & Waves)", "siri")
        self._style_combo.addItem("Arc Reactor (Classic Iron Man HUD)", "reactor")
        cur_style = self._cfg.get("ui_style", "siri")
        idx = self._style_combo.findData(cur_style)
        self._style_combo.setCurrentIndex(max(0, idx))
        lay.addWidget(self._style_combo)

        lay.addStretch()
        return w

    def _on_color_pick(self, hex_val: str):
        if hex_val.startswith("#") and len(hex_val) == 7:
            self._cur_color = hex_val
            self._hex_in.setText(hex_val)
            self._wheel.set_color(hex_val)
            old = current_palette()
            if apply_ui_accent(hex_val):
                retheme_all_widgets(old, current_palette())

    def _tab_audio(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)

        try:
            from memory.config_manager import AVAILABLE_VOICES, DEFAULT_VOICE, get_input_device, get_output_device
            from core.audio_devices import list_devices, DEFAULT_LABEL
        except ImportError:
            AVAILABLE_VOICES, DEFAULT_VOICE = ["Puck", "Charon", "Kore", "Fenrir", "Aoede"], "Puck"
            get_input_device = lambda: ""
            get_output_device = lambda: ""
            list_devices = lambda _: []
            DEFAULT_LABEL = "Default"

        lay.addWidget(QLabel("Prebuilt Assistant Voice:"))
        self._voice_combo = QComboBox()
        for v in AVAILABLE_VOICES:
            self._voice_combo.addItem(v, v)
        self._voice_combo.setCurrentText(self._cfg.get("voice_name") or DEFAULT_VOICE)
        lay.addWidget(self._voice_combo)

        lay.addWidget(QLabel("Input Microphone:"))
        self._in_combo = QComboBox()
        self._in_combo.addItem(DEFAULT_LABEL, "")
        for d in list_devices("input"):
            self._in_combo.addItem(d, d)
        self._in_combo.setCurrentIndex(max(0, self._in_combo.findData(get_input_device())))
        lay.addWidget(self._in_combo)

        lay.addWidget(QLabel("Output Speaker:"))
        self._out_combo = QComboBox()
        self._out_combo.addItem(DEFAULT_LABEL, "")
        for d in list_devices("output"):
            self._out_combo.addItem(d, d)
        self._out_combo.setCurrentIndex(max(0, self._out_combo.findData(get_output_device())))
        lay.addWidget(self._out_combo)
        lay.addStretch()
        return w

    def _tab_system(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(12)

        try:
            from core.shortcut_manager import is_autostart_enabled
            auto_state = "ON" if is_autostart_enabled() else "OFF"
        except Exception:
            auto_state = "OFF"
        self._auto_btn = QPushButton(f"Toggle Auto-Start ({auto_state})")
        self._auto_btn.clicked.connect(self._toggle_autostart_clicked)
        lay.addWidget(self._auto_btn)

        self._shor_btn = QPushButton("Re-Create Desktop Shortcut")
        self._shor_btn.clicked.connect(self._create_shortcut_clicked)
        lay.addWidget(self._shor_btn)

        self._mb_btn = QPushButton("Morning Brief: ON")
        self._mb_btn.clicked.connect(self._toggle_mb)
        lay.addWidget(self._mb_btn)

        self._remote_btn = QPushButton("📱 Connect Mobile & Remote Control")
        self._remote_btn.clicked.connect(self._open_remote_from_settings)
        lay.addWidget(self._remote_btn)

        lay.addStretch()
        return w

    def _open_remote_from_settings(self):
        if self.parent() and hasattr(self.parent(), "_open_remote_dialog"):
            self.parent()._open_remote_dialog()

    def _toggle_autostart_clicked(self):
        try:
            from core.shortcut_manager import toggle_autostart, is_autostart_enabled
            ok, msg = toggle_autostart()
            if self.parent() and hasattr(self.parent(), "_log"):
                self.parent()._log.append_log(f"SYS: {msg}" if ok else f"ERR: {msg}")
            state = "ON" if is_autostart_enabled() else "OFF"
            self._auto_btn.setText(f"Toggle Auto-Start ({state})")
        except Exception as e:
            if self.parent() and hasattr(self.parent(), "_log"):
                self.parent()._log.append_log(f"ERR: Auto-start error: {e}")

    def _create_shortcut_clicked(self):
        try:
            from core.shortcut_manager import create_desktop_shortcut
            ok, msg = create_desktop_shortcut()
            if self.parent() and hasattr(self.parent(), "_log"):
                self.parent()._log.append_log(f"SYS: {msg}" if ok else f"ERR: {msg}")
            if ok:
                self._shor_btn.setText("✓ Desktop Shortcut Created")
            else:
                self._shor_btn.setText("⚠️ Failed to Create Shortcut")
        except Exception as e:
            if self.parent() and hasattr(self.parent(), "_log"):
                self.parent()._log.append_log(f"ERR: Shortcut error: {e}")

    def _toggle_mb(self):
        try:
            from memory.config_manager import get_brief_enabled, save_brief_enabled
            nv = not get_brief_enabled()
            save_brief_enabled(nv)
            self._mb_btn.setText(f"Morning Brief: {'ON' if nv else 'OFF'}")
        except Exception:
            pass

    def _tab_memory(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(12, 12, 12, 12)
        try:
            from memory.memory_manager import all_entries_for_ui, forget
            rows = all_entries_for_ui()
        except ImportError:
            rows = []
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        ilay = QVBoxLayout(inner)
        ilay.setSpacing(6)
        for r in rows:
            line = QHBoxLayout()
            lbl = QLabel(f"{r['key']}: {r['value']}")
            lbl.setStyleSheet("background: #141724; padding: 6px 10px; border-radius: 6px;")
            del_b = QPushButton("✕")
            del_b.setFixedSize(24, 24)
            del_b.clicked.connect(lambda _, c=r["category"], k=r["key"]: (forget(k, c), self._refresh_mem(ilay)))
            line.addWidget(lbl, 1)
            line.addWidget(del_b)
            ilay.addLayout(line)
        ilay.addStretch()
        scroll.setWidget(inner)
        lay.addWidget(scroll)
        return w

    def _refresh_mem(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                while item.layout().count():
                    c = item.layout().takeAt(0)
                    if c.widget():
                        c.widget().deleteLater()

    def _tab_plugins(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(12, 12, 12, 12)
        plugins = self._get_plugins() if self._get_plugins else []
        for p in plugins:
            row = QHBoxLayout()
            lbl = QLabel(p["name"])
            lbl.setStyleSheet("background: #141724; padding: 6px 10px; border-radius: 6px;")
            btn = QPushButton("ON" if p.get("enabled", True) else "OFF")
            btn.setFixedSize(54, 28)
            btn.clicked.connect(lambda _, n=p["name"], b=btn: self._toggle_p(n, b))
            row.addWidget(lbl, 1)
            row.addWidget(btn)
            lay.addLayout(row)
        lay.addStretch()
        return w

    def _toggle_p(self, name: str, btn: QPushButton):
        try:
            from memory.config_manager import get_plugin_enabled, save_plugin_enabled
            nv = not get_plugin_enabled(name)
            save_plugin_enabled(name, nv)
            btn.setText("ON" if nv else "OFF")
        except Exception:
            pass

    def _save(self):
        try:
            from memory.config_manager import save_voice, save_input_device, save_output_device
            save_voice(self._voice_combo.currentText())
            save_input_device(self._in_combo.currentData() or "")
            save_output_device(self._out_combo.currentData() or "")
        except Exception:
            pass

        res = {
            "assistant_name": self._name_in.text().strip() or "JARVIS",
            "user_name": self._user_in.text().strip(),
            "ui_color": self._cur_color,
            "ui_style": self._style_combo.currentData() or "siri",
            "voice_name": self._voice_combo.currentText(),
        }
        key_val = self._key_in.text().strip()
        if key_val:
            res["gemini_api_key"] = key_val
        self.saved.emit(res)
        self.accept()


# ── Apple-Style First-Boot Setup Modal ───────────────────────────────────────
class SetupOverlay(QWidget):
    done = pyqtSignal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(f"""
            SetupOverlay {{
                background: rgba(16, 18, 28, 0.96);
                border: 1px solid #2e354c;
                border-radius: 14px;
            }}
        """)
        detected = {"darwin": "mac", "windows": "windows"}.get(_OS.lower(), "linux")
        self._sel_os = detected

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(10)

        lbl = QLabel("Initialisation Required")
        lbl.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        lbl.setStyleSheet(f"color: {C.WHITE};")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(lbl)

        sub = QLabel("Enter your Gemini API Key to activate assistant intelligence.")
        sub.setFont(QFont("Segoe UI", 9))
        sub.setStyleSheet(f"color: {C.TEXT_DIM};")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(sub)

        layout.addSpacing(6)
        self._key_input = QLineEdit()
        self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self._key_input.setPlaceholderText("AIzaSy... (from aistudio.google.com/apikey)")
        self._key_input.setFont(QFont("Segoe UI", 9))
        self._key_input.setFixedHeight(36)
        self._key_input.setStyleSheet(f"""
            QLineEdit {{
                background: #10121b; color: {C.WHITE};
                border: 1px solid #2d3348; border-radius: 8px; padding: 4px 10px;
            }}
            QLineEdit:focus {{ border: 1px solid {C.PRI}; }}
        """)
        layout.addWidget(self._key_input)

        self._err_lbl = QLabel()
        self._err_lbl.setFont(QFont("Segoe UI", 8))
        self._err_lbl.setStyleSheet("color: #ff453a;")
        self._err_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._err_lbl.hide()
        layout.addWidget(self._err_lbl)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        offline_btn = QPushButton("⚡ Continue in Offline Mode")
        offline_btn.setFont(QFont("Segoe UI", 9))
        offline_btn.setFixedHeight(38)
        offline_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        offline_btn.setStyleSheet("""
            QPushButton {
                background: #23273a; color: #ffffff;
                border: 1px solid #363d59; border-radius: 8px; padding: 0 12px;
            }
            QPushButton:hover { background: #2c324b; }
        """)
        offline_btn.clicked.connect(self._continue_offline)
        btn_row.addWidget(offline_btn)

        init_btn = QPushButton("Activate Systems")
        init_btn.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        init_btn.setFixedHeight(38)
        init_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        init_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C.PRI}; color: #00060a;
                border: none; border-radius: 8px;
            }}
            QPushButton:hover {{ background: #38d6ff; }}
        """)
        init_btn.clicked.connect(self._submit)
        btn_row.addWidget(init_btn)

        layout.addLayout(btn_row)

    def _continue_offline(self):
        self.done.emit("", self._sel_os)

    def _submit(self):
        k = self._key_input.text().strip()
        if not k:
            self._err_lbl.setText("Please paste a Gemini API key or click 'Continue in Offline Mode'.")
            self._err_lbl.show()
            return
        if not (k.startswith("AIzaSy") and len(k) >= 35):
            self._err_lbl.setText("Google AI Studio keys start with 'AIzaSy'. (Or click Offline Mode).")
            self._err_lbl.show()
            return
        self._err_lbl.hide()
        self.done.emit(k, self._sel_os)


# ── Confirmation Action Gate ─────────────────────────────────────────────────
class ConfirmBanner(QWidget):
    answered = pyqtSignal(bool)

    def __init__(self, title: str, detail: str, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedWidth(380)
        self.setStyleSheet(f"""
            ConfirmBanner {{
                background: rgba(26, 18, 20, 0.96);
                border: 1px solid rgba(255, 69, 58, 0.4);
                border-radius: 12px;
            }}
        """)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        h = QLabel(f"⚠  {title}")
        h.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        h.setStyleSheet(f"color: {C.RED};")
        lay.addWidget(h)

        if detail:
            d = QLabel(detail)
            d.setWordWrap(True)
            d.setFont(QFont("Segoe UI", 9))
            d.setStyleSheet(f"color: {C.TEXT_MED};")
            lay.addWidget(d)

        row = QHBoxLayout()
        row.setSpacing(8)
        no = QPushButton("Cancel")
        no.setStyleSheet("background: #252836; color: #ffffff; border-radius: 6px; padding: 6px 14px;")
        no.clicked.connect(lambda: self.answered.emit(False))

        yes = QPushButton("Confirm")
        yes.setStyleSheet(f"background: {C.RED}; color: #ffffff; font-weight: bold; border-radius: 6px; padding: 6px 14px;")
        yes.clicked.connect(lambda: self.answered.emit(True))

        row.addStretch()
        row.addWidget(no)
        row.addWidget(yes)
        lay.addLayout(row)


# ── Remote Control & QR Pairing Dialog ───────────────────────────────────────
class RemoteControlDialog(QDialog):
    def __init__(self, parent=None, get_remote_info_fn=None):
        super().__init__(parent)
        self.setWindowTitle("JARVIS — Mobile Remote Control & QR Pairing")
        self.setFixedSize(450, 580)
        self._get_remote_info = get_remote_info_fn
        self._current_url = ""
        self._current_key = ""
        self._current_autologin = ""

        self.setStyleSheet(f"""
            QDialog {{
                background: #141620;
                border: 1px solid #282d3f;
                border-radius: 14px;
            }}
            QLabel {{
                color: {C.WHITE};
                font-family: 'Segoe UI', sans-serif;
            }}
            QPushButton {{
                background: #23273a;
                color: {C.WHITE};
                border: 1px solid #2f354d;
                border-radius: 8px;
                padding: 8px 14px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 9pt;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background: #2b3046;
                border-color: {C.PRI};
            }}
        """)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 20)
        lay.setSpacing(10)

        # Header
        hdr = QLabel("📱 Mobile Remote Control")
        hdr.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        sub = QLabel("Scan QR code with your mobile camera to connect instantly.")
        sub.setFont(QFont("Segoe UI", 9))
        sub.setStyleSheet(f"color: {C.TEXT_DIM};")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)

        # QR Code Display Container
        self._qr_frame = QFrame()
        self._qr_frame.setStyleSheet("""
            QFrame {
                background: #ffffff;
                border-radius: 12px;
                padding: 10px;
            }
        """)
        qr_lay = QVBoxLayout(self._qr_frame)
        qr_lay.setContentsMargins(8, 8, 8, 8)
        self._qr_label = QLabel()
        self._qr_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._qr_label.setFixedSize(220, 220)
        qr_lay.addWidget(self._qr_label, alignment=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._qr_frame, alignment=Qt.AlignmentFlag.AlignCenter)

        # Pairing PIN Box
        self._pin_label = QLabel("PIN:  ------")
        self._pin_label.setFont(QFont("Consolas", 14, QFont.Weight.Bold))
        self._pin_label.setStyleSheet(f"color: {C.PRI}; letter-spacing: 3px;")
        self._pin_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._pin_label)

        # Connection URL
        self._url_label = QLabel("URL: http://...")
        self._url_label.setFont(QFont("Segoe UI", 9))
        self._url_label.setStyleSheet(f"color: {C.TEXT_MED};")
        self._url_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._url_label)

        # Live Status
        self._status_label = QLabel("🟢 Ready for connection on Wi-Fi")
        self._status_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self._status_label.setStyleSheet(f"color: {C.GREEN};")
        self._status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._status_label)

        # Action Buttons Row 1 (Copy Link & New Code)
        row1 = QHBoxLayout()
        row1.setSpacing(8)
        self._copy_btn = QPushButton("📋 Copy Link")
        self._copy_btn.clicked.connect(self._copy_link)
        row1.addWidget(self._copy_btn)

        self._refresh_btn = QPushButton("🔄 New Code")
        self._refresh_btn.clicked.connect(self.refresh_qr)
        row1.addWidget(self._refresh_btn)
        lay.addLayout(row1)

        # Action Buttons Row 2 (Open in Browser & Done)
        row2 = QHBoxLayout()
        row2.setSpacing(8)
        self._browser_btn = QPushButton("🌐 Open Browser")
        self._browser_btn.clicked.connect(self._open_in_browser)
        row2.addWidget(self._browser_btn)

        close_btn = QPushButton("Done")
        close_btn.setStyleSheet(f"background: {C.PRI}; color: #000; font-weight: bold;")
        close_btn.clicked.connect(self.accept)
        row2.addWidget(close_btn)
        lay.addLayout(row2)

        # Initial generation
        self.refresh_qr()

    def refresh_qr(self):
        if not self._get_remote_info:
            self._status_label.setText("⚠️ Remote callback unavailable")
            self._status_label.setStyleSheet(f"color: {C.RED};")
            return

        res = self._get_remote_info()
        if not res:
            self._status_label.setText("⚠️ Dashboard server unavailable. Check terminal.")
            self._status_label.setStyleSheet(f"color: {C.RED};")
            self._pin_label.setText("PIN: N/A")
            self._url_label.setText("Start dashboard server to enable remote")
            return

        url, key, autologin_url, manual_url = res
        self._current_url = url
        self._current_key = key
        self._current_autologin = autologin_url

        self._pin_label.setText(f"PIN:  {'  '.join(key)}")
        self._url_label.setText(f"Manual URL: {manual_url}")
        self._status_label.setText("🟢 Server Active • Scan to Pair")
        self._status_label.setStyleSheet(f"color: {C.GREEN};")

        # Generate QR Code image dynamically
        try:
            import io
            import qrcode
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_M,
                box_size=6,
                border=1,
            )
            qr.add_data(autologin_url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="#000000", back_color="#ffffff")

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            pix = QPixmap()
            pix.loadFromData(buf.getvalue(), "PNG")
            self._qr_label.setPixmap(pix.scaled(200, 200, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except Exception as e:
            self._status_label.setText(f"QR Error: {e}")
            self._status_label.setStyleSheet(f"color: {C.RED};")

    def notify_connected(self):
        self._status_label.setText("📱 Mobile Device Connected!")
        self._status_label.setStyleSheet("color: #86efac; font-size: 10pt; font-weight: bold;")

    def _copy_link(self):
        if self._current_autologin:
            QApplication.clipboard().setText(self._current_autologin)
            self._copy_btn.setText("✓ Copied!")
            QTimer.singleShot(1800, lambda: self._copy_btn.setText("📋 Copy Link"))

    def _open_in_browser(self):
        if self._current_autologin:
            QDesktopServices.openUrl(QUrl(self._current_autologin))


# ── Main Application Window (Siri Design) ────────────────────────────────────
class MainWindow(QMainWindow):
    _log_sig = pyqtSignal(str)
    _state_sig = pyqtSignal(str)
    _content_sig = pyqtSignal(str, str)
    _confirm_sig = pyqtSignal(str, str)
    _confirm_hide_sig = pyqtSignal()
    _reconfig_sig = pyqtSignal()

    def __init__(self, face_path: str = ""):
        super().__init__()
        self._face_path = face_path
        self._cfg = _read_full_config()
        self._assistant_name = (self._cfg.get("assistant_name") or "JARVIS").strip()
        self._ui_style = self._cfg.get("ui_style", "siri")
        self._muted = False
        self._ready = self._check_config()
        self._overlay = None
        self._confirm_overlay = None
        self._remote_dialog = None

        if self._cfg.get("ui_color"):
            apply_ui_accent(self._cfg["ui_color"])

        self.setWindowTitle(f"{self._assistant_name.upper()} — Voice Assistant")
        self.setMinimumSize(_MIN_W, _MIN_H)
        self.resize(_DEFAULT_W, _DEFAULT_H)
        self.setAcceptDrops(True)

        self.on_text_command = None
        self.on_interrupt = None
        self.on_voice_change = None
        self.on_audio_device_change = None
        self.on_remote_clicked = None
        self.get_plugins = None

        central = QWidget()
        central.setStyleSheet(f"background: {C.BG};")
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 12, 16, 16)
        root.setSpacing(10)

        # Top Bar (Metrics + Title + Actions)
        root.addWidget(self._build_top_bar())

        # Middle Content Area (Splitter: Siri Orb + Conversation Stream)
        self.hud = HudCanvas(face_path, self._assistant_name.upper())
        self.hud.style_mode = self._ui_style
        self.hud.wake_requested.connect(self._on_hud_wake_tap)
        self._log = LogWidget()
        self._content_panel = self._build_content_panel()

        self._center_split = QSplitter(Qt.Orientation.Vertical)
        self._center_split.setHandleWidth(1)
        self._center_split.setStyleSheet("QSplitter::handle { background: transparent; }")
        self._center_split.addWidget(self.hud)

        conv_container = QWidget()
        conv_lay = QVBoxLayout(conv_container)
        conv_lay.setContentsMargins(0, 0, 0, 0)
        conv_lay.addWidget(self._log, stretch=1)
        conv_lay.addWidget(self._content_panel, stretch=0)
        self._center_split.addWidget(conv_container)
        self._center_split.setStretchFactor(0, 4)
        self._center_split.setStretchFactor(1, 3)

        root.addWidget(self._center_split, stretch=1)

        # Attached file preview zone
        self._drop_zone = FileDropZone()
        self._drop_zone.file_selected.connect(self._on_file_selected)
        root.addWidget(self._drop_zone)

        # Floating Bottom Siri Capsule Bar
        root.addWidget(self._build_input_capsule())

        # Siri Floating Orb Widget (F12)
        self._orb = OrbFloatingWidget()
        self._orb.expand_requested.connect(self._restore_from_orb)
        self._orb.mute_toggled.connect(self._toggle_mute)
        self._orb.settings_requested.connect(self._open_settings_from_orb)
        self._orb.quit_requested.connect(QApplication.quit)

        # Periodic Timers
        self._metric_tmr = QTimer(self)
        self._metric_tmr.timeout.connect(self._update_metrics)
        self._metric_tmr.start(2000)

        # Signal Connections
        self._log_sig.connect(self._log.append_log)
        self._state_sig.connect(self._apply_state)
        self._content_sig.connect(self._show_content)
        self._confirm_sig.connect(self._show_confirm_banner)
        self._confirm_hide_sig.connect(self._hide_confirm_banner)
        self._reconfig_sig.connect(self._show_setup)

        if not self._ready:
            self._show_setup()

        # Keyboard Shortcuts
        QShortcut(QKeySequence("F4"), self).activated.connect(self._toggle_mute)
        QShortcut(QKeySequence("F11"), self).activated.connect(self._toggle_fullscreen)
        QShortcut(QKeySequence("F12"), self).activated.connect(self._minimize_to_orb)
        QShortcut(QKeySequence("Escape"), self).activated.connect(lambda: self.on_interrupt() if self.on_interrupt else None)

    # ── Drag and Drop onto Entire Window ─────────────────────────────────────
    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e: QDropEvent):
        urls = e.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if Path(path).is_file():
                self._drop_zone._set_file(path)

    def changeEvent(self, event):
        super().changeEvent(event)

    def _minimize_to_orb(self):
        screen = QApplication.primaryScreen().availableGeometry()
        x = max(20, screen.right() - 165)
        y = max(20, screen.bottom() - 165)
        self._orb.move(x, y)
        self._orb.muted = self._muted
        self._orb.speaking = self.hud.speaking
        self._orb.show()
        self.hide()

    def _restore_from_orb(self):
        self._orb.hide()
        self.setWindowState(Qt.WindowState.WindowNoState)
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def _check_config(self) -> bool:
        if not API_FILE.exists():
            return False
        try:
            d = json.loads(API_FILE.read_text(encoding="utf-8"))
            return bool(d.get("os_system"))
        except Exception:
            return False

    def _show_setup(self):
        if self._overlay:
            return
        cw = self.centralWidget()
        ov = SetupOverlay(cw)
        ow, oh = 440, 260
        ov.setGeometry((cw.width() - ow) // 2, (cw.height() - oh) // 2, ow, oh)
        ov.done.connect(self._on_setup_done)
        ov.show()
        self._overlay = ov

    def _on_setup_done(self, key: str, os_name: str):
        os.makedirs(CONFIG_DIR, exist_ok=True)
        data = _read_full_config()
        data["gemini_api_key"] = key
        data["os_system"] = os_name
        API_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
        self._ready = True
        if self._overlay:
            self._overlay.hide()
            self._overlay.deleteLater()
            self._overlay = None
        self._log.append_log(f"SYS: Initialised with OS {os_name.upper()}.")

    # ── Minimal Apple Siri Top Header ────────────────────────────────────────
    def _build_top_bar(self) -> QWidget:
        w = QWidget()
        w.setFixedHeight(36)
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        # Subtle Horizontal Hardware Metrics Pill
        self._bar_cpu = MetricBar("CPU", C.PRI)
        self._bar_mem = MetricBar("RAM", C.ACC)
        self._bar_net = MetricBar("NET", C.GREEN)
        self._bar_gpu = MetricBar("GPU", C.ACC2)
        self._bar_tmp = MetricBar("TMP", "#ff6688")

        for b in [self._bar_cpu, self._bar_mem, self._bar_net, self._bar_gpu, self._bar_tmp]:
            lay.addWidget(b)

        lay.addStretch()

        # Title Label
        self._title_lbl = QLabel(self._assistant_name.upper())
        self._title_lbl.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self._title_lbl.setStyleSheet(f"color: {C.WHITE}; letter-spacing: 1px;")
        lay.addWidget(self._title_lbl)

        lay.addStretch()

        # Minimal Apple Action Pill Buttons
        btn_style = """
            QPushButton {
                background: rgba(255, 255, 255, 0.06);
                color: #a1a1a6;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 13px;
                padding: 4px 10px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 8pt;
                font-weight: 500;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.14);
                color: #ffffff;
            }
        """
        self._style_btn = QPushButton("✦ Siri" if self._ui_style == "siri" else "✦ HUD")
        self._style_btn.setToolTip("Toggle Visualizer Style: Apple Siri vs Iron Man HUD")
        self._style_btn.setStyleSheet(btn_style)
        self._style_btn.clicked.connect(self._toggle_ui_style)
        lay.addWidget(self._style_btn)

        orb_btn = QPushButton("◉ Orb")
        orb_btn.setToolTip("Switch to Floating Orb Mode [F12]")
        orb_btn.setStyleSheet(btn_style)
        orb_btn.clicked.connect(self._minimize_to_orb)
        lay.addWidget(orb_btn)

        remote_btn = QPushButton("📱 Remote")
        remote_btn.setToolTip("Connect Mobile Device & Remote Control [QR Code]")
        remote_btn.setStyleSheet(btn_style)
        remote_btn.clicked.connect(self._open_remote_dialog)
        lay.addWidget(remote_btn)

        settings_btn = QPushButton("⚙ Settings")
        settings_btn.setToolTip("System Settings")
        settings_btn.setStyleSheet(btn_style)
        settings_btn.clicked.connect(self._open_settings)
        lay.addWidget(settings_btn)

        return w

    # ── Apple Siri Floating Input Capsule ────────────────────────────────────
    def _build_input_capsule(self) -> QWidget:
        capsule = QWidget()
        capsule.setFixedHeight(54)
        capsule.setStyleSheet(f"""
            QWidget {{
                background: rgba(22, 25, 36, 0.94);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 27px;
            }}
        """)
        lay = QHBoxLayout(capsule)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(8)

        # Attachment Button (File Picker)
        attach_btn = QPushButton("📎")
        attach_btn.setFixedSize(38, 38)
        attach_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        attach_btn.setToolTip("Attach File or Drop Here")
        attach_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {C.TEXT_MED};
                border: none;
                font-size: 14px;
                border-radius: 19px;
            }}
            QPushButton:hover {{
                background: rgba(255, 255, 255, 0.08);
                color: {C.WHITE};
            }}
        """)
        attach_btn.clicked.connect(self._browse_file)
        lay.addWidget(attach_btn)

        # Clean Line Input
        self._input = QLineEdit()
        self._input.setPlaceholderText(f"Ask {self._assistant_name} anything...")
        self._input.setFont(QFont("Segoe UI", 10))
        self._input.setStyleSheet(f"""
            QLineEdit {{
                background: transparent;
                color: {C.WHITE};
                border: none;
                padding: 0px 6px;
                font-size: 13px;
            }}
        """)
        self._input.returnPressed.connect(self._send_text)
        lay.addWidget(self._input, 1)

        # Microphone / Mute Pill Button
        self._mute_btn = QPushButton("🎙")
        self._mute_btn.setFixedSize(38, 38)
        self._mute_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mute_btn.setToolTip("Toggle Microphone [F4]")
        self._style_mute_btn()
        self._mute_btn.clicked.connect(self._toggle_mute)
        lay.addWidget(self._mute_btn)

        # Send Action Button
        snd_btn = QPushButton("↑")
        snd_btn.setFixedSize(38, 38)
        snd_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        snd_btn.setStyleSheet(f"""
            QPushButton {{
                background: {C.PRI};
                color: #00060a;
                border: none;
                font-size: 16px;
                font-weight: bold;
                border-radius: 19px;
            }}
            QPushButton:hover {{
                background: #3cd7ff;
            }}
        """)
        snd_btn.clicked.connect(self._send_text)
        lay.addWidget(snd_btn)

        return capsule

    def _style_mute_btn(self):
        if self._muted:
            self._mute_btn.setText("🔇")
            self._mute_btn.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(255, 69, 58, 0.2);
                    color: {C.MUTED_C};
                    border: 1px solid rgba(255, 69, 58, 0.4);
                    border-radius: 19px;
                    font-size: 14px;
                }}
            """)
        else:
            self._mute_btn.setText("🎙")
            self._mute_btn.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(48, 209, 88, 0.15);
                    color: {C.GREEN};
                    border: 1px solid rgba(48, 209, 88, 0.3);
                    border-radius: 19px;
                    font-size: 14px;
                }}
                QPushButton:hover {{
                    background: rgba(48, 209, 88, 0.28);
                }}
            """)

    # ── Apple Siri Content Card ──────────────────────────────────────────────
    def _build_content_panel(self) -> QWidget:
        w = QWidget()
        w.hide()
        w.setStyleSheet("""
            QWidget {
                background: rgba(20, 23, 34, 0.92);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 12px;
            }
        """)
        lay = QVBoxLayout(w)
        lay.setContentsMargins(14, 10, 14, 12)
        lay.setSpacing(8)

        hdr = QHBoxLayout()
        self._content_title = QLabel("Information Card")
        self._content_title.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self._content_title.setStyleSheet("color: #ffffff; border: none;")
        hdr.addWidget(self._content_title)
        hdr.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(20, 20)
        close_btn.setStyleSheet("background: transparent; color: #86868b; border: none; font-size: 11px;")
        close_btn.clicked.connect(w.hide)
        hdr.addWidget(close_btn)
        lay.addLayout(hdr)

        self._content_display = QTextEdit()
        self._content_display.setReadOnly(True)
        self._content_display.setFont(QFont("Segoe UI", 9))
        self._content_display.setStyleSheet(f"""
            QTextEdit {{
                background: transparent;
                color: {C.TEXT};
                border: none;
            }}
        """)
        lay.addWidget(self._content_display)
        return w

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select file", str(Path.home()), "All Files (*.*)")
        if path:
            self._drop_zone._set_file(path)

    def _open_remote_dialog(self):
        if hasattr(self, "_remote_dialog") and self._remote_dialog and self._remote_dialog.isVisible():
            self._remote_dialog.raise_()
            self._remote_dialog.activateWindow()
            return
        self._remote_dialog = RemoteControlDialog(self, get_remote_info_fn=self.on_remote_clicked)
        self._remote_dialog.exec()

    def notify_phone_connected(self):
        if hasattr(self, "_remote_dialog") and self._remote_dialog and self._remote_dialog.isVisible():
            self._remote_dialog.notify_connected()

    def _open_settings(self):
        diag = SettingsDialog(self, get_plugins_fn=self.get_plugins)
        diag.saved.connect(self._apply_settings)
        diag.exec()

    def _apply_settings(self, res: dict):
        self._assistant_name = res["assistant_name"]
        self._title_lbl.setText(self._assistant_name.upper())
        self.hud._assistant_name = self._assistant_name.upper()
        self._input.setPlaceholderText(f"Ask {self._assistant_name} anything...")

        if "ui_style" in res:
            self._set_ui_style(res["ui_style"])

        data = _read_full_config()
        data.update(res)
        API_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
        self._log.append_log("SYS: Settings successfully synchronized.")

        if self.on_voice_change:
            self.on_voice_change()
        if self.on_audio_device_change:
            self.on_audio_device_change()

    def _toggle_ui_style(self):
        new_style = "reactor" if self._ui_style == "siri" else "siri"
        self._set_ui_style(new_style)

    def _set_ui_style(self, style: str):
        self._ui_style = style
        self.hud.style_mode = style
        if hasattr(self, "_style_btn"):
            self._style_btn.setText("✦ Siri" if style == "siri" else "✦ HUD")
        cfg = _read_full_config()
        cfg["ui_style"] = style
        try:
            API_FILE.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
        except Exception:
            pass
        self.hud.update()

    def _open_settings_from_orb(self):
        self._restore_from_orb()
        self._open_settings()

    def _on_hud_wake_tap(self):
        if self.hud.state == "SLEEPING":
            if hasattr(self, "on_wake_manual") and self.on_wake_manual:
                self.on_wake_manual()
            elif self.on_text_command:
                self.on_text_command("wake up")

    def _send_text(self):
        t = self._input.text().strip()
        if t:
            self._input.clear()
            self._log.append_log(f"You: {t}")
            if self.on_text_command:
                threading.Thread(target=self.on_text_command, args=(t,), daemon=True).start()

    def _on_file_selected(self, path: str):
        self._log.append_log(f"FILE: Loaded {Path(path).name}")
        if self.on_text_command:
            msg = f"[FILE_UPLOADED] path={path}"
            threading.Thread(target=self.on_text_command, args=(msg,), daemon=True).start()

    def _toggle_mute(self):
        self._muted = not self._muted
        self.hud.muted = self._muted
        self._orb.muted = self._muted
        self._style_mute_btn()
        self._apply_state("MUTED" if self._muted else "LISTENING")

    def _toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def _apply_state(self, state: str):
        self.hud.state = state
        self.hud.speaking = (state == "SPEAKING")
        self._orb.speaking = (state == "SPEAKING")

    def _show_content(self, title: str, text: str):
        self._content_title.setText(title.upper())
        self._content_display.setPlainText(text)
        self._content_panel.show()

    def _update_metrics(self):
        s = _metrics.snapshot()
        self._bar_cpu.set_value(s["cpu"], f"{s['cpu']:.0f}%")
        self._bar_mem.set_value(s["mem"], f"{s['mem']:.0f}%")
        self._bar_net.set_value(min(100, s["net"] * 10), f"{s['net']:.1f}M")
        self._bar_gpu.set_value(max(0, s["gpu"]), f"{s['gpu']:.0f}%" if s["gpu"] >= 0 else "N/A")
        self._bar_tmp.set_value(max(0, s["tmp"]), f"{s['tmp']:.0f}°" if s["tmp"] >= 0 else "N/A")

    def _toggle_autostart(self):
        try:
            from core.shortcut_manager import toggle_autostart
            ok, msg = toggle_autostart()
            self._log.append_log(f"SYS: {msg}" if ok else f"ERR: {msg}")
        except Exception as e:
            self._log.append_log(f"ERR: Auto-start toggle error: {e}")

    def _create_desktop_shortcut(self):
        try:
            from core.shortcut_manager import create_desktop_shortcut
            ok, msg = create_desktop_shortcut()
            self._log.append_log(f"SYS: {msg}" if ok else f"ERR: {msg}")
        except Exception as e:
            self._log.append_log(f"ERR: Desktop shortcut error: {e}")

    def _show_confirm_banner(self, title: str, detail: str):
        if self._confirm_overlay:
            self._confirm_overlay.deleteLater()
        ov = ConfirmBanner(title, detail, self.centralWidget())
        ov.answered.connect(self._resolve_confirm)
        ov.move((self.centralWidget().width() - ov.width()) // 2, 80)
        ov.show()
        self._confirm_overlay = ov

    def _hide_confirm_banner(self):
        if self._confirm_overlay:
            self._confirm_overlay.hide()
            self._confirm_overlay.deleteLater()
            self._confirm_overlay = None

    def _resolve_confirm(self, ok: bool):
        self._hide_confirm_banner()
        try:
            from core.confirm import resolve
            resolve(ok)
        except Exception:
            pass


# ── Compatibility Root Shim ──────────────────────────────────────────────────
class _RootShim:
    def __init__(self, app: QApplication):
        self._app = app

    def mainloop(self):
        self._app.exec()

    def protocol(self, *_):
        pass


# ── Jarvis Interface Adapter ─────────────────────────────────────────────────
class JarvisUI:
    def __init__(self, face_path: str = "", size=None):
        self._app = QApplication.instance() or QApplication(sys.argv)
        self._app.setStyle("Fusion")
        self._win = MainWindow(face_path)
        self._win.show()
        self.root = _RootShim(self._app)

    def wait_for_api_key(self):
        while not self._win._ready:
            self._app.processEvents()
            time.sleep(0.05)

    def set_audio_level(self, level: float):
        self._win.hud.set_audio_level(level)
        self._win._orb.set_audio_level(level)

    def set_state(self, state: str):
        self._win._state_sig.emit(state)

    def write_log(self, text: str):
        self._win._log_sig.emit(text)

    def show_content(self, title: str, text: str):
        self._win._content_sig.emit(title, text)

    def show_confirm(self, title: str, detail: str):
        self._win._confirm_sig.emit(title, detail)

    def hide_confirm(self):
        self._win._confirm_hide_sig.emit()

    def prompt_reconfig(self):
        self._win._ready = False
        self._win._reconfig_sig.emit()

    def start_speaking(self):
        self.set_state("SPEAKING")

    def stop_speaking(self):
        if not self.muted:
            self.set_state("LISTENING")

    def show_camera_frame(self, img_bytes: bytes):
        pass

    def start_camera_stream(self):
        pass

    def stop_camera_stream(self):
        pass

    def notify_phone_connected(self):
        self._win.notify_phone_connected()

    @property
    def muted(self) -> bool:
        return self._win._muted

    @muted.setter
    def muted(self, v: bool):
        if v != self._win._muted:
            self._win._toggle_mute()

    @property
    def current_file(self) -> str | None:
        return self._win._drop_zone._current_file

    @property
    def assistant_name(self) -> str:
        return self._win._assistant_name

    @property
    def on_text_command(self):
        return self._win.on_text_command

    @on_text_command.setter
    def on_text_command(self, cb):
        self._win.on_text_command = cb

    @property
    def on_remote_clicked(self):
        return self._win.on_remote_clicked

    @on_remote_clicked.setter
    def on_remote_clicked(self, cb):
        self._win.on_remote_clicked = cb

    @property
    def on_interrupt(self):
        return self._win.on_interrupt

    @on_interrupt.setter
    def on_interrupt(self, cb):
        self._win.on_interrupt = cb

    @property
    def on_voice_change(self):
        return self._win.on_voice_change

    @on_voice_change.setter
    def on_voice_change(self, cb):
        self._win.on_voice_change = cb

    @property
    def on_audio_device_change(self):
        return self._win.on_audio_device_change

    @on_audio_device_change.setter
    def on_audio_device_change(self, cb):
        self._win.on_audio_device_change = cb

    @property
    def get_plugins(self):
        return self._win.get_plugins

    @get_plugins.setter
    def get_plugins(self, cb):
        self._win.get_plugins = cb


if __name__ == "__main__":
    ui = JarvisUI()
    ui.write_log("SYS: Siri Interface loaded.")
    ui.write_log("You: Hey Jarvis, what is the weather today?")
    ui.write_log("JARVIS: It is currently 72°F and sunny in San Francisco.")
    ui.root.mainloop()
