# 📱 JARVIS Mobile Android App & Deployment Guide

This directory contains the native Android application project for **JARVIS MARK LII (52)**.

You have two easy ways to use JARVIS on your Android phone:
1. **Instant PWA Installation (Zero Build Tools)**: Open your JARVIS dashboard in mobile Chrome and tap **"Install App"**.
2. **Native Android APK**: Build and install the standalone `.apk` using Android Studio or Gradle.

---

## ⚡ Method 1: Instant PWA Install (Fastest, No SDK Required)

1. Make sure JARVIS is running on your computer.
2. Note the LAN URL printed in your terminal or click **Remote Control** in JARVIS UI (e.g. `http://192.168.1.50:8000`).
3. On your Android phone, connect to the same Wi-Fi and open that URL in **Google Chrome**.
4. You will see a button in the header: **📲 INSTALL APP** (or tap Chrome menu `⋮` → **Add to Home screen** / **Install app**).
5. Tap **Install**. 
6. JARVIS is now installed on your Android home screen as a standalone full-screen app with launcher icon, microphone streaming, and background caching!

---

## 🔨 Method 2: Build Native Android APK (`.apk`)

The `android/` directory is a complete Android Studio project configured with:
- WebRTC & native audio capture delegates (for live voice streaming to Gemini Live)
- Cleartext LAN network security allowing local IP connections (`192.168.x.x`, `10.x.x.x`)
- SSL bypass for JARVIS's local self-signed certificates
- Persistent server address configuration with quick switching
- Pull-to-refresh and connection telemetry

### Option A: Using Android Studio (GUI)
1. Open **Android Studio**.
2. Click **Open** and select the `d:\jarvis\android` directory.
3. Let Gradle sync project dependencies.
4. Click **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
5. Once built, click **locate** in the popup notification to find your `.apk`:
   `android/app/build/outputs/apk/debug/app-debug.apk`
6. Transfer this APK to your phone (via USB, Google Drive, WhatsApp, or email) and tap to install!

### Option B: Using Command-Line (CLI)
If you have Android SDK and Java installed:
```powershell
cd d:\jarvis\android
.\gradlew assembleDebug
```
The APK will be generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

To install directly to a connected Android phone via ADB:
```powershell
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 🌐 Using JARVIS on Mobile Outside Home (4G/5G Cellular Data)

If you want to talk to your JARVIS assistant while away from home on mobile data, use one of these secure tunnels:

### 1. Cloudflare Tunnel (Free, Permanent HTTPS URL)
1. Download `cloudflared` from Cloudflare.
2. Run:
   ```bash
   cloudflared tunnel --url http://localhost:8000
   ```
3. Copy the generated `https://xxxx.trycloudflare.com` URL and enter it in the JARVIS Android App settings (⚙).

### 2. Tailscale (Private Mesh VPN)
1. Install **Tailscale** on your PC and your Android phone.
2. Connect both to your Tailscale tailnet.
3. In the JARVIS Android App, enter your PC's 100.x.y.z Tailscale IP (e.g. `http://100.x.y.z:8000`).

### 3. ngrok
1. Run:
   ```bash
   ngrok http 8000
   ```
2. Enter the generated `https://xxxx.ngrok-free.app` URL into the Android App.

---

## 🎙️ Microphone & Camera Permissions
When running for the first time:
- The app will ask for **Microphone permission**. Grant it to enable real-time speech interaction with JARVIS.
- The app will ask for **Camera/Storage permission** if you want to upload photos or documents to JARVIS for visual analysis.
