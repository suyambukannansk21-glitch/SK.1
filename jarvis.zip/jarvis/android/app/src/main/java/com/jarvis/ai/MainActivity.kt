package com.jarvis.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var statusPill: TextView
    private lateinit var setupOverlay: LinearLayout
    private lateinit var etServerUrl: EditText
    private lateinit var btnConnect: Button
    private lateinit var btnSettings: ImageButton
    private lateinit var btnRefresh: ImageButton

    private lateinit var prefs: SharedPreferences
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (!audioGranted) {
            Toast.makeText(this, R.string.permission_required, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Keep screen on during interaction
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

        initViews()
        setupWebView()
        checkAppPermissions()

        val savedUrl = prefs.getString(PREF_SERVER_URL, "") ?: ""
        if (savedUrl.isNotEmpty()) {
            loadServerUrl(savedUrl)
        } else {
            showSetupOverlay(true)
        }
    }

    private fun initViews() {
        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        statusPill = findViewById(R.id.statusPill)
        setupOverlay = findViewById(R.id.setupOverlay)
        etServerUrl = findViewById(R.id.etServerUrl)
        btnConnect = findViewById(R.id.btnConnect)
        btnSettings = findViewById(R.id.btnSettings)
        btnRefresh = findViewById(R.id.btnRefresh)

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
        swipeRefresh.setColorSchemeColors(ContextCompat.getColor(this, R.color.jarvis_cyan))

        btnRefresh.setOnClickListener {
            webView.reload()
        }

        btnSettings.setOnClickListener {
            showSettingsDialog()
        }

        btnConnect.setOnClickListener {
            val inputUrl = etServerUrl.text.toString().trim()
            if (inputUrl.isNotEmpty()) {
                val formattedUrl = formatUrl(inputUrl)
                saveServerUrl(formattedUrl)
                loadServerUrl(formattedUrl)
                showSetupOverlay(false)
            } else {
                Toast.makeText(this, "Please enter a valid JARVIS URL", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false

        // Custom User-Agent tag so server can detect native Android client
        settings.userAgentString = "${settings.userAgentString} JARVIS-Android-App/1.0"

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }

            // Handle WebRTC audio capture permissions for Gemini Live voice streaming
            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread {
                    val requestedResources = request?.resources ?: return@runOnUiThread
                    val granted = mutableListOf<String>()

                    for (r in requestedResources) {
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            if (ContextCompat.checkSelfPermission(
                                    this@MainActivity,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                granted.add(r)
                            }
                        }
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                            if (ContextCompat.checkSelfPermission(
                                    this@MainActivity,
                                    Manifest.permission.CAMERA
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                granted.add(r)
                            }
                        }
                    }

                    if (granted.isNotEmpty()) {
                        request.grant(granted.toTypedArray())
                    } else {
                        request.deny()
                    }
                }
            }

            // Support file uploads (photos, documents) to JARVIS
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = fileChooserParams?.createIntent()
                try {
                    if (intent != null) {
                        fileChooserLauncher.launch(intent)
                    }
                } catch (e: Exception) {
                    fileUploadCallback = null
                    return false
                }
                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                updateStatus("CONNECTING", R.color.jarvis_muted)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                updateStatus("ONLINE", R.color.jarvis_green)
                showSetupOverlay(false)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    updateStatus("OFFLINE", R.color.jarvis_red)
                    showSetupOverlay(true)
                }
            }

            // Accept self-signed certificates from JARVIS server
            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                // JARVIS generates a local self-signed certificate for secure mobile audio streaming
                handler?.proceed()
            }
        }
    }

    private fun checkAppPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
        }

        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (needed.isNotEmpty()) {
            requestPermissionsLauncher.launch(needed.toTypedArray())
        }
    }

    private fun loadServerUrl(url: String) {
        webView.loadUrl(url)
    }

    private fun formatUrl(raw: String): String {
        var url = raw.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://$url"
        }
        return url
    }

    private fun saveServerUrl(url: String) {
        prefs.edit().putString(PREF_SERVER_URL, url).apply()
    }

    private fun showSetupOverlay(show: Boolean) {
        setupOverlay.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            val current = prefs.getString(PREF_SERVER_URL, "")
            etServerUrl.setText(current)
        }
    }

    private fun updateStatus(text: String, colorRes: Int) {
        statusPill.text = text
        statusPill.setTextColor(ContextCompat.getColor(this, colorRes))
    }

    private fun showSettingsDialog() {
        val currentUrl = prefs.getString(PREF_SERVER_URL, "") ?: ""
        val editText = EditText(this).apply {
            setText(currentUrl)
            hint = getString(R.string.server_url_hint)
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle("JARVIS Server Address")
            .setMessage("Enter the IP & port shown in the JARVIS desktop terminal (e.g. http://192.168.1.50:8000) or your remote tunnel URL:")
            .setView(editText)
            .setPositiveButton("Save & Connect") { _, _ ->
                val newUrl = formatUrl(editText.text.toString().trim())
                if (newUrl.isNotEmpty()) {
                    saveServerUrl(newUrl)
                    loadServerUrl(newUrl)
                    showSetupOverlay(false)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private const val PREF_SERVER_URL = "pref_server_url"
    }
}
