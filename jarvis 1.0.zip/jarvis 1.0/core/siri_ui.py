"""
Next-Generation Siri UI Component Suite for J.A.R.V.I.S. / Siri AI.

Features:
- SiriOrbCanvas: Multi-layered, software-rendered 3D fluid iridescent Siri Orb,
  harmonic audio-reactive wave ribbons, floating stardust, and chromatic aura.
- FloatingSiriOrb: Frameless, transparent, draggable desktop floating orb widget
  shown when the AI window is minimized.
- SiriSettingsModal: Apple-style Settings modal housing all options EXCEPT theme
  (Assistant Name, User Name, Voice, Wake Word, PTT, Audio Devices, Plugins,
  Auto-Start, Desktop Shortcut, Remote Control, Memory, Briefing, etc.).
"""

from __future__ import annotations

import math
import random
import time
from typing import Callable

from PyQt6.QtCore import (
    QPoint, QPointF, QRect, QRectF, QSize, Qt, QTimer, pyqtSignal,
)
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath,
    QPen, QRadialGradient, QCursor, QRegion,
)
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QScrollArea, QSizePolicy, QStackedWidget,
    QVBoxLayout, QWidget,
)

# ── Siri Aesthetic Palette ──────────────────────────────────────────────────
class SiriPalette:
    # Deep obsidian midnight glass
    BG_VOID         = "#06070b"
    BG_GLASS        = "rgba(12, 15, 25, 0.88)"
    BG_CARD         = "rgba(22, 26, 42, 0.75)"
    BG_CARD_HOVER   = "rgba(32, 38, 60, 0.85)"
    BG_INPUT        = "rgba(10, 12, 20, 0.90)"

    # Frosted glass borders
    BORDER_GLASS    = "rgba(255, 255, 255, 0.10)"
    BORDER_GLOW     = "rgba(168, 85, 247, 0.40)"
    BORDER_CYAN     = "rgba(6, 182, 212, 0.40)"

    # Signature Siri Iridescent Spectrum
    VIOLET          = "#a855f7"
    INDIGO          = "#6366f1"
    CYAN            = "#06b6d4"
    SKY             = "#38bdf8"
    MAGENTA         = "#ec4899"
    AMBER           = "#f59e0b"
    EMERALD         = "#10b981"
    ROSE            = "#f43f5e"

    # Typography
    TEXT_PRIMARY    = "#f8fafc"
    TEXT_SECONDARY  = "#94a3b8"
    TEXT_MUTED      = "#64748b"

    # Font stack
    FONT_FAMILY     = "Segoe UI, -apple-system, SF Pro Display, Helvetica Neue, Arial, sans-serif"


def qcol(color_hex_or_rgba: str, alpha: int = 255) -> QColor:
    """Helper to construct QColor safely from hex or rgba."""
    c = QColor(color_hex_or_rgba)
    if alpha < 255:
        c.setAlpha(alpha)
    return c


# ── Siri Orb Canvas (Visualizer) ─────────────────────────────────────────────
class SiriOrbCanvas(QWidget):
    """
    Hypnotic Next-Gen Siri Dynamic Plasma Orb & Audio-Reactive Fluid Waves.
    Renders pure software QPainter graphics with zero GPU driver dependencies.
    """

    def __init__(self, compact: bool = False, parent: QWidget | None = None):
        super().__init__(parent)
        self.compact = compact
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, not compact)
        if compact:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setMinimumSize(120 if compact else 280, 120 if compact else 280)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        # Audio and State Tracking
        self.muted = False
        self.speaking = False
        self.state = "INITIALISING"  # LISTENING, THINKING, PROCESSING, SPEAKING, SLEEPING, IDLE
        self._live_amp = 0.0
        self._amp_disp = 0.0

        # Animation parameters
        self._tick = 0
        self._phase = 0.0
        self._wave_phase = 0.0
        self._pulse_phase = 0.0
        self._step_t = time.time()
        self._visemes = None
        self._vis_i = None

        # Floating micro-particles (stardust)
        self._particles = []
        for _ in range(36):
            self._particles.append({
                "angle": random.uniform(0, math.tau),
                "dist_ratio": random.uniform(0.65, 1.45),
                "speed": random.uniform(0.008, 0.024) * (1 if random.random() > 0.5 else -1),
                "size": random.uniform(1.2, 3.2),
                "base_alpha": random.uniform(0.25, 0.85),
                "hue_offset": random.uniform(0, 1.0),
            })

        # 60 FPS animation timer
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self._timer.start(16)

    def set_audio_level(self, level: float) -> None:
        """Feed live 0.0-1.0 audio level from microphone or TTS."""
        try:
            lv = max(0.0, min(1.0, float(level)))
            if lv > self._live_amp:
                self._live_amp = lv
        except Exception:
            pass

    def push_visemes(self, frames, hop: float, at: float) -> None:
        """Hand over TTS viseme schedule for precise lip-sync wave flaring."""
        try:
            if not frames:
                return
            self._visemes = (list(frames), float(at), max(1e-3, float(hop)))
            self._vis_i = None
        except Exception:
            pass

    def _step(self) -> None:
        self._tick += 1
        now = time.time()
        dt = min(0.05, max(0.005, now - self._step_t))
        self._step_t = now

        # Viseme synchronization
        sched = self._visemes
        if sched is not None:
            frames, t0, hop = sched
            i = int((now - t0) / hop)
            if 0 <= i < len(frames):
                v_level = frames[i][0]
                if v_level > self._live_amp:
                    self._live_amp = v_level
            elif i >= len(frames):
                self._visemes = None

        # Audio decay and smoothing
        self._live_amp *= 0.88
        self._amp_disp += (self._live_amp - self._amp_disp) * 0.42
        amp = self._amp_disp

        # Speed scaling based on AI activity
        if self.speaking:
            speed_mult = 2.4 + amp * 2.8
        elif self.state in ("THINKING", "PROCESSING"):
            speed_mult = 3.2
        elif self.state == "LISTENING":
            speed_mult = 1.6 + amp * 2.0
        elif self.muted or self.state == "SLEEPING":
            speed_mult = 0.5
        else:
            speed_mult = 1.0

        self._phase += dt * 1.5 * speed_mult
        self._wave_phase += dt * 2.6 * speed_mult
        self._pulse_phase += dt * 2.0

        # Update orbiting particles
        for p in self._particles:
            p["angle"] = (p["angle"] + p["speed"] * speed_mult) % math.tau

        # Throttle repaints when invisible or idle
        if self._on_screen():
            self.update()

    def _on_screen(self) -> bool:
        try:
            if not self.isVisible():
                return False
            win = self.window()
            return not (win.isMinimized() or win.isHidden())
        except Exception:
            return True

    def _get_state_colors(self) -> tuple[QColor, QColor, QColor, QColor]:
        """Returns (core_color, secondary_color, aura_color, wave_color)."""
        if self.muted:
            return (
                qcol(SiriPalette.ROSE),
                qcol(SiriPalette.VIOLET),
                qcol(SiriPalette.ROSE, 120),
                qcol(SiriPalette.ROSE, 160),
            )
        if self.speaking:
            return (
                qcol(SiriPalette.MAGENTA),
                qcol(SiriPalette.CYAN),
                qcol(SiriPalette.AMBER, 160),
                qcol(SiriPalette.MAGENTA, 220),
            )
        if self.state in ("THINKING", "PROCESSING"):
            return (
                qcol(SiriPalette.VIOLET),
                qcol(SiriPalette.INDIGO),
                qcol(SiriPalette.MAGENTA, 180),
                qcol(SiriPalette.SKY, 220),
            )
        if self.state == "LISTENING":
            return (
                qcol(SiriPalette.CYAN),
                qcol(SiriPalette.EMERALD),
                qcol(SiriPalette.SKY, 180),
                qcol(SiriPalette.EMERALD, 220),
            )
        if self.state == "SLEEPING":
            return (
                qcol(SiriPalette.INDIGO),
                qcol(SiriPalette.VIOLET),
                qcol(SiriPalette.INDIGO, 90),
                qcol(SiriPalette.VIOLET, 100),
            )
        # IDLE / READY / DEFAULT
        return (
            qcol(SiriPalette.CYAN),
            qcol(SiriPalette.VIOLET),
            qcol(SiriPalette.INDIGO, 140),
            qcol(SiriPalette.SKY, 180),
        )

    def paintEvent(self, _):
        p = QPainter(self)
        if not p.isActive():
            return
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        W = self.width()
        H = self.height()
        cx = W / 2.0
        cy = H / 2.0 if self.compact else (H / 2.0 - 24.0)

        # Draw deep glass background only if not compact
        if not self.compact:
            p.fillRect(self.rect(), qcol(SiriPalette.BG_VOID))

        c_core, c_sec, c_aura, c_wave = self._get_state_colors()
        amp = self._amp_disp
        t = self._phase

        # Base radius
        min_dim = min(W, H)
        if self.compact:
            base_r = min_dim * 0.38
        else:
            base_r = min(min_dim * 0.28, 140.0)

        # Dynamic breathing + audio flaring
        pulse = math.sin(self._pulse_phase) * 0.035
        r = base_r * (1.0 + pulse + amp * 0.24)

        # ── 1. Chromatic Outer Aura (Apple Intelligence Glowing Atmosphere) ──
        aura_r = r * (1.85 + amp * 0.45)
        g_aura = QRadialGradient(cx, cy, aura_r)
        g_aura.setColorAt(0.00, QColor(c_core.red(), c_core.green(), c_core.blue(), int(90 + amp * 120)))
        g_aura.setColorAt(0.40, QColor(c_sec.red(), c_sec.green(), c_sec.blue(), int(45 + amp * 70)))
        g_aura.setColorAt(0.75, QColor(c_aura.red(), c_aura.green(), c_aura.blue(), int(18 + amp * 30)))
        g_aura.setColorAt(1.00, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g_aura))
        p.drawEllipse(QRectF(cx - aura_r, cy - aura_r, aura_r * 2, aura_r * 2))

        # ── 2. Orbiting Micro-Particle Stardust ──────────────────────────────
        for pt in self._particles:
            p_dist = r * pt["dist_ratio"] * (1.0 + amp * 0.35)
            px = cx + math.cos(pt["angle"]) * p_dist
            py = cy + math.sin(pt["angle"]) * p_dist * 0.85
            p_size = pt["size"] * (1.0 + amp * 0.6)

            alpha = int(255 * min(1.0, pt["base_alpha"] * (0.6 + amp * 0.8)))
            # Hue cycle for particles
            p_col = QColor(c_sec)
            p_col.setAlpha(alpha)
            p.setBrush(QBrush(p_col))
            p.drawEllipse(QRectF(px - p_size / 2, py - p_size / 2, p_size, p_size))

        # ── 3. Multi-Layer Fluid Siri Plasma Core ────────────────────────────
        # Layer A: Deep energy body
        g_body = QRadialGradient(cx, cy, r)
        g_body.setColorAt(0.00, QColor(255, 255, 255, int(180 + amp * 75)))
        g_body.setColorAt(0.28, QColor(c_core.red(), c_core.green(), c_core.blue(), 230))
        g_body.setColorAt(0.68, QColor(c_sec.red(), c_sec.green(), c_sec.blue(), 190))
        g_body.setColorAt(0.95, QColor(c_aura.red(), c_aura.green(), c_aura.blue(), 110))
        g_body.setColorAt(1.00, QColor(c_sec.red(), c_sec.green(), c_sec.blue(), 0))
        p.setBrush(QBrush(g_body))
        p.drawEllipse(QRectF(cx - r, cy - r, r * 2, r * 2))

        # Layer B: Swirling iridescent fluid contours
        p.save()
        clip_path = QPainterPath()
        clip_path.addEllipse(QRectF(cx - r * 0.98, cy - r * 0.98, r * 1.96, r * 1.96))
        p.setClipPath(clip_path)

        # 3 offset swirling plasma spheres creating organic liquid depth
        num_blobs = 4
        for b_i in range(num_blobs):
            b_angle = t * 1.2 + b_i * (math.tau / num_blobs)
            b_dist = r * (0.32 + 0.18 * math.sin(t * 0.8 + b_i))
            bx = cx + math.cos(b_angle) * b_dist
            by = cy + math.sin(b_angle) * b_dist
            br = r * (0.55 + 0.15 * math.cos(t * 1.1 + b_i))

            g_blob = QRadialGradient(bx, by, br)
            col_pick = [c_core, c_sec, c_wave, c_aura][b_i % 4]
            g_blob.setColorAt(0.0, QColor(col_pick.red(), col_pick.green(), col_pick.blue(), 160))
            g_blob.setColorAt(0.6, QColor(col_pick.red(), col_pick.green(), col_pick.blue(), 70))
            g_blob.setColorAt(1.0, QColor(0, 0, 0, 0))
            p.setBrush(QBrush(g_blob))
            p.drawEllipse(QRectF(bx - br, by - br, br * 2, br * 2))

        p.restore()

        # ── 4. Harmonic Siri Wave Ribbons (Liquid Acoustic Waves) ────────────
        wave_w = r * 2.3
        wave_x0 = cx - wave_w / 2.0
        num_waves = 4
        wave_colors = [
            qcol(SiriPalette.CYAN, 200),
            qcol(SiriPalette.MAGENTA, 185),
            qcol(SiriPalette.VIOLET, 195),
            qcol(SiriPalette.SKY, 175),
        ]

        for w_idx in range(num_waves):
            pen_col = wave_colors[w_idx % len(wave_colors)]
            pen_w = 2.4 if not self.compact else 1.8
            p.setPen(QPen(pen_col, pen_w))
            p.setBrush(Qt.BrushStyle.NoBrush)

            w_path = QPainterPath()
            points_count = 32
            dx = wave_w / points_count
            w_phase = self._wave_phase + w_idx * 1.35
            w_amp_base = 6.0 + amp * 32.0 * (1.1 - w_idx * 0.15)

            for pt_i in range(points_count + 1):
                wx = wave_x0 + pt_i * dx
                norm_x = (pt_i / points_count) * 2.0 - 1.0  # -1 to 1
                envelope = math.exp(-3.2 * (norm_x ** 2))   # Gaussian hump
                wy = cy + math.sin(norm_x * 4.2 + w_phase) * w_amp_base * envelope

                if pt_i == 0:
                    w_path.moveTo(wx, wy)
                else:
                    w_path.lineTo(wx, wy)

            p.drawPath(w_path)

        # ── 5. Specular Gloss / Luminous Rim ─────────────────────────────────
        gloss_r = r * 0.42
        gx = cx - r * 0.28
        gy = cy - r * 0.28
        g_spec = QRadialGradient(gx, gy, gloss_r)
        g_spec.setColorAt(0.00, QColor(255, 255, 255, 170))
        g_spec.setColorAt(0.50, QColor(255, 255, 255, 40))
        g_spec.setColorAt(1.00, QColor(255, 255, 255, 0))
        p.setBrush(QBrush(g_spec))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QRectF(gx - gloss_r, gy - gloss_r, gloss_r * 2, gloss_r * 2))

        # Thin iridescent rim ring
        rim_pen = QPen(QColor(255, 255, 255, int(60 + amp * 80)), 1.2)
        p.setPen(rim_pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(cx - r, cy - r, r * 2, r * 2))

        # ── 6. HUD Elements (Status Pill & Waveform) — if not compact ────────
        if not self.compact:
            self._paint_hud_elements(p, W, H, cy + r + 26.0, c_core)

        p.end()

    def _paint_hud_elements(self, p: QPainter, W: float, H: float, sy: float, status_col: QColor) -> None:
        """Renders Apple-style status badge and audio level indicator."""
        amp = self._amp_disp

        # Status text determination
        if self.muted:
            status_txt = "MUTED"
            dot_col = qcol(SiriPalette.ROSE)
        elif self.speaking:
            status_txt = "SPEAKING"
            dot_col = qcol(SiriPalette.MAGENTA)
        elif self.state == "THINKING":
            status_txt = "THINKING..."
            dot_col = qcol(SiriPalette.VIOLET)
        elif self.state == "PROCESSING":
            status_txt = "PROCESSING..."
            dot_col = qcol(SiriPalette.SKY)
        elif self.state == "LISTENING":
            status_txt = "LISTENING..."
            dot_col = qcol(SiriPalette.EMERALD)
        elif self.state == "SLEEPING":
            status_txt = "SLEEPING"
            dot_col = qcol(SiriPalette.INDIGO)
        else:
            status_txt = "READY"
            dot_col = qcol(SiriPalette.CYAN)

        # Frosted glass status pill
        pill_w = 160.0
        pill_h = 28.0
        pill_x = (W - pill_w) / 2.0
        pill_y = sy

        p.setPen(QPen(qcol(SiriPalette.BORDER_GLASS), 1.0))
        p.setBrush(QBrush(qcol(SiriPalette.BG_CARD)))
        p.drawRoundedRect(QRectF(pill_x, pill_y, pill_w, pill_h), 14.0, 14.0)

        # Pulsing glowing dot
        dot_r = 4.0 + math.sin(self._pulse_phase * 2.0) * 1.0
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(dot_col))
        p.drawEllipse(QRectF(pill_x + 16.0 - dot_r, pill_y + 14.0 - dot_r, dot_r * 2, dot_r * 2))

        # Status Label
        p.setPen(QPen(qcol(SiriPalette.TEXT_PRIMARY), 1.0))
        p.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
        p.drawText(QRectF(pill_x + 28.0, pill_y, pill_w - 38.0, pill_h),
                   Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, status_txt)

        # Modern audio waveform bar
        bar_y = pill_y + pill_h + 16.0
        num_bars = 28
        bar_w = 4.0
        gap = 4.0
        total_w = num_bars * (bar_w + gap) - gap
        start_x = (W - total_w) / 2.0
        mid = (num_bars - 1) / 2.0

        for b_i in range(num_bars):
            dist_mid = abs(b_i - mid) / mid
            env = math.exp(-2.2 * (dist_mid ** 2))
            idle_h = 3.0 + 2.0 * math.sin(self._tick * 0.12 + b_i * 0.45)
            hgt = max(3.0, min(24.0, idle_h + amp * 22.0 * env))
            bx = start_x + b_i * (bar_w + gap)
            by = bar_y + (24.0 - hgt) / 2.0

            if self.muted:
                b_col = qcol(SiriPalette.ROSE, 120)
            elif amp > 0.04:
                b_col = qcol(SiriPalette.CYAN if b_i % 2 == 0 else SiriPalette.MAGENTA, 210)
            else:
                b_col = qcol(SiriPalette.TEXT_MUTED, 80)

            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(b_col))
            p.drawRoundedRect(QRectF(bx, by, bar_w, hgt), 2.0, 2.0)


# ── Floating Desktop Siri Orb (When AI is Minimized) ─────────────────────────
class FloatingSiriOrb(QWidget):
    """
    Floating Desktop Siri Orb widget.
    Appears on the desktop when the user minimizes the AI.
    Features:
    - Draggable anywhere on the desktop
    - Hypnotic, live audio-reactive Siri Orb animation
    - Click or double-click to restore/expand to full window
    - Hover overlay with quick action buttons (Expand, Mute Mic, Close)
    """

    restore_requested = pyqtSignal()
    mute_toggled = pyqtSignal()
    close_requested = pyqtSignal()

    _ORB_SIZE = 140

    def __init__(self, parent: QWidget | None = None):
        super().__init__(None)  # Top-level window
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(self._ORB_SIZE, self._ORB_SIZE)

        # Positioning defaults to bottom right
        self._drag_pos: QPoint | None = None
        self._is_hovered = False

        # Central Orb Canvas
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.orb_canvas = SiriOrbCanvas(compact=True, parent=self)
        lay.addWidget(self.orb_canvas)
        self.setToolTip("Siri AI • Click to expand")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        from pathlib import Path
        _ico_p = Path(__file__).resolve().parent.parent / "config" / "jarvis.ico"
        if _ico_p.exists():
            from PyQt6.QtGui import QIcon
            self.setWindowIcon(QIcon(str(_ico_p)))

    def set_state(self, state: str) -> None:
        self.orb_canvas.state = state

    def set_muted(self, muted: bool) -> None:
        self.orb_canvas.muted = muted

    def set_speaking(self, speaking: bool) -> None:
        self.orb_canvas.speaking = speaking

    def set_audio_level(self, lvl: float) -> None:
        self.orb_canvas.set_audio_level(lvl)

    def enterEvent(self, event):
        self._is_hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._is_hovered = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos is not None:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            # Check if this was a click rather than a drag
            cur_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            if self._drag_pos and (cur_pos - self._drag_pos).manhattanLength() < 5:
                # User clicked to restore!
                self.restore_requested.emit()
            self._drag_pos = None
            event.accept()

    def mouseDoubleClickEvent(self, event):
        self.restore_requested.emit()
        event.accept()

    def paintEvent(self, event):
        # Base orb canvas draws itself. When hovered, we draw subtle frosted controls.
        super().paintEvent(event)
        if self._is_hovered:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            W, H = self.width(), self.height()

            # Outer subtle glow ring
            p.setPen(QPen(qcol(SiriPalette.CYAN, 160), 1.5))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(4, 4, W - 8, H - 8))

            # Small top pill badge
            pill_txt = "⤢ EXPAND"
            p.setFont(QFont("Segoe UI", 7, QFont.Weight.Bold))
            p.setPen(QPen(qcol(SiriPalette.TEXT_PRIMARY), 1.0))
            p.setBrush(QBrush(qcol(SiriPalette.BG_CARD, 220)))
            p.drawRoundedRect(QRectF((W - 64) / 2, H - 24, 64, 18), 9, 9)
            p.drawText(QRectF((W - 64) / 2, H - 24, 64, 18),
                       Qt.AlignmentFlag.AlignCenter, pill_txt)
            p.end()


# ── Siri Settings Modal (ALL Options Except Theme) ───────────────────────────
class SiriSettingsModal(QWidget):
    """
    Next-Generation Apple-Style Settings Dialog.
    Contains ALL settings and options EXCEPT theme/color selection:
    1. Identity & Voice (Assistant Name, User Name, Voice Picker, Daily Briefing)
    2. Voice & Wake Word (Wake Word toggle, Manual Wake/Sleep, Offline Model Download, PTT)
    3. Audio & Hardware (Microphone & Speaker Device selection)
    4. System & Integration (Auto-Start on Boot, Desktop Shortcut, Remote Dashboard)
    5. Plugins & Memory (Plugin Manager toggles, Plugin Settings, Conversation Memory)
    """

    saved = pyqtSignal(str, str, str)  # assistant_name, user_name, voice_name

    def __init__(self,
                 assistant_name: str = "JARVIS",
                 user_name: str = "",
                 voice_name: str = "Charon",
                 parent: QWidget | None = None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedSize(580, 680)

        self._assistant_name = assistant_name
        self._user_name = user_name
        self._voice_name = voice_name

        # Callbacks hooked by MainWindow
        self.on_create_shortcut: Callable[[], None] | None = None
        self.on_toggle_autostart: Callable[[], None] | None = None
        self.on_open_remote: Callable[[], None] | None = None
        self.on_open_audio_devices: Callable[[], None] | None = None
        self.on_open_memory: Callable[[], None] | None = None
        self.on_open_plugins: Callable[[], None] | None = None
        self.on_open_plugin_settings: Callable[[], None] | None = None
        self.on_toggle_wake_word: Callable[[bool], str] | None = None
        self.on_wake_manual: Callable[[], None] | None = None
        self.on_wake_install: Callable[[], tuple[bool, str]] | None = None
        self.on_toggle_ptt: Callable[[], None] | None = None
        self.on_toggle_brief: Callable[[], None] | None = None
        self.on_voice_change: Callable[[str], None] | None = None
        self.on_test_voice: Callable[[str], None] | None = None

        self._init_ui()

    def _init_ui(self) -> None:
        self.setStyleSheet(f"""
            QWidget {{
                color: {SiriPalette.TEXT_PRIMARY};
                font-family: {SiriPalette.FONT_FAMILY};
            }}
            QScrollArea {{
                border: none;
                background: transparent;
            }}
            QScrollBar:vertical {{
                background: transparent;
                width: 6px;
                margin: 0px;
            }}
            QScrollBar::handle:vertical {{
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                min-height: 20px;
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)

        # Main background card layout
        outer_lay = QVBoxLayout(self)
        outer_lay.setContentsMargins(0, 0, 0, 0)

        card = QWidget(self)
        card.setObjectName("SettingsCard")
        card.setStyleSheet(f"""
            QWidget#SettingsCard {{
                background: {SiriPalette.BG_GLASS};
                border: 1px solid {SiriPalette.BORDER_GLOW};
                border-radius: 18px;
            }}
        """)
        outer_lay.addWidget(card)

        card_lay = QVBoxLayout(card)
        card_lay.setContentsMargins(28, 22, 28, 22)
        card_lay.setSpacing(14)

        # ── Header ───────────────────────────────────────────────────────────
        hdr = QHBoxLayout()
        hdr_icon = QLabel("⚙")
        hdr_icon.setFont(QFont("Segoe UI", 16))
        hdr_icon.setStyleSheet(f"color: {SiriPalette.CYAN};")
        hdr.addWidget(hdr_icon)

        hdr_title = QLabel("AI SETTINGS & PREFERENCES")
        hdr_title.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        hdr_title.setStyleSheet(f"color: {SiriPalette.TEXT_PRIMARY}; letter-spacing: 0.5px;")
        hdr.addWidget(hdr_title)
        hdr.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(28, 28)
        close_btn.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255, 255, 255, 0.08);
                color: {SiriPalette.TEXT_SECONDARY};
                border-radius: 14px;
                border: none;
            }}
            QPushButton:hover {{
                background: rgba(244, 63, 94, 0.3);
                color: #fff;
            }}
        """)
        close_btn.clicked.connect(self.hide)
        hdr.addWidget(close_btn)
        card_lay.addLayout(hdr)

        # Divider
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none; height: 1px;")
        card_lay.addWidget(sep)

        # ── Scrollable Settings Sections ──────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent;")

        scroll_content = QWidget()
        scroll_content.setStyleSheet("background: transparent;")
        s_lay = QVBoxLayout(scroll_content)
        s_lay.setContentsMargins(4, 4, 12, 4)
        s_lay.setSpacing(16)

        def _section_header(title: str, icon: str = "◈") -> QLabel:
            lbl = QLabel(f"{icon}  {title}")
            lbl.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            lbl.setStyleSheet(f"color: {SiriPalette.CYAN}; margin-top: 6px; letter-spacing: 0.5px;")
            return lbl

        def _input_style() -> str:
            return f"""
                QLineEdit {{
                    background: {SiriPalette.BG_INPUT};
                    color: {SiriPalette.TEXT_PRIMARY};
                    border: 1px solid {SiriPalette.BORDER_GLASS};
                    border-radius: 8px;
                    padding: 6px 12px;
                    font-size: 13px;
                }}
                QLineEdit:focus {{
                    border: 1px solid {SiriPalette.CYAN};
                    background: rgba(15, 18, 30, 0.98);
                }}
            """

        def _btn_pill(text: str, primary: bool = False) -> QPushButton:
            b = QPushButton(text)
            b.setFixedHeight(34)
            b.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            bg = f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {SiriPalette.INDIGO}, stop:1 {SiriPalette.VIOLET});" if primary else f"background: {SiriPalette.BG_CARD};"
            border = f"border: 1px solid {SiriPalette.BORDER_GLOW};" if primary else f"border: 1px solid {SiriPalette.BORDER_GLASS};"
            b.setStyleSheet(f"""
                QPushButton {{
                    {bg}
                    {border}
                    color: {SiriPalette.TEXT_PRIMARY};
                    border-radius: 8px;
                    padding: 0 14px;
                    text-align: left;
                }}
                QPushButton:hover {{
                    background: rgba(56, 189, 248, 0.18);
                    border: 1px solid {SiriPalette.SKY};
                }}
            """)
            return b

        # ── Section 1: Assistant Identity & Persona ──────────────────────────
        s_lay.addWidget(_section_header("ASSISTANT IDENTITY & PERSONA", "👤"))

        # Assistant Name
        lbl_asst = QLabel("Assistant Name")
        lbl_asst.setFont(QFont("Segoe UI", 8))
        lbl_asst.setStyleSheet(f"color: {SiriPalette.TEXT_MUTED};")
        s_lay.addWidget(lbl_asst)

        self._name_input = QLineEdit(self._assistant_name)
        self._name_input.setFixedHeight(34)
        self._name_input.setStyleSheet(_input_style())
        s_lay.addWidget(self._name_input)

        # User Name
        lbl_user = QLabel("Your Name (how the AI addresses you)")
        lbl_user.setFont(QFont("Segoe UI", 8))
        lbl_user.setStyleSheet(f"color: {SiriPalette.TEXT_MUTED};")
        s_lay.addWidget(lbl_user)

        self._user_input = QLineEdit(self._user_name)
        self._user_input.setPlaceholderText("e.g. Tony, Master, Alex (leave blank for default)")
        self._user_input.setFixedHeight(34)
        self._user_input.setStyleSheet(_input_style())
        s_lay.addWidget(self._user_input)

        # Assistant Voice Picker
        lbl_voice = QLabel("Assistant Voice (Gemini Live Models)")
        lbl_voice.setFont(QFont("Segoe UI", 8))
        lbl_voice.setStyleSheet(f"color: {SiriPalette.TEXT_MUTED};")
        s_lay.addWidget(lbl_voice)

        from memory.config_manager import AVAILABLE_VOICES, DEFAULT_VOICE
        self._voice_btns: dict[str, QPushButton] = {}
        v_box = QHBoxLayout()
        v_box.setSpacing(6)
        for v_name in AVAILABLE_VOICES:
            b = QPushButton(v_name)
            b.setCheckable(True)
            b.setFixedHeight(30)
            b.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _, name=v_name: self._pick_voice(name))
            self._voice_btns[v_name] = b
            v_box.addWidget(b)
        s_lay.addLayout(v_box)

        # Voice description + Instant Test action
        desc_row = QHBoxLayout()
        desc_row.setSpacing(8)
        self._voice_desc_lbl = QLabel("")
        self._voice_desc_lbl.setFont(QFont("Segoe UI", 8))
        self._voice_desc_lbl.setStyleSheet(f"color: {SiriPalette.CYAN};")
        desc_row.addWidget(self._voice_desc_lbl, stretch=1)

        self._test_voice_btn = QPushButton("▶ Test Voice")
        self._test_voice_btn.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self._test_voice_btn.setFixedHeight(24)
        self._test_voice_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._test_voice_btn.setToolTip("Ask Siri to say a brief test sentence in this voice")
        self._test_voice_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(6, 182, 212, 0.15);
                color: {SiriPalette.CYAN};
                border: 1px solid rgba(6, 182, 212, 0.40);
                border-radius: 6px;
                padding: 0 10px;
            }}
            QPushButton:hover {{
                background: rgba(6, 182, 212, 0.30);
                color: #ffffff;
            }}
        """)
        self._test_voice_btn.clicked.connect(self._test_current_voice)
        desc_row.addWidget(self._test_voice_btn)
        s_lay.addLayout(desc_row)

        self._refresh_voice_pills()

        # Daily Briefing Toggle
        from memory.config_manager import get_brief_enabled
        self._brief_chk = QCheckBox("Deliver morning briefing on startup")
        self._brief_chk.setChecked(get_brief_enabled())
        self._brief_chk.setStyleSheet(f"""
            QCheckBox {{
                color: {SiriPalette.TEXT_SECONDARY};
                font-size: 12px;
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 1px solid {SiriPalette.BORDER_GLASS};
                background: {SiriPalette.BG_INPUT};
            }}
            QCheckBox::indicator:checked {{
                background: {SiriPalette.CYAN};
                border: 1px solid {SiriPalette.SKY};
            }}
        """)
        self._brief_chk.toggled.connect(self._on_brief_toggled)
        s_lay.addWidget(self._brief_chk)

        # ── Section 2: Voice & Wake Word ─────────────────────────────────────
        s_lay.addWidget(_section_header("VOICE & WAKE WORD DETECTION", "🎙"))

        wake_row = QHBoxLayout()
        self._wake_btn = _btn_pill("🎙  WAKE WORD: TOGGLE")
        self._wake_btn.clicked.connect(self._on_toggle_wake_word_click)
        wake_row.addWidget(self._wake_btn)

        self._wake_manual_btn = _btn_pill("🌙  MANUAL SLEEP / WAKE")
        self._wake_manual_btn.clicked.connect(self._on_wake_manual_click)
        wake_row.addWidget(self._wake_manual_btn)
        s_lay.addLayout(wake_row)

        ptt_row = QHBoxLayout()
        self._ptt_btn = _btn_pill("🗣  PUSH-TO-TALK (SPACE)")
        self._ptt_btn.clicked.connect(self._on_toggle_ptt_click)
        ptt_row.addWidget(self._ptt_btn)

        self._wake_model_btn = _btn_pill("⬇  DOWNLOAD WAKE MODEL")
        self._wake_model_btn.clicked.connect(self._on_wake_install_click)
        ptt_row.addWidget(self._wake_model_btn)
        s_lay.addLayout(ptt_row)

        # ── Section 3: Audio Devices ─────────────────────────────────────────
        s_lay.addWidget(_section_header("AUDIO & HARDWARE", "🎧"))

        audio_btn = _btn_pill("🎧  CONFIGURE AUDIO DEVICES (MIC & SPEAKERS)")
        audio_btn.clicked.connect(self._on_audio_devices_click)
        s_lay.addWidget(audio_btn)

        # ── Section 4: System & Shortcuts ────────────────────────────────────
        s_lay.addWidget(_section_header("SYSTEM & DESKTOP INTEGRATION", "⚡"))

        sys_row = QHBoxLayout()
        self._autostart_btn = _btn_pill("◉  AUTO-START WITH WINDOWS")
        self._autostart_btn.clicked.connect(self._on_autostart_click)
        sys_row.addWidget(self._autostart_btn)

        shortcut_btn = _btn_pill("⊞  CREATE DESKTOP SHORTCUT")
        shortcut_btn.clicked.connect(self._on_shortcut_click)
        sys_row.addWidget(shortcut_btn)
        s_lay.addLayout(sys_row)

        remote_btn = _btn_pill("📱  REMOTE CONTROL & MOBILE DASHBOARD")
        remote_btn.clicked.connect(self._on_remote_click)
        s_lay.addWidget(remote_btn)

        # ── Section 5: Plugins & Memory ──────────────────────────────────────
        s_lay.addWidget(_section_header("PLUGINS & MEMORY MANAGEMENT", "🧩"))

        plug_row = QHBoxLayout()
        plugin_mgr_btn = _btn_pill("🧩  MANAGE PLUGINS")
        plugin_mgr_btn.clicked.connect(self._on_plugins_click)
        plug_row.addWidget(plugin_mgr_btn)

        plugin_cfg_btn = _btn_pill("⚙  PLUGIN SETTINGS")
        plugin_cfg_btn.clicked.connect(self._on_plugin_settings_click)
        plug_row.addWidget(plugin_cfg_btn)
        s_lay.addLayout(plug_row)

        mem_btn = _btn_pill("🧠  LONG-TERM MEMORY & CONTEXT")
        mem_btn.clicked.connect(self._on_memory_click)
        s_lay.addWidget(mem_btn)

        s_lay.addSpacing(10)
        scroll.setWidget(scroll_content)
        card_lay.addWidget(scroll)

        # ── Footer / Action Buttons ──────────────────────────────────────────
        footer = QHBoxLayout()
        footer.setSpacing(12)

        self._status_lbl = QLabel("")
        self._status_lbl.setFont(QFont("Segoe UI", 9))
        self._status_lbl.setStyleSheet(f"color: {SiriPalette.EMERALD};")
        footer.addWidget(self._status_lbl)
        footer.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setFixedSize(90, 36)
        cancel_btn.setFont(QFont("Segoe UI", 9))
        cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {SiriPalette.TEXT_SECONDARY};
                border: 1px solid {SiriPalette.BORDER_GLASS};
                border-radius: 8px;
            }}
            QPushButton:hover {{
                background: rgba(255, 255, 255, 0.05);
                color: {SiriPalette.TEXT_PRIMARY};
            }}
        """)
        cancel_btn.clicked.connect(self.hide)
        footer.addWidget(cancel_btn)

        apply_btn = QPushButton("Save & Apply")
        apply_btn.setFixedSize(120, 36)
        apply_btn.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        apply_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        apply_btn.setStyleSheet(f"""
            QPushButton {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {SiriPalette.INDIGO}, stop:1 {SiriPalette.VIOLET});
                color: #ffffff;
                border: none;
                border-radius: 8px;
            }}
            QPushButton:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {SiriPalette.CYAN}, stop:1 {SiriPalette.INDIGO});
            }}
        """)
        apply_btn.clicked.connect(self._apply)
        footer.addWidget(apply_btn)

        card_lay.addLayout(footer)

    def _pick_voice(self, name: str) -> None:
        self._voice_name = name
        self._refresh_voice_pills()
        if self.on_voice_change:
            self.on_voice_change(name)
        if hasattr(self, "_status_lbl"):
            self._status_lbl.setText(f"✓ Voice set to {name} — reconnecting AI session...")

    def _test_current_voice(self) -> None:
        if self.on_test_voice:
            self.on_test_voice(self._voice_name)
        if hasattr(self, "_status_lbl"):
            self._status_lbl.setText(f"Testing {self._voice_name} voice...")

    def _refresh_voice_pills(self) -> None:
        _info_map = {
            "Puck": "Energetic, youthful male voice",
            "Charon": "Deep, confident male voice (Default)",
            "Kore": "Warm, clear, natural female voice",
            "Fenrir": "Authoritative baritone male voice",
            "Aoede": "Expressive, articulate female voice",
        }
        for name, b in self._voice_btns.items():
            on = (name == self._voice_name)
            b.setChecked(on)
            if on:
                b.setStyleSheet(f"""
                    QPushButton {{
                        background: rgba(6, 182, 212, 0.25);
                        color: {SiriPalette.CYAN};
                        border: 1.5px solid {SiriPalette.CYAN};
                        border-radius: 6px;
                    }}
                """)
            else:
                b.setStyleSheet(f"""
                    QPushButton {{
                        background: {SiriPalette.BG_CARD};
                        color: {SiriPalette.TEXT_SECONDARY};
                        border: 1px solid {SiriPalette.BORDER_GLASS};
                        border-radius: 6px;
                    }}
                    QPushButton:hover {{
                        color: {SiriPalette.TEXT_PRIMARY};
                        border: 1px solid rgba(255, 255, 255, 0.25);
                    }}
                """)
        if hasattr(self, "_voice_desc_lbl"):
            desc = _info_map.get(self._voice_name, "Gemini Live voice")
            self._voice_desc_lbl.setText(f"Active: {self._voice_name} — {desc}")

    def _on_brief_toggled(self, checked: bool) -> None:
        if self.on_toggle_brief:
            self.on_toggle_brief()

    def _on_toggle_wake_word_click(self) -> None:
        if self.on_toggle_wake_word:
            self.on_toggle_wake_word(True)

    def _on_wake_manual_click(self) -> None:
        if self.on_wake_manual:
            self.on_wake_manual()

    def _on_wake_install_click(self) -> None:
        if self.on_wake_install:
            self.on_wake_install()

    def _on_toggle_ptt_click(self) -> None:
        if self.on_toggle_ptt:
            self.on_toggle_ptt()

    def _on_audio_devices_click(self) -> None:
        self.hide()
        if self.on_open_audio_devices:
            self.on_open_audio_devices()

    def _on_autostart_click(self) -> None:
        if self.on_toggle_autostart:
            self.on_toggle_autostart()

    def _on_shortcut_click(self) -> None:
        if self.on_create_shortcut:
            self.on_create_shortcut()

    def _on_remote_click(self) -> None:
        self.hide()
        if self.on_open_remote:
            self.on_open_remote()

    def _on_plugins_click(self) -> None:
        self.hide()
        if self.on_open_plugins:
            self.on_open_plugins()

    def _on_plugin_settings_click(self) -> None:
        self.hide()
        if self.on_open_plugin_settings:
            self.on_open_plugin_settings()

    def _on_memory_click(self) -> None:
        self.hide()
        if self.on_open_memory:
            self.on_open_memory()

    def _apply(self) -> None:
        asst = self._name_input.text().strip() or "JARVIS"
        user = self._user_input.text().strip()
        voice = self._voice_name

        from memory.config_manager import save_assistant_config
        save_assistant_config(asst, user)

        self.saved.emit(asst, user, voice)
        self._status_lbl.setText("✓ Settings saved successfully")
        QTimer.singleShot(1200, self.hide)
